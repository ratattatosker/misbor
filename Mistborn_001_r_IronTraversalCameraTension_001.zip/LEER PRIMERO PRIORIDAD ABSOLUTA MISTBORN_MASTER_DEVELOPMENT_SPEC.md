# MISTBORN — DOCUMENTO MAESTRO DE DISEÑO Y DESARROLLO

**Versión:** 1.2 · **Fecha:** 2026-10-11  
**Estado:** contrato de producto vigente; la implementación actual requiere validación de ejecución y de sensación en Godot.  
**Ámbito:** toda la jugabilidad. La historia queda fuera. El arte se limita a concept art y referencias visuales; no se producirá arte final en esta fase.

> **Este es el único documento normativo del proyecto.** Si un documento, comentario, nombre de archivo, instrucción antigua o implementación contradice este documento, prevalece este documento. El código describe lo que existe; no convierte automáticamente un comportamiento en diseño aprobado. Una mecánica solo se considera aceptada cuando supera las pruebas técnicas y la validación jugable.

---

# PARTE I — OBJETIVO Y REGLAS INNEGOCIABLES

## 1. La prueba principal

El juego debe hacer que el jugador piense: «Estoy jugando a Mistborn». Debe sentir que interpreta el mundo mediante metal, dirección, distancia, altura, masa, inercia y oportunidad. No buscamos una simulación física perfecta ni una copia literal de otro juego: buscamos el resultado jugable más convincente.

**La experiencia del jugador prevalece sobre la elegancia del código.** Se permite usar fuerzas, velocity shaping, asistencia invisible, estados especiales, targeting contextual, cámara, animación, IK, VFX y reglas de contacto si producen el resultado correcto y son consistentes.

## 2. Reglas de desarrollo

1. **Un cambio jugable principal por paso.** Dividir los trabajos grandes en pasos pequeños y verificables; un paso puede requerir múltiples rondas de trabajo.
2. **Causa raíz, no parches cosméticos.** Si una mecánica se comporta mal, investigar el flujo completo y reconstruir el módulo afectado si hace falta. No ocultar errores de compilación o comportamiento con excepciones arbitrarias.
3. **Rollback real.** No sobrescribir ni eliminar el ZIP estable anterior. Entregar un nuevo ZIP versionado y conservar la base previa para volver atrás.
4. **No declarar pruebas que no se ejecutaron.** Distinguir auditoría estática, parseo real de Godot, pruebas automatizadas y validación manual de feel.
5. **Godot 4.7.2 como referencia actual.** El proyecto debe seguir siendo ligero y ejecutable en el equipo objetivo conocido: Acer Aspire ES1-572, Intel i3-7100U, 16 GB RAM. Medir en lugar de asumir.
6. **Módulos aislados.** Un cambio en targeting no debe romper cámara, combate, Coin Jump o locomoción. Evitar responsabilidades duplicadas.
7. **No añadir sistemas porque sean populares.** Cada mecánica debe justificar qué decisión interesante aporta al jugador.
8. **No ampliar alcance por accidente.** Historia y metales diferentes de Steel/Iron están en pausa. El mapa completo de Luthadel está aparcado en `docs/MAPA_LUTHADEL_PENDIENTE.md`.
9. **El código no es canon.** Una regla anterior solo se mantiene si produce el resultado aprobado y no contradice este documento.
10. **Después de cada cambio:** inspeccionar diferencias, revisar referencias a APIs, analizar errores/warnings, ejecutar tests disponibles, validar en Godot si el ejecutable está disponible, revisar regresiones y actualizar este documento solo si cambia el contrato aprobado.

## 3. No negociables de calidad

- El input debe responder de manera predecible.
- La cámara no debe robar el control ni ocultar información crítica.
- La asistencia no debe sentirse como un piloto automático.
- Ninguna interacción alomántica debe cambiar de objetivo silenciosamente durante una pulsación fijada.
- El mismo tipo de interacción debe producir resultados coherentes en traversal y combate.
- Los enemigos no pueden conocer la posición del jugador a través de paredes o sin percepción válida.
- Los impactos no pueden aplicar daño varias veces por una única colisión.
- El entorno debe ser físicamente legible: sin paredes invisibles arbitrarias, teleportaciones encubiertas o colisiones que contradigan la imagen.
- La estética de referencia es estilizada, con siluetas ricas; no reducir el mundo a cubos sin carácter para optimizar. El arte, por ahora, será conceptual, no producción final.

---

# PARTE II — ENCUESTA MAESTRA Y PRIORIDADES

## 4. PRIORIDAD 1 — PROMPT DE INTERROGATORIO TOTAL DEL JUEGO

**Este prompt debe ejecutarse antes de priorizar nuevas mecánicas o diseñar grandes sistemas.** Su objetivo es construir una especificación jugable completa y aprobada por el usuario. No debe preguntar sobre trama, diálogos, lore narrativo, finales ni escritura de personajes. El arte se pregunta únicamente como concepto visual de apoyo, nunca como producción de assets finales.

### PROMPT MAESTRO DE ENCUESTA

> Actúa como director de diseño de sistemas y entrevistador técnico del videojuego Mistborn. Antes de proponer una implementación nueva, construye conmigo una guía de producto exhaustiva que cubra todas las áreas jugables. No supongas preferencias por mí. No conviertas tus sugerencias en decisiones aprobadas sin que yo las confirme.
>
> **Método de entrevista:**
> 1. Divide la entrevista en módulos temáticos y pregunta solo un bloque manejable cada vez (aproximadamente 5–8 preguntas relacionadas). No me entregues un cuestionario interminable en un solo mensaje.
> 2. Para cada pregunta, ofrece opciones concretas cuando ayuden, incluye «otra respuesta» y recomienda una opción por razones jugables, sin presionarme a aceptarla.
> 3. Distingue cada punto como **Decidido por el usuario**, **Recomendación pendiente**, **Pendiente de respuesta**, **Experimento por validar** o **Descartado**.
> 4. Después de cada bloque, resume las respuestas confirmadas, detecta contradicciones y pregunta solo lo necesario para resolverlas. No inventes respuestas faltantes.
> 5. Mantén una matriz maestra de requisitos con: ID, sistema, decisión, motivo jugable, dependencias, prioridad, riesgo técnico, prueba de aceptación y estado.
> 6. Si una decisión cambia otra, explica la dependencia antes de cerrar el bloque. No implementes nada durante la entrevista.
> 7. Cuando un módulo esté completo, no vuelvas a abrirlo sin señalar una contradicción, una prueba fallida o una decisión nueva del usuario.
> 8. Al terminar todos los módulos, genera una especificación funcional completa, un mapa de dependencias, una lista de preguntas sin resolver y un roadmap ordenado por impacto jugable. La encuesta es la Prioridad 1 y debe completarse antes de comprometer un roadmap definitivo, salvo correcciones críticas del proyecto actual.
>
> **Módulos obligatorios de la entrevista (no omitas ninguno):**
>
> **A. Identidad jugable y límites del proyecto:** perspectiva, modo de juego, fantasía principal, estructura de sesiones, solo/multijugador, plataforma objetivo, controles, accesibilidad, dificultad, límites de alcance y qué significa que una prueba «se sienta bien».
>
> **B. Movimiento terrestre:** caminar, correr, aceleración, frenado, giro, sprint, agacharse, saltar, salto variable, coyote time, jump buffer, caída, aterrizaje, escalada, vault, deslizarse, colisiones, pendientes, bordes, interacción con puertas y objetos, estados de movimiento y prioridades de input.
>
> **C. Movimiento aéreo y verticalidad:** control aéreo, momentum, caídas, recuperación, aterrizaje sobre superficies estrechas, maniobras, recuperación tras fallos, tolerancia a errores, cámara en altura, límites del mundo y transiciones tierra-aire.
>
> **D. Steel:** entrada y salida, tap/hold, adquisición, fijación, reacquisición, prioridades de objetivos, dirección del empuje, masa, soporte, rango, cono, objetivos fuera de cámara, enemigos, proyectiles, traversal, combate, recuperación, feedback y casos de fallo.
>
> **E. Iron:** entrada y salida, fuerza continua, ancla, dirección dinámica, conservación de momentum, gravedad, control aéreo, masa, soporte, llegada y aterrizaje contextual, objetivos móviles, interrupciones, combate y diferencias con Steel.
>
> **F. Monedas y Coin Jump:** lanzamiento ordinario, apuntado, cámara lenta, cámara, retícula, trayectoria prevista, confirmación, velocidad, colisiones, rebotes, recuperación, cantidad disponible, usos de distracción/combate/traversal, relación con Steel/Iron, activación Space×2, moneda invocada, dirección descendente, duración real de la interacción y repetición sin bloquear la siguiente moneda.
>
> **G. Otros objetos metálicos y entorno interactivo:** farolas, puntas metálicas, armas, monedas, tapas de alcantarilla, objetos movibles, masas efectivas, objetos bloqueados, soporte físico, destrucción permitida, objetos recuperables, visibilidad, densidad de objetivos y legibilidad de las líneas.
>
> **H. Combate cuerpo a cuerpo:** ataque ligero/pesado, combos, preparación/impacto/recuperación, cancelaciones, alcance, dirección, fijación de enemigo, daño, hitboxes/hurtboxes, interrupción, aturdimiento, derribo, recuperación, ataques aéreos, ataques durante traversal y acciones contextuales.
>
> **I. Defensa:** parry/parada, bloqueo, esquiva, invulnerabilidad si la hubiera, contraataques, coste, ventanas, lectura de ataques, agarres, ataques no bloqueables, recuperación y alternativas para jugadores con distintos niveles de habilidad.
>
> **J. Combate alomántico:** Steel/Iron contra enemigos, proyectiles y entorno; control posicional; interrupción; impactos contra paredes; caídas; sinergias con cuerpo a cuerpo; límites antiabuso; enemigos que resisten o responden de forma distinta y reglas comunes entre traversal y combate.
>
> **K. Enemigos y arquetipos:** guardia básico, defensivo, ágil, pesado, a distancia, grupos, enemigos élite, jefes, resistencia, postura, vulnerabilidades, percepción, estados, animaciones legibles, variación y escalado de dificultad.
>
> **L. IA y sigilo:** patrulla, visión, oclusión, ruido, sospecha, investigación, alerta, persecución, última posición conocida, coordinación de grupos, búsqueda, pérdida de contacto, retorno a patrulla, distracciones con monedas y consecuencias del combate.
>
> **M. Salud, recursos y derrota:** salud del jugador/enemigos, curación si existe, recursos alománticos, monedas, recuperación, muerte/derrota, checkpoints, reintento, penalizaciones, reinicio de encuentro y accesibilidad. No asumir reglas Souls por defecto.
>
> **N. Progresión y personalización:** desbloqueos, árbol de habilidades si existe, mejoras funcionales frente a estadísticas, equipo, recursos, aprendizaje, tutorialización jugable, configuraciones y posibilidad de completar el juego sin mejoras obligatorias.
>
> **O. Cámara, apuntado y control:** cámara libre, fijación, sensibilidad, inversión, aceleración, colisión, cámara en altura, cámara lenta, FOV, sacudidas, bloqueo de objetivo, cambio de objetivo, cámara en grupos y prioridad entre objetivo de combate y objetivo alomántico.
>
> **P. HUD, información y accesibilidad:** salud, postura, alerta, monedas, retícula, líneas alománticas, tutoriales contextuales, indicadores de ataque, subtítulos de señales si se necesitan, escalado de interfaz, daltonismo, remapeo, opciones para reducir cámara lenta/sacudidas y ayudas configurables.
>
> **Q. Mundo jugable y actividades (sin historia):** escala del espacio de prueba, navegación, verticalidad, rutas alternativas, arenas, encuentros, actividades repetibles, interiores jugables, sótanos, tejados, interacciones ambientales, densidad de metal y relación entre espacio y traversal. Mantén el mapa completo de Luthadel aparcado hasta que yo lo reactive explícitamente.
>
> **R. Estructura de niveles y encuentros:** duración de encuentros, cantidad de enemigos, entradas/salidas, arenas, cobertura, alturas, emboscadas, rutas de escape, objetivos jugables, checkpoints y criterios de finalización de una zona, sin hablar de trama.
>
> **S. Arte conceptual y presentación (solo conceptual):** silueta del personaje, referencias de estilo, lenguaje visual de enemigos, concepto de ciudad, paleta, iluminación, materiales, cámara de referencia y concept sheets necesarios para comunicar diseño. No planifiques modelado final, texturas finales ni producción masiva de assets en esta fase.
>
> **T. Audio y feedback:** señales de ataques, impacto, alomancia, aterrizaje, detección, monedas, música funcional si se requiere, prioridad de mezcla y opciones de accesibilidad.
>
> **U. Rendimiento y tecnología:** presupuesto de FPS/frame time, física activa, cantidad de enemigos/monedas, pooling, LOD, streaming futuro por celdas, oclusión, perfilado, memoria, estabilidad en el equipo objetivo y criterios para aceptar una solución más barata.
>
> **V. QA y aceptación:** pruebas automatizadas, pruebas manuales, casos límite, regresiones, métricas, validación en Godot, reporte de errores, criterios para declarar un sistema estable y condiciones para rollback.
>
> **W. Dependencias, prioridades y riesgos:** qué debe existir antes de cada sistema, qué puede prototiparse en paralelo, qué mecánicas se excluyen, cuáles son los mayores riesgos y qué se debe demostrar con un prototipo antes de expandir.
>
> Empieza por el módulo A y continúa secuencialmente. No saltes módulos por considerarlos secundarios. Al final, pregúntame si falta alguna actividad jugable que no aparezca en la lista y añade un módulo adicional si la respuesta lo requiere. El resultado final debe servir como contrato del juego y como base para priorizar y programar todas las mecánicas en conjunto.

### Entregables obligatorios de la encuesta

- Matriz de requisitos y decisiones aprobadas.
- Lista de preguntas pendientes y contradicciones.
- Diagrama de dependencias entre sistemas.
- Catálogo de estados e inputs.
- Criterios de aceptación medibles para cada mecánica.
- Roadmap por impacto jugable, riesgo y dependencia.
- Lista explícita de cosas excluidas del alcance.

## 5. Lista de prioridades general

El punto 1 es la encuesta anterior. El resto es el orden provisional de implementación **sujeto a lo que revele la encuesta**. Los defectos que impidan abrir, ejecutar o controlar el prototipo actual pueden adelantarse como correcciones de bloqueo, pero no justifican saltarse la encuesta como guía de producto.

1. **Encuesta/interrogatorio total del juego** (prompt de la sección 4).
2. **Auditar la base actual y crear baseline verificable:** abrir el ZIP vigente en Godot 4.7.2, recopilar errores/warnings, ejecutar pruebas existentes y registrar qué funciona realmente.
3. **Cerrar Player Core:** caminar, correr, salto, caída, aterrizaje, control aéreo, cámara, colisiones y controles sin regresiones.
4. **Cerrar Steel/Iron targeting:** autoridad única, prioridad direccional, objetivo fijado por pulsación, rango común, selección de objetivos fuera de cámara cuando la intención lo justifique y ausencia de cambio silencioso de objetivo.
5. **Cerrar el modelo de masa y soporte:** una sola regla para Steel/Iron y objetos; diferenciar contacto, bloqueo y soporte real; evitar masas artificiales por mero contacto.
6. **Validar Steel traversal:** empujes discretos y legibles, momentum, selección correcta, caída y recuperación/trampoline aprobada, sin techo artificial del mundo.
7. **Validar Iron traversal inspirado en Ashes:** atracción dinámica hacia un ancla fijada, gravedad y momentum conservados, control aéreo razonable, liberación limpia y llegada a farolas sin teletransporte.
8. **Auditar Coin Jump contra el contrato de Steel:** Space salta; Space×2 invoca moneda cerca del pecho y aplica Steelpush hacia abajo; misma autoridad de fuerza, masa, soporte y rango. Investigar y eliminar cualquier diferencia no aprobada (por ejemplo, ventana especial fija de 0,78 s) si impide que sea realmente la misma interacción sostenida.
9. **Construir el lanzamiento ordinario de monedas:** apuntado dedicado, cámara lenta contextual, trayectoria prevista coherente con la física, lanzamiento real y recuperación de moneda.
10. **Separar objetivos y cámara:** objetivo de combate, objetivo alomántico y retícula no deben competir ni apropiarse del input unos de otros.
11. **Núcleo de combate cuerpo a cuerpo:** salud, daño, hitboxes/hurtboxes, ataque ligero/pesado, fases de ataque, recuperación, combos básicos y reacción física.
12. **Defensa legible:** parada, esquiva, bloqueo si se aprueba, contraataques y ataques con respuestas diferentes; nada de QTE como sustituto del sistema.
13. **Postura/equilibrio:** sistema inspirado en Sekiro para abrir oportunidades, con complejidad ajustada por arquetipo.
14. **Integración de Steel/Iron en combate:** empujar/tirar enemigos, interrupciones, proyectiles, choques, derribos y continuidad con traversal.
15. **Entorno como herramienta táctica:** paredes, bordes, farolas, armas y objetos con respuestas físicas claras; evitar una única habilidad dominante.
16. **IA de un guardia completo:** patrulla, visión, sospecha, investigación, alerta, persecución, combate, búsqueda, pérdida de contacto y retorno.
17. **Combate contra grupos:** coordinación flexible, amenazas legibles, ataques fuera de cámara con aviso razonable y ausencia de turnos rígidos artificiales.
18. **Arquetipos de enemigos:** defensivo, ágil, pesado y a distancia; cada uno cambia decisiones, no solo salud.
19. **Sigilo funcional:** ruido, distracciones con monedas, rutas, memoria de última posición y transiciones entre sigilo y combate.
20. **Derrota, reintentos y checkpoints:** decidir después de la encuesta; no copiar penalizaciones Souls por defecto.
21. **HUD y feedback:** salud, postura contextual, alerta, moneda, retícula, líneas, impactos y señales de ataque.
22. **Jefes:** patrones legibles, ventanas de castigo, fases significativas y respuestas alománticas específicas.
23. **Progresión y mejoras:** priorizar nuevas opciones jugables sobre aumentos numéricos; cerrar reglas solo después de validar el combate básico.
24. **Audio funcional:** avisos de ataque, impactos, alomancia, aterrizajes y detección.
25. **Arte conceptual:** hojas conceptuales de personaje, enemigos, objetos, ciudad y presentación para orientar decisiones. Sin producción de assets finales por ahora.
26. **Diseño de niveles y encuentros:** arenas, rutas, alturas y alternativas de aproximación; mantener la ciudad completa de Luthadel aparcada.
27. **Perfilado y optimización continua:** medir FPS, frame time, cuerpos activos, nodos, draw calls y memoria; no optimizar a ciegas.
28. **Mapa completo de Luthadel y streaming por celdas:** solo cuando se reactive la nota pendiente, y después de aprobar escala y probar traversal en una manzana.
29. **Pulido, accesibilidad y balance final:** solo tras cerrar el ciclo completo de combate y movimiento.

---

# PARTE III — CONTRATO DE MOVIMIENTO Y ALOMANCIA

## 6. Reglas compartidas actuales

Los valores siguientes son parámetros heredados del prototipo y **no equivalen a validación de sensación**. Deben probarse en Godot y pueden cambiarse con una prueba que justifique el cambio.

- Radio alomántico compartido actual: **35 m**.
- Fuerza base compartida: **1450 N**, sin aumento en `001_h`; se mantiene para aislar la calibración de trayectoria del aumento bruto de fuerza.
- `HERO_STRENGTH` actual: **1.20**.
- Límite actual de traversal: **34 m/s**.
- Steel e Iron son interacciones independientes.
- La autoridad compartida de fuerza, masa y soporte debe evitar resolver Steel, Iron y Coin Jump con sistemas de física duplicados.
- Contacto por sí solo no convierte un objeto en pesado. Debe existir bloqueo o soporte real en la dirección de fuerza.
- Ninguna altura máxima artificial del mundo se debe usar para ocultar fallos de traversal.

## 7. Steel

- Q inicia una adquisición nueva y fija un objetivo para esa pulsación.
- Mientras Q siga mantenida, la interacción permanece sobre ese objetivo; no se auto-retargetea.
- Soltar Q termina la interacción; la siguiente pulsación vuelve a adquirir.
- El Steel de traversal debe sentirse como empujes discretos y una caída controlable, no como vuelo infinito.
- Objetivo de feel aprobado para el prototipo: reacción inicial legible, aceleración suficientemente contundente y encadenamiento de impulsos a partir de anclajes; no introducir un segundo sistema de impulso oculto. La fuerza procede del resolver compartido.
- El selector debe descartar objetivos que hagan que la reacción del jugador vaya absolutamente hacia atrás respecto a la dirección horizontal deseada cuando ese criterio aplique.
- La dirección deseada de movimiento no debe quedar anulada por la velocidad vertical actual. La altura puede intervenir solo donde la especificación de feel lo permita, no como un criterio oculto de targeting.
- Steel debe contrarrestar la caída mediante fuerza alomántica real suficiente cuando la reacción ascendente recae en el jugador. No usar amortiguación directa de velocidad vertical ni suspender la gravedad para simular la captura.
- No auto-retarget mientras la tecla permanezca pulsada.

## 8. Iron

- E fija un ancla al iniciar la pulsación.
- La dirección de atracción se recalcula desde el origen alomántico actual del jugador hacia ese mismo ancla en cada tick físico.
- La fuerza se suma a la velocidad existente; no debe borrar perpendicular momentum.
- La gravedad permanece activa durante Iron salvo que una prueba de feel aprobada justifique una excepción muy localizada.
- WASD puede corregir moderadamente la trayectoria aérea sin reemplazar la atracción ni su velocidad.
- Objetivo de feel actualizado por el usuario: movimiento fluido inspirado en Spider-Man de Insomniac con una restricción física virtual de distancia máxima durante la travesía hacia anclajes fijos pesados. La línea azul alomántica visible parte del pecho y termina en el punto de conexión de la superficie metálica. Esto es una abstracción jugable inspirada por las líneas que percibe el alomántico; no se afirma que el canon las describa literalmente como una cuerda material.
- La cuerda virtual se calcula sobre la trayectoria del pecho, con una longitud máxima fijada al adquirir el ancla. Cuando se tensa, se elimina solo la velocidad radial que estiraría más la conexión, conservando el impulso tangencial; si hay sobreextensión por movimiento del ancla o integración temporal, se aplica una corrección limitada hacia el anclaje. Nunca se teletransporta al jugador ni se reinicia su vector completo de velocidad.
- La restricción solo se aplica a anclajes físicos fijos (StaticBody3D o RigidBody3D congelado). Los cuerpos metálicos móviles mantienen el resolver compartido de masa/soporte, evitando que el sistema de cuerda convierta objetos sueltos en anclas invisiblemente inmóviles.
- La gravedad completa permanece activa durante el modo de cuerda para producir un arco pendular legible. E suelta la conexión y conserva la velocidad alcanzada. WASD puede aportar aceleración tangencial controlada mientras la cuerda está activa.
- La línea visual utiliza una toma de origen en el pecho independiente del origen de cálculo de fuerzas (centro/cintura), para que el feedback canónico no altere el solver físico.
- La llegada contextual a una farola puede guiar al jugador alrededor del poste y hacia la superficie superior, pero no teletransportarlo. Solo termina cuando el soporte físico está confirmado y el jugador se ha asentado.
- Las puntas de las farolas son objetivos alománticos; el poste entero no debe captar la selección accidentalmente.

## 9. Targeting

- La adquisición y la interacción activa son responsabilidades separadas.
- El objetivo de combate no sustituye al objetivo metálico.
- Una acción fijada no cambia de objetivo en silencio.
- Las reglas de dirección deben usar el input horizontal previsto donde corresponda, no `velocity.y` como proxy de intención.
- Objetivos fuera de cámara pueden ser válidos para traversal si la dirección de reacción es la correcta; la cámara no debe actuar como muro invisible.
- Los candidatos inválidos por dirección se descartan antes de puntuarlos; legibilidad/cámara solo desempata candidatos ya válidos.
- El rango compartido de 35 m se aplica a Steel, Iron y las interacciones de moneda, salvo cambio aprobado explícitamente.

## 10. Masa, soporte y colisiones

- La regla de masa es binaria en el nivel jugable: el lado más ligero responde más; el lado efectivamente más pesado transfiere la reacción al otro.
- Para Steel: si el objetivo es más ligero que el jugador, el objetivo se desplaza; si es más pesado/efectivamente bloqueado, se desplaza el jugador.
- Para Iron: si el objetivo es más ligero, se acerca; si es más pesado/efectivamente bloqueado, el jugador se acerca al objetivo.
- Los bloqueadores y soportes pueden contribuir a masa efectiva mediante una cadena coherente. El mero contacto no basta.
- Regla de juego aprobada para Mistborn: una moneda que mantiene contacto firme con adoquín o tierra compactada se considera anclaje completo para Steel en cualquier dirección; no simular deslizamiento lateral de monedas apoyadas. Pierde el estado de anclaje cuando se comprueba que deja de tener soporte geométrico actual.
- Las colisiones deben ser verificables, estables y legibles para el jugador.

## 11. Coin Jump — contrato estricto

**Diseño aprobado:** Coin Jump no es un tercer poder ni un impulso manual independiente. Es el mismo Steelpush, con una forma de inicio distinta.

1. Primera pulsación de Space: salto normal.
2. Segunda pulsación válida de Space: invocar una moneda física cerca del pecho, fijarla como objetivo de esa acción y comenzar Steelpush sobre ella estrictamente hacia abajo.
3. No requiere Q ni Shift.
4. El empuje de la moneda debe usar la misma autoridad compartida de fuerza, masa/soporte y rango de Steel.
5. Cuando la moneda se apoya físicamente en el suelo, la respuesta de soporte puede transferirse al jugador para impulsar el ascenso, siguiendo el mismo resolver de interacción; no debe ser un impulso de velocidad escrito a mano.
6. Repetir Space×2 debe permitir una nueva moneda/acción sin que la anterior bloquee el input. Las monedas anteriores pueden permanecer como objetos físicos válidos.
7. No introducir un multiplicador de fuerza o un temporizador especial de duración que cambie la naturaleza de Steelpush sin aprobación explícita. Si la implementación actual usa una ventana temporal fija (la documentación histórica menciona 0,78 s), tratarlo como posible divergencia y probar si puede terminarse por las mismas condiciones de interacción que Steel.
8. No permitir que la moneda atraviese el suelo, quede bajo la geometría o active la reacción antes de que el contacto real esté confirmado.
9. La interacción no debe depender del aim de la cámara.

## 12. Allomantic Sight y líneas

- Allomantic Sight es percepción, no un selector de objetivo de traversal.
- Ctrl alterna Sight.
- Las líneas deben ser escasas, estables y visualmente claras. Las líneas de acción visibles nacen en el pecho; el origen de cálculo físico puede permanecer en el centro/cintura si así lo requiere el solver.
- Las líneas de acción y Sight pueden compartir renderer, pero Sight no debe robar input ni modificar la selección.
- El objetivo activo debe distinguirse por contraste/emisión, no solo por aumentar su grosor.
- No añadir líneas redundantes de Q/E ni efectos ruidosos o parpadeantes.
- La retícula central es discreta y no crea su propia lógica de targeting.

---

# PARTE IV — CONTRATO DE COMBATE

## 13. Filosofía de combate

Mistborn no será un Souls con poderes ni Spider-Man con monedas. El combate combinará:

- **Sekiro:** presión ofensiva, postura/equilibrio, precisión y defensa que crea oportunidades.
- **Sifu:** lectura espacial, paradas/esquivas con propósitos diferentes y uso del entorno.
- **Control:** objetos como herramientas físicas, con riesgo de que una habilidad domine todos los encuentros.
- **Spider-Man:** movilidad, cámara que facilita la lectura y herramientas contextuales; cámara lenta solo cuando una decisión de precisión lo merece.
- **Titanfall 2:** continuidad del impulso y capacidad de encadenar desplazamientos.
- **Dark Souls/Elden Ring:** compromiso de acciones, preparación legible, recuperación y castigo razonable por elegir mal; no copiar penalizaciones de muerte ni retrasos arbitrarios.
- **Devil May Cry 5:** profundidad para dominar combos, sin exigir un sistema de combos complejo para que el básico sea divertido.
- **Dishonored 2:** múltiples soluciones jugables para un mismo problema.

No se copian código, assets, animaciones ni contenido propietario. Se adaptan principios generales de diseño. Ninguna referencia se trata como autoridad absoluta.

## 13.1. Matriz completa de referentes: qué adoptar y qué descartar

| Referente | Adoptar | No copiar |
|---|---|---|
| Mistborn: Ashes Project | Fantasía de monedas, saltos, Steel/Iron y maniobras; estudiar cómo llega y se queda el personaje en objetos metálicos. | Dar por hecho que el prototipo público documenta o resuelve cada detalle físico necesario. La implementación exacta debe verificarse jugando/referenciando material disponible. |
| Marvel's Spider-Man Remastered | Movilidad, cámara fluida, entrada/salida de combate, herramientas tácticas y tiempo de decisión al apuntar cuando sea útil. | Ralentizar continuamente el combate o depender de herramientas que resuelvan todos los encuentros. |
| Sekiro | Postura, presión, precisión defensiva, interrupción y recompensa por dominar el ritmo. | Hacer que todos los enemigos requieran la misma respuesta de parry o que el juego castigue cada error con una cadena inevitable. |
| Sifu | Paradas/esquivas con propósitos distintos, control de grupos, lanzamientos y uso táctico del entorno. | Copiar sin adaptación una curva de aprendizaje abrupta o un esquema de controles que compita con Steel/Iron. |
| Control | Convertir objetos y física del entorno en herramientas ofensivas. | Permitir que una sola habilidad sea la solución óptima en casi todos los encuentros. |
| Titanfall 2 | Impulso, continuidad y encadenamiento de acciones de movimiento. | Importar un sistema de shooter sin adaptarlo a tercera persona, objetivos metálicos y combate cuerpo a cuerpo. |
| Dark Souls III / Elden Ring | Compromiso de acciones, preparación legible, recuperación, lectura del enemigo y castigo razonable. | Penalizaciones de muerte, recorridos repetidos obligatorios, esquiva como respuesta universal o retrasos arbitrarios que parezcan engañosos. |
| Devil May Cry 5 | Profundidad de combos y espacio para que el jugador exprese dominio. | Exigir combos complejos antes de que los golpes básicos sean satisfactorios. |
| Dishonored 2 | Libertad de aproximación, sigilo, poderes y rutas alternativas para resolver situaciones. | Crear rutas distintas visualmente pero idénticas en sus decisiones. |
| Batman: Arkham Knight | Lectura de amenazas, combate contra varios enemigos y transiciones claras de ataque. | Contraataques automáticos que permitan ganar sin leer los ataques. |
| God of War (2018) | Claridad del impacto, presentación de golpes y lectura del peligro. | Una cámara tan cerrada que perjudique traversal, verticalidad o percepción de enemigos. |
| DOOM Eternal | Presión, ritmo y decisiones constantes durante los encuentros. | Hacer que una mecánica de recuperación sea una obligación repetitiva que interrumpa el resto del juego. |
| Horizon Zero Dawn | Enemigos con vulnerabilidades y componentes que cambian la estrategia. | Puntos débiles arbitrarios que conviertan cada enemigo en una lista de tareas desconectada de su comportamiento. |
| Hades | Respuesta ágil, claridad de habilidades y combinaciones que hagan interesantes las repeticiones. | Convertir Mistborn en un roguelite solo porque el modelo de repetición funciona bien en Hades. |
| Ghost of Tsushima | Diferenciar respuestas ofensivas/defensivas por tipo de enemigo y mantener claridad de los intercambios. | Reducir todos los encuentros a una única secuencia de contraataque memorizada. |

Esta matriz es una biblioteca de patrones. No significa que cada sistema se implementará: la encuesta de Prioridad 1 debe decidir cuáles pertenecen al juego final.

## 14. Cuerpo a cuerpo

Cada ataque debe tener fases definidas: preparación, activo/impacto, recuperación y cancelaciones permitidas. Las hitboxes/hurtboxes deben determinar el contacto real. Un golpe no aplica daño repetidamente por una sola colisión.

- **Ligero:** rápido, recuperación corta, inicia presión y combos.
- **Pesado:** más lento, comprometido, mayor daño o interrupción y recuperación más vulnerable si falla.
- **Combos:** combinaciones legibles; las cancelaciones son explícitas y limitadas. No todo cancela todo.
- **Aéreo:** los ataques aéreos deben coexistir con traversal sin borrar momentum de forma arbitraria.
- **Impacto:** respuesta de cuerpo y cámara proporcional al evento; evitar sacudidas en cada golpe.
- **Lectura:** las animaciones comunican el momento y el área de peligro.

## 15. Defensa y postura

La parada, la esquiva y el bloqueo (si la encuesta lo aprueba) no son respuestas intercambiables.

- La parada requiere precisión y puede generar postura/ventaja.
- La esquiva reposiciona y evita ataques que no conviene parar.
- El bloqueo reduce riesgo, pero puede tener coste o ser ineficaz contra ciertos ataques si se decide así.
- Los agarres, ataques pesados y ataques de área pueden exigir respuestas distintas.
- No usar indicadores tipo QTE como sustituto del combate.

Postura/equilibrio sirve para medir estabilidad táctica además de salud. Golpes, paradas y alteraciones físicas pueden reducir postura. Al cruzar un umbral, el enemigo queda expuesto a una ventana de ataque. En enemigos menores se puede simplificar; en élites/jefes debe tener profundidad. No añadir una barra permanente en HUD cuando no aporta información.

## 16. Steel/Iron durante combate

Las interacciones alománticas no son simplemente ataques de daño. Pueden desplazar, interrumpir, desestabilizar, lanzar contra superficies, crear separación o cambiar la altura del encuentro. El resultado depende de masa, soporte, estado del enemigo, dirección y geometría.

- El guardia ligero debe responder de forma diferente al pesado.
- Un empuje que no hace daño aún puede crear una oportunidad táctica.
- Un enemigo puede resistir una interrupción por estado o peso, pero no ser inmune arbitrariamente.
- Un impacto contra pared/borde debe comprobar la colisión real y la velocidad.
- Cuerpo a cuerpo y alomancia deben encadenarse sin cortar artificialmente la movilidad.
- Ninguna habilidad debe ser la respuesta dominante a todos los enemigos.

## 17. Monedas como proyectiles y herramientas de sigilo

El lanzamiento ordinario de monedas tiene un modo dedicado de apuntado. Al entrar en él, el tiempo del mundo se ralentiza, como preferencia de diseño del usuario inspirada en su experiencia con Ashes Project. Como valor inicial de prueba puede usarse aproximadamente el 25 % de velocidad, pero no se considera definitivo hasta jugarlo.

- El input y la cámara siguen respondiendo normalmente durante la ralentización.
- La trayectoria previa debe aproximarse a la física real, incluyendo gravedad y obstáculos.
- La confirmación lanza una moneda física real y devuelve la simulación a tiempo normal.
- La cámara no debe saltar ni girar automáticamente hacia objetivos no seleccionados.
- El modo no debe durar indefinidamente ni pausar por completo el riesgo.
- La cámara lenta se reserva al apuntado de monedas; no ralentizar el mundo para cada ataque, Steel o Iron.
- Una moneda puede distraer por ruido, golpear, rebotar y recuperarse si las reglas físicas lo permiten.
- No hacer que una moneda revele automáticamente al jugador si el enemigo solo ha oído un ruido.

## 18. Cámara y objetivos

Mantener separados:

1. **Objetivo de combate:** enemigo al que se fija o se sigue.
2. **Objetivo alomántico:** objeto metálico que recibe Steel/Iron.
3. **Punto de apuntado de moneda:** lugar o trayectoria que el jugador decide al lanzar.

La cámara debe mantener lectura del personaje, enemigos y espacio vertical, evitar atravesar geometría, suavizar transiciones y no quitar control. Debe adaptarse a uno o varios enemigos sin convertirse en una cámara fija de arena. La ralentización de moneda debe ser una transición suave y reversible.

## 19. Enemigos e IA

### Guardia básico

Debe tener estados claros: patrulla, sospecha, investigación, alerta, persecución, combate, búsqueda, pérdida de contacto y regreso a patrulla. La visión utiliza línea de visión y oclusión reales. El enemigo recuerda una última posición conocida, no la posición actual del jugador detrás de una pared.

Debe poder acercarse, mantener distancia, preparar ataques, atacar, recuperar, reaccionar a impactos, ser interrumpido o derribado, levantarse, buscar y dejar de buscar si el jugador escapa válidamente.

### Coordinación de grupos

Varios enemigos pueden presionar, flanquear o reposicionarse, pero no todos deben atacar a la vez sin lectura ni esperar en una cola rígida. Los ataques fuera de cámara necesitan señales razonables. La coordinación debe crear presión sin trampas.

### Arquetipos

- **Defensivo:** guarda posiciones, protege aperturas y exige un ángulo o ruptura de defensa.
- **Ágil:** reposiciona y castiga ataques comprometidos.
- **Pesado:** tolera mejor ciertos desplazamientos y castiga con ataques comprometidos.
- **A distancia:** obliga a cerrar distancia, cubrirse o usar rutas verticales.
- **Élite/jefe:** patrones diferenciados, fases significativas, ventanas claras y reacciones alománticas específicas.

La diferencia entre arquetipos debe cambiar decisiones, no ser solo salud/daño.

## 20. Sigilo y encuentros

- Ruido de pasos, aterrizajes, monedas e impactos según contexto.
- La sospecha precede a la alerta total.
- Un guardia investiga el origen de un sonido si no vio la fuente.
- Otros guardias reaccionan si presencian un suceso o reciben información válida.
- El jugador puede iniciar un encuentro desde tejados, calle, altura o sigilo.
- El jugador puede escapar y regresar al sigilo si rompe el contacto; no debe exigirse matar a todos.
- Las rutas deben ofrecer alternativas tácticas, no ser solo rutas visualmente distintas.

## 21. Salud, derrota y progresión

No decidir reglas definitivas de muerte, checkpoints, penalizaciones, recursos, árbol de habilidades o economía antes de la encuesta. No adoptar por defecto pérdida de recursos o repetición de recorridos Souls.

La progresión debe priorizar nuevas opciones de juego (maniobras, enlaces de combo, control posicional, herramientas de sigilo) frente a aumentos estadísticos planos. La progresión no puede ser necesaria para que el combate básico sea satisfactorio.

---

# PARTE V — PRESENTACIÓN, ARTE CONCEPTUAL Y RENDIMIENTO

## 22. HUD y feedback

La información debe ser contextual y jerarquizada: salud, alerta, estado del enemigo, postura cuando importa, monedas disponibles, retícula, objetivo y señales de ataque. La retícula central es pequeña, estable y no crea lógica propia.

Señales de audio/visual recomendadas: preparación de ataques, paradas, golpes ligeros/pesados, choques, apuntado de moneda, activación Steel/Iron, contacto/aterrizaje, detección y pérdida de contacto. Las señales sonoras complementan la imagen y no deben ser el único medio para leer amenazas.

## 23. Arte solo conceptual

En esta fase se pueden crear moodboards, siluetas, hojas de concept art, esquemas de materiales, color script conceptual y referencias visuales para comunicar la dirección. No se implementará una tubería de arte final ni se modelará una gran biblioteca de assets hasta que el diseño jugable y la encuesta lo justifiquen.

Dirección conceptual deseada: estilizada, atmosférica, con siluetas urbanas ricas y materiales legibles, inspirada en el nivel de acabado pictórico de juegos de alta calidad sin copiar personajes, assets ni diseños protegidos. La optimización no debe convertirse en una excusa para un mundo insípido de cubos.

## 24. Rendimiento

- Objetivo de diseño: estabilidad y respuesta en el equipo objetivo; el objetivo numérico de FPS debe fijarse en la encuesta y validarse con métricas.
- Medir FPS promedio/mínimo, frame time, memoria, nodos activos, cuerpos físicos, draw calls y número de enemigos/monedas simultáneos.
- Usar colisiones simples y estables; la silueta visible puede ser más detallada.
- Reutilizar objetos cuando compense, limitar física activa de objetos lejanos y evitar nodos innecesarios por frame.
- No introducir streaming de ciudad hasta que el mapa se reactive.
- No regenerar el mundo completo cada frame.
- Cada optimización debe preservar el resultado visual y jugable; comparar antes/después con métricas.

---

# PARTE VI — PROMPT MAESTRO DE IMPLEMENTACIÓN

## 25. Prompt que rige cada tarea futura

> Trabaja como ingeniero principal de gameplay y director de diseño del proyecto Mistborn en Godot 4.7.2. Lee este documento maestro antes de modificar el proyecto. Este documento es la única autoridad normativa de diseño. Si el código actual, comentarios o documentos antiguos lo contradicen, señala la discrepancia y sigue el contrato aprobado aquí.
>
> **Objetivo:** implementar la siguiente prioridad no completada de la lista de la sección 5, considerando primero las respuestas aprobadas de la encuesta. El objetivo no es producir más código: es obtener un resultado jugable que cumpla el criterio de aceptación.
>
> **Antes de tocar código:**
> 1. Identifica el ZIP/base exacta recibida y el estado de la rama.
> 2. Lee el contrato de los sistemas implicados dentro de este documento.
> 3. Inspecciona escenas, scripts, señales, inputs, recursos y dependencias que intervienen en el comportamiento.
> 4. Describe la causa raíz esperada, los archivos que cambiarás, los riesgos y una prueba de aceptación observable.
> 5. No cambies sistemas no relacionados. Si encuentras un problema lateral, regístralo para un paso separado salvo que bloquee la tarea.
>
> **Implementación:**
> - Realiza un cambio principal pequeño y reversible.
> - Mantén una autoridad única para cada responsabilidad (input, targeting, fuerza, salud, estado de enemigo, cámara, etc.).
> - No dupliques sistemas de fuerza o estado para resolver un caso especial; comparte el resolver y cambia solo la forma de iniciar la acción cuando el diseño lo requiera.
> - No uses constantes temporales o multiplicadores especiales para tapar una interacción mal modelada.
> - Mantén colisiones, estado físico y feedback visual coherentes.
> - No añadas historia ni metales fuera de alcance. Arte final fuera de alcance; solo concept art.
> - No amplíes el mapa de Luthadel mientras su anotación siga aparcada.
>
> **Verificación obligatoria:**
> 1. Revisa el diff y elimina restos de la implementación sustituida cuando ya no tengan función.
> 2. Ejecuta comprobaciones estáticas de tipos, referencias, recursos, señales, entradas, rutas y sintaxis.
> 3. Ejecuta las pruebas automatizadas relevantes y añade regresiones para el comportamiento corregido.
> 4. Si Godot está disponible, abre/parsea el proyecto y ejecuta la escena y pruebas. Si no está disponible, dilo explícitamente y no afirmes que se ejecutó.
> 5. Comprueba errores/warnings nuevos, estados inválidos, colisiones, repetición de acciones, input sostenido, cancelación, pérdida de objetivo y casos límite.
> 6. Evalúa el resultado contra el criterio de aceptación. El análisis estático no demuestra feel.
>
> **Entrega:**
> - Empaqueta el proyecto completo en un ZIP con nombre simple, sin `%` ni nombres URL-encoded.
> - No sobrescribas el último ZIP estable; conserva el rollback.
> - Elimina documentación obsoleta solo después de transferir su conocimiento vigente a este documento o a una nota explícitamente aparcada.
> - Actualiza BUILD_ID/VERSION y el README mínimo.
> - Resume: cambio realizado, archivos tocados, pruebas realmente ejecutadas, limitaciones, resultado de cada criterio, riesgos conocidos y el siguiente paso exacto.
> - No digas «terminado» si el usuario todavía debe validar una sensación de juego que no puede probarse automáticamente.
>
> **Regla de continuidad:** cuando el usuario diga «prosigue», interpreta que ha probado el último ZIP, pero pide o utiliza su feedback real si el resultado depende de una sensación que no se ha descrito. Antes de implementar, declara el siguiente paso exacto. Si un sistema se comporta mal, corrige la causa raíz o reconstruye el módulo afectado; no apiles parches.

---

# PARTE VII — VALIDACIÓN Y ESTADO ACTUAL

## 26. Pruebas de aceptación mínimas

### Proyecto y Player Core
- El proyecto abre en Godot 4.7.2 sin errores de parseo.
- WASD mueve al personaje y no mueve la cámara por error.
- Salto, coyote time, jump buffer, aterrizaje y control aéreo se comportan de forma consistente.
- Perfil provisional del salto 001_h: velocidad inicial 5,75 m/s y gravedad 14 m/s², para conservar una altura cercana al salto anterior y acortar el tiempo de vuelo. Aceptación funcional: altura de 0,95–1,45 m y tiempo aéreo aproximado de 0,55–0,92 s en el fixture, más revisión manual de la sensación.
- La cámara sigue al jugador sin quitar control ni atravesar geometría.

### Steel/Iron
- Q/E adquieren un objetivo válido y no cambian silenciosamente de objetivo mientras se mantienen.
- La dirección de reacción coincide con la intención aprobada.
- Soltar corta la fuerza y conserva la inercia esperada.
- La masa/soporte responde de manera coherente a objetos libres, bloqueados y apoyados.
- La interacción respeta los 35 m actuales.
- Llegar a una farola no teletransporta al jugador y confirma soporte físico real.

### Coin Jump y moneda ordinaria
- La primera Space salta; Space×2 invoca la moneda y ejecuta Steelpush descendente.
- La interacción usa el resolver compartido, sin un impulso manual ni multiplicador secreto.
- Dos Coin Jumps consecutivos crean acciones independientes válidas.
- La moneda no atraviesa el suelo ni activa soporte antes del contacto confirmado.
- El apuntado ordinario ralentiza el mundo, permite ajustar aim y dispara un objeto físico con trayectoria coherente.

### Combate/IA cuando estén implementados
- Un golpe aplica daño una sola vez por impacto.
- Ataques, paradas, esquivas e interrupciones tienen ventanas legibles.
- Steel/Iron afectan a enemigos según el resolver físico compartido.
- El guardia no ve a través de paredes, investiga sonidos y puede perder el contacto.
- Los arquetipos cambian decisiones tácticas.
- No hay bloqueos invisibles sin justificación espacial ni estados permanentes de IA.

### Rendimiento
- Registrar escena, configuración, duración y hardware de cada medición.
- Comparar frame time y mínimos, no solo FPS promedio.
- Repetir el test con el mismo número de objetos/enemigos antes y después de optimizar.

## 27. Estado técnico heredado y límites de certeza

El ZIP base utilizado para esta consolidación es `Mistborn_001_a_SteelCoinJumpSustainedSteelpush_001.zip`, con la nota de mapa recuperada de `Mistborn_001_a_SteelCoinJumpSameSteelpush_001_MapNote.zip`. Los valores y contratos técnicos de este documento describen la intención vigente o parámetros heredados, no certifican que todas las mecánicas funcionen en ejecución.

La documentación anterior indica que se hicieron revisiones estáticas y pruebas automatizadas relacionadas con Player Core y Coin Jump. **No se ha certificado aquí una ejecución real de Godot 4.7.2 ni el feel de juego.** La siguiente prioridad técnica después de la encuesta es abrir esta base en Godot, ejecutar el proyecto y comprobar los criterios de la sección 26.

Se eliminaron las rutas antiguas de impulso único y el helper de Iron con vector fijo, que ya no formaban parte del flujo activo; Steel/Iron y Coin Jump deben utilizar la interacción sostenida compartida. La implementación activa todavía menciona una ventana de 0,78 s para la fase apoyada de Coin Jump. Como el contrato aprobado exige que Coin Jump sea el mismo Steelpush y solo difiera en el inicio, esa ventana activa debe auditarse expresamente y no asumirse correcta por estar en el código.

### Iteración 001_h — calibración de movimiento (pendiente de prueba manual)

Tras una ejecución real anterior con 28/28 pruebas aprobadas, el usuario informó que la cámara era aceptable, que el salto se sentía demasiado flotante y que Steel/Iron funcionaban de manera intuitiva pero no divertida. `001_h` reduce el tiempo de vuelo del salto con gravedad más alta y velocidad inicial ajustada, mantiene la fuerza base compartida de 1450 N y acelera la corrección direccional aérea durante traversal de 9 a 12. Se crea `scenes/movement_lab.tscn` con un circuito dedicado para salto, Steel, Iron, Coin Jump, caída/recuperación y masa. Steel usa una prioridad ascendente algo mayor dentro de la asistencia aérea ya existente (0,55 -> 0,64), sin crear otro resolver ni aumentar la fuerza base compartida. Iron deja de girar directamente la velocidad horizontal hacia WASD y añade una aceleración tangencial pequeña (7 m/s² máximo, solo en aire y con entrada direccional), sin tocar gravedad ni sustituir la fuerza radial compartida. Se añade una prueba matemática de la proyección al plano tangente.

Esto es una hipótesis de feel, no una afirmación de que ahora sea divertido. `001_h` no se ha ejecutado todavía en Godot durante esta preparación. Hay que correr la batería de QA y probar manualmente el circuito antes de congelar los nuevos valores. El laboratorio usa primitivas y sombras dinámicas apagadas para respetar el hardware conocido (i3-7100U, Intel HD Graphics 620, 16 GB RAM).


## 28. Referentes de diseño y fuentes para consulta

Estas fuentes son referencias de principios de diseño, no especificaciones técnicas ni evidencia de que todos los jugadores prefieran cada mecánica. Las reseñas agregadas reflejan satisfacción general del juego, no causalidad de una característica individual.

- **Mistborn: Ashes Project** — página pública del prototipo y su intención alomántica: https://ashesproject.carrd.co/ . La ralentización del apuntado de moneda es una preferencia expresada por el usuario y un requisito del diseño de Mistborn; no se afirma que la página pública documente todos sus detalles.
- **Marvel's Spider-Man Remastered** — reseñas generales: https://store.steampowered.com/app/1817070/Marvels_SpiderMan_Remastered/
- **Sekiro: Shadows Die Twice** — reseñas generales: https://store.steampowered.com/app/814380/SEKIRO_SHADOWS_DIE_TWICE/
- **Sifu** — reseñas y comentarios de jugadores: https://store.steampowered.com/app/2138710/Sifu/
- **Control Ultimate Edition** — reseñas generales: https://store.steampowered.com/app/870780/Control_Ultimate_Edition/
- **Titanfall 2** — reseña de GameSpot sobre movimiento: https://www.gamespot.com/reviews/titanfall-2-review/1900-6416561/
- **Dark Souls III** — reseñas generales: https://store.steampowered.com/app/374320/DARK_SOULS_III/
- **Dishonored 2** — entrevista sobre elección del jugador: https://www.theguardian.com/technology/2015/jul/10/dishonored-2-harvey-smith-player-choice-arkane-studios
- **Devil May Cry 5** — reseñas generales: https://store.steampowered.com/app/601150/Devil_May_Cry_5/
- **God of War (2018)** — reseñas generales: https://store.steampowered.com/app/1593500/God_of_War/
- **DOOM Eternal** — reseñas generales: https://store.steampowered.com/app/782330/DOOM_Eternal/
- **Hades** — reseñas generales: https://store.steampowered.com/app/1145360/Hades/
- **Horizon Zero Dawn** — reseñas generales: https://store.steampowered.com/app/1151640/Horizon_Zero_Dawn_Complete_Edition/
- **Ghost of Tsushima** — reseñas y discusiones: https://store.steampowered.com/app/2215430/Ghost_of_Tsushima_DIRECTORS_CUT/
- **Batman: Arkham Knight** — reseñas generales: https://store.steampowered.com/app/208650/Batman_Arkham_Knight/

Los debates de Reddit citados en la investigación anterior son indicios cualitativos de preferencias y críticas, no encuestas representativas. Antes de adoptar una mecánica controvertida, prototiparla y compararla con una alternativa.

---

# REGLA FINAL

La encuesta establece qué juego vamos a construir. Este documento convierte las respuestas en un contrato. El roadmap decide qué construir primero. El código es una implementación revisable. Las pruebas determinan si funciona. La validación del jugador determina si se siente como Mistborn.

**No volver a multiplicar documentos de diseño paralelos.** Cambiar este archivo cuando una decisión se apruebe o cambie; dejar las notas históricas fuera del paquete de desarrollo salvo la anotación explícitamente aparcada del mapa.


### Iteración 001_i — instrumentación de Jump Buffer

La ejecución real de `001_h` produjo 28 PASS y 1 FAIL, concentrado en `PLAYER_CORE_JUMP_BUFFER`. El salto normal pasó (altura medida 1,23 m; 0,817 s de aire), y los otros 27 criterios funcionales pasaron. La prueba anterior podía confundir un frame de contacto ya apoyado con un frame aéreo dentro de la ventana: calculaba `remaining_time = 0` al aterrizar y no excluía `is_on_floor()`. Después observaba primero el siguiente estado de suelo y podía pasar por alto un segundo salto ya iniciado durante el helper de pulsación. `001_i` refina solo la prueba: exige que la muestra de entrada esté realmente en el aire, registra tiempo estimado a aterrizaje, coyote restante y buffer restante, y observa el impulso ascendente tras una sola actualización de entrada. **No se cambia la lógica de salto ni se afirma todavía que Jump Buffer funcione en runtime**; el nuevo registro de Godot debe confirmarlo. La causa raíz queda clasificada como fallo probable de instrumentación, pendiente de confirmación mediante la nueva ejecución.


## Addendum 001_j — Ciudad de movimiento y ajuste de traversal (2026-10-10)

Este addendum documenta las prioridades aprobadas por el usuario para la iteración `001_j`; no declara que el código se haya validado en runtime.

### Ciudad de prueba
- Se autoriza sustituir la escena principal de laboratorio por una mini-ciudad densa y navegable, con calles, tejados, rampas, pasarelas, agujas distantes, ventanas cálidas y ceniza ambiental. No reactiva el proyecto completo de mapa de Luthadel, que continúa fuera de alcance.
- La dirección artística toma como referencia los principios publicados por Ashes Project (gritty, oppressive, contrast, stylized reality), pero no se reutilizan código, modelos, mapas, materiales ni otros archivos del proyecto ajeno.
- Los anclajes metálicos deben ser grandes, legibles y fáciles de seleccionar a distancia razonable. Las superficies de aterrizaje deben tener colisión real; un marco visual no se considera una plataforma si no tiene un soporte físico explícito.
- Optimizar la ciudad para Intel HD 620 y GL Compatibility: primitivos, MultiMeshes para decoración repetida, pocas luces puntuales sin sombras dinámicas, sin assets pesados por requisito.

### Iron: traversal con trayectoria y caída legible
- Al mantener E se conserva el ancla adquirida; la fuerza continúa siendo una atracción dinámica hacia ese ancla y se suma a la velocidad existente.
- WASD puede añadir una corrección tangencial limitada en el aire, no reemplazar la atracción radial ni imponer una cuerda/órbita.
- Si el jugador está en el aire y mantiene Iron contra un ancla cuya masa alomántica es igual o superior a la del jugador, puede activarse una asistencia gravitatoria estrictamente local: gravedad sigue activa, pero su aceleración se reduce y la velocidad de caída se limita. Al soltar Iron o cambiar a un objetivo ligero, se restaura la gravedad normal sin borrar la velocidad acumulada.
- En `001_j` los valores iniciales de esta asistencia son 22% de gravedad y límite de caída de 3,8 m/s. Son parámetros de feel para probar y ajustar, no constantes canónicas.

### Steel: asistencia frontal restringida
- La dirección base de Steel sigue proviniendo del objetivo y del solver compartido de fuerza/masa/reacción. No se redirige el vector físico hacia la intención lateral o hacia atrás del jugador.
- Solo se permite una asistencia frontal sutil cuando el jugador mantiene W, no expresa intención lateral, está en el aire y la reacción física natural ya apunta hacia delante. El movimiento A/D/S sigue siendo responsabilidad del controlador de movimiento del jugador.
- La fuerza base y el rango compartidos no deben aumentarse solo para compensar el feel.

### Coin Jump: magnitud regulada por la duración de la interacción
- Primera pulsación de Espacio: salto normal. Segunda pulsación dentro de la ventana reconocida: moneda física y Steelpush hacia abajo mediante el solver compartido.
- Mantener la segunda pulsación mantiene la aplicación de fuerza; soltarla termina esa fuerza. Así el jugador puede decidir cuánto prolonga el impulso sin introducir un multiplicador ni una duración fija exclusiva de Coin Jump.
- La moneda sigue siendo física y recuperable después de soltar. Una fuerza interrumpida antes del contacto real con el suelo no garantiza una respuesta de apoyo; el impulso de rebote depende de la interacción válida con ese soporte.
- Las monedas de acciones repetidas se gestionan independientemente y no bloquean la creación de una acción nueva.

### Validación obligatoria
Esta especificación registra la dirección deseada; para considerarla cumplida hace falta ejecutar el proyecto en Godot 4.7.2, comprobar los errores de scripts y probar manualmente selección, altura, caída, continuidad de inercia, llegada al tejado y rendimiento del equipo objetivo.


## Addendum 001_k — historial supersedido

La iteración 001_k separó inicialmente la travesía y el tirón pesado mediante tap/hold y una postura S+E. Esa interfaz se probó solo como hipótesis de implementación y se considera **supersedida por 001_l**: E no debe esperar un umbral temporal para iniciar la travesía ni depender de una combinación direccional para tirar de un objeto.

## Addendum 001_l — Iron traversal de respuesta inmediata (2026-10-11)

Este addendum define la iteración de control y feel. Sus valores son parámetros de prototipo pendientes de validación manual; no certifican una sensación equivalente a Spider-Man.

### Controles y responsabilidad
- **E / botón lateral del ratón ya asignado a Iron:** adquiere un objetivo una sola vez al comenzar la pulsación. Si el objetivo es un anclaje o tiene masa efectiva igual o superior a la del jugador, Iron inicia la travesía inmediatamente; no hay ventana tap/hold ni retarget silencioso.
- **F o botón derecho del ratón (`iron_yank`):** atrae un `RigidBody3D` móvil cuya masa sea igual o superior a la del jugador. La fuerza se aplica al objeto, el objetivo permanece fijado y, en el suelo, el jugador amortigua su velocidad horizontal para resistir el tirón. Si el objetivo no cumple esos criterios, la entrada se consume sin elegir otro objetivo durante la misma pulsación.
- Los objetivos ligeros siguen utilizando el resolver compartido de masa/soporte y E; no se duplica ese solver.
- La travesía y el tirón de objeto son dos intenciones internas del mismo poder Iron. `iron_yank` no bloquea la locomoción normal del jugador como si fuera una acción de desplazamiento.

### Feel de Iron traversal
- En el primer frame de una travesía hacia un objetivo pesado, se añade una velocidad inicial de hasta 7,5 m/s en dirección al objetivo. El impulso se suma al vector de velocidad existente; nunca lo sustituye. El resultado se limita a la velocidad máxima de traversal compartida (34 m/s).
- La atracción continua sigue utilizando el resolver alomántico compartido de fuerza, rango y masa. El impulso de salida es una respuesta inicial de control, no un segundo sistema sostenido de fuerzas.
- El control lateral en el aire se proyecta sobre el plano tangente al radio objetivo para cambiar la trayectoria sin girar directamente todo el vector radial; la aceleración tangencial máxima inicial es 12 m/s².
- Durante la fase descendente de Iron contra objetivos pesados, la gravedad conserva el 72% de su aceleración normal y el límite de caída provisional es 18 m/s. Esto reemplaza el ajuste excesivamente flotante anterior (22% y 3,8 m/s) para favorecer trayectorias con más inercia. Al soltar Iron se restaura la gravedad normal sin borrar velocidad.
- La liberación conserva la velocidad real; no se fuerza una parada ni una llegada automática. La llegada guiada solo se mantiene para superficies que declaran explícitamente que el jugador puede posarse sobre ellas.
- **Límite de la iteración 001_l (histórico, supersedido por 001_m):** no implementaba una cuerda física. Su atracción rápida, control tangencial e inercia son la base de prototipo anterior; el addendum 001_m incorpora la restricción virtual descrita a continuación. La equivalencia de feel sigue pendiente de ejecución y ajuste en Godot.

### QA y aceptación
- La batería estática debe comprobar que el impulso inicial suma al vector previo y respeta el límite de velocidad, que una dirección inválida no crea velocidad y que `iron_yank` existe en InputMap.
- En ejecución, mantener E debe propulsar desde el primer frame; soltarlo no puede detener al jugador de golpe.
- En ejecución, mantener F/botón derecho sobre el cajón móvil de 120 kg debe acercar el objeto y no propulsar al jugador. El objeto objetivo no puede cambiar hasta soltar.
- Probar el circuito con W/A/S/D mientras se mantiene Iron: la entrada lateral debe curvar el trayecto sin anular el impulso radial.
- Ejecutar las pruebas con Godot 4.7.2 y recorrer manualmente la ciudad. Hasta entonces, los parámetros y el feel permanecen pendientes de validación.


## Addendum 001_m — línea azul y cuerda virtual de Iron (2026-10-11)

**Estado:** implementación de prototipo; revisión estática y pruebas matemáticas añadidas, pero no aceptada como feel final hasta ejecutar Godot 4.7.2.

### Decisión de diseño
- Las líneas visibles de acción Steel/Iron parten de un socket visual del pecho. Se separa este punto del origen físico del solver para no alterar las fuerzas ya existentes.
- Al adquirir un anclaje fijo pesado con E, la conexión activa termina en la superficie real del collider cuando una prueba de raycast identifica de forma inequívoca el cuerpo objetivo; si no, utiliza el punto de acción existente.
- Iron Heavy crea una restricción virtual de distancia máxima entre el pecho y el anclaje fijo. La longitud se fija al conectar y se mantiene durante esa conexión.
- Cuando el cable está tenso, se elimina el componente radial de velocidad que aumentaría la longitud, pero se conserva el componente tangencial. Si la distancia ya excedió la longitud debido al movimiento del objetivo o al paso temporal, la corrección radial hacia el anclaje es limitada por parámetros configurables.
- Un radio de seguridad pequeño evita que la corrección de cuerda empuje el punto de origen del pecho a través del anclaje. El cuerpo físico del jugador y sus colisiones siguen siendo la autoridad final sobre contactos reales.
- Mientras la cuerda está activa, se conserva gravedad completa; la combinación de gravedad, velocidad inicial, control tangencial y limitación radial debe generar el arco. Soltar E desactiva la restricción y conserva la velocidad.
- La cuerda no es un RigidBody, no tiene colisiones propias ni se dibuja como una telaraña blanca: el hilo azul activo existente se reutiliza y su extremo sigue el punto de unión físico.
- Solo los StaticBody3D, los RigidBody3D congelados y los anclajes lógicos sin cuerpo físico entran en el controlador de cuerda. Los RigidBody3D móviles siguen usando el resolver de masa/soporte.

### Parámetros de prototipo
- `physical_tether_enabled`: habilita el controlador.
- `physical_tether_minimum_length`: longitud mínima permitida al iniciar una conexión muy cercana.
- `physical_tether_tangent_launch_speed`: impulso adicional limitado en el plano tangencial si el jugador ya expresa una dirección WASD al engancharse.
- `physical_tether_correction_gain` y `physical_tether_max_inward_correction_speed`: estabilizan una extensión fuera de la longitud máxima sin borrar la velocidad tangencial.

### Pruebas y aceptación
- La prueba matemática `IRON_PHYSICAL_TETHER_MATH` comprueba: eliminación de velocidad radial hacia fuera al tensarse la cuerda, conservación de velocidad tangencial, corrección de sobreextensión, preservación de velocidad hacia dentro y salvaguarda de distancia mínima.
- Ejecutar `tools/run_player_core_playtest.bat` con Godot 4.7.2. El resultado debe incluir `IRON_PHYSICAL_TETHER_MATH` aprobado y cero errores de parser.
- En la ciudad, mantener E sobre un anclaje alto y fijo: la línea debe salir del pecho y terminar en la superficie metálica; al tensarse, el jugador debe describir un arco en vez de seguir acelerando radialmente a través del ancla. WASD lateral debe alterar el arco; soltar E debe separar el hilo sin frenar el momentum.
- Probar un objeto metálico móvil: E no debe fijarlo con una cuerda; F/botón derecho sigue siendo la acción explícita para atraerlo hacia el jugador.
- **No se afirma feel Spider-Man validado** hasta completar las pruebas en el motor y una pasada manual por el circuito.

### Corrección Steel 001_n — histórico, supersedido en 001_p

El principio de comprobar el destinatario real de la reacción sigue vigente. Las instrucciones de amortiguación tipo trampoline quedan fuera de la implementación activa: no se debe atenuar directamente la velocidad vertical ni suspender la gravedad en la solución actual. En 001_p, la caída se contrarresta por una fuerza Steel real ampliada a través del resolver compartido, con gravedad normal y una escala de fuerza mantenida durante la acción para evitar que desaparezca al llegar a velocidad vertical cero. El trampolín no queda descartado para siempre; su eventual reconsideración de prioridad muy baja se especifica en el addendum 001_q.



### Steel 001_o — anclaje de monedas sobre suelo firme

- Una moneda en el aire conserva su masa ligera: Steel la empuja como proyectil y no la trata prematuramente como anclaje.
- Cuando una moneda establece contacto geométrico firme con el suelo de la ciudad (adoquines/tierra compactada representados por `coin_ground_mask`), Steel la trata como completamente anclada, independientemente de si la línea de empuje es vertical, diagonal o lateral.
- No se simula deslizamiento lateral de monedas sobre el terreno ordinario. Esta es una decisión de fidelidad/legibilidad del juego basada en la representación usual del suelo de Scadrial.
- `MistbornCoin.has_firm_ground_anchor_for_steel()` usa una prueba de raycast estrecha respecto al punto más bajo de la moneda y verifica una normal de suelo; no reutiliza el indicador de contacto del proyectil sin validarlo, para evitar que una moneda que cayó de un borde permanezca anclada para siempre.
- `MistbornAllomanticForceModel.grounded_coin_anchor_mass()` centraliza la política: solo Steel + target type `COIN` + contacto firme devuelven masa de anclaje estático. Iron y otros objetos no reciben esta excepción.
- Esta regla se consulta tanto en la predicción de destinatario como en la aplicación de fuerza, para que Coin Jump, Steel normal y la transición de moneda en el aire a moneda apoyada usen la misma autoridad.
- Prueba determinista: `STEEL_GROUNDED_COIN_ANCHOR_POLICY`. Pendiente validación real dentro de Godot 4.7.2.


### Addendum 001_p — Steel counter-fall, Coin Jump unificado e intercambio Iron/Steel

**Estado:** implementación integrada y revisión estática pendiente de compilación/ejecución real en Godot 4.7.2. El usuario no puede ejecutar el motor por ahora; el feel no se declara aprobado.

#### Steel contrarresta una caída mediante fuerza real
- Se retira de la implementación activa cualquier “trampoline brake” que modifique directamente `velocity.y` o suspenda la gravedad. La gravedad normal permanece activa. El posible trampolín futuro queda como contingencia de prioridad MUY BAJA (P4) en 001_q, no como una opción prohibida permanentemente.
- Cuando el resolver compartido determina que Steel transmite su reacción al jugador, y la dirección de reacción tiene una componente vertical ascendente suficiente mientras cae, `MistbornAllomanticForceModel.calculate_steel_counterfall_strength()` calcula una fuerza efectiva mayor con una ventana de frenado ajustable.
- La escala extra queda enclavada durante la acción mantenida después de activarse. No desaparece cuando `velocity.y` cruza cero: de otro modo la gravedad reiniciaría la caída y podría producir jitter de captura/liberación. Se restablece al terminar la acción o cuando la reacción vuelve al objetivo.
- Los objetivos ligeros libres continúan recibiendo el empuje; no activan el refuerzo de caída del jugador. Una moneda apoyada firmemente en adoquines/tierra es anclaje completo para Steel con cualquier dirección de empuje, según la decisión 001_o; Iron no recibe esta excepción.

#### Coin Jump es Steel, no un tercer poder
- Espacio×2 crea/selecciona la moneda y establece el objetivo de acción Steel activo. La línea alomántica apunta a esa moneda desde el mismo renderer que Steel normal.
- La fase de caída empuja la moneda hacia abajo con el resolver y la fuerza compartidos, sin dar un impulso manual al personaje.
- En el primer tick con contacto firme con el terreno, la moneda pasa a ser anclaje Steel. La misma pulsación sostenida continúa aplicando Steel, y la respuesta se transmite al jugador a través del mismo resolver; no hay un temporizador de rebote ni una asignación directa a la velocidad del jugador.
- Coin Jump usa los mismos parámetros de fuerza, masa, alcance, telemetría y escala de contra-caída que el Steel normal. Su única diferencia es el selector contextual del objetivo: la moneda propia que se empuja hacia el suelo.
- La acción termina al soltar Espacio, perder el objetivo o salir del alcance válido; la moneda permanece en el mundo como moneda física.

#### Intercambio de Iron y Steel
- La última acción primaria pulsada entre Q/Steel y E/Iron toma la propiedad de entrada inmediatamente.
- El controlador anterior termina su interacción sin borrar la velocidad ya ganada. El botón anterior mantenido no debe reactivarse silenciosamente al soltar el nuevo poder; es necesario volver a pulsarlo.
- El cambio opera en ambos sentidos (Iron→Steel y Steel→Iron). No se requiere soltar los dos botones como pausa artificial. Una pulsación nueva de Q/E o F/botón derecho durante Coin Jump termina esa interacción especial y entrega el objetivo y la línea al poder recién elegido.

#### Pruebas añadidas/actualizadas
- `STEEL_COUNTERFALL_REAL_FORCE`: integra pasos temporales usando fuerza Steel ampliada y gravedad normal; comprueba que la caída de referencia se detiene dentro de la ventana configurada, que una moneda libre no activa el refuerzo y que una reacción lateral/subida no elegible tampoco recibe ese aumento.
- `STEEL_GROUNDED_COIN_ANCHOR_POLICY`: conserva la política 001_o de anclaje de moneda en suelo firme en cualquier ángulo.
- `ALLOMANCY_STEEL_COIN_INTERACTION`: espera que Coin Jump tenga un objetivo Steel activo, una línea alomántica compartida y ticks de fuerza tanto antes como después del contacto con el suelo.
- `ALLOMANCY_INPUT_HANDOFF`: comprueba el traspaso en ambas direcciones y que el input anterior no se reactive por quedarse sostenido.
- `ALLOMANCY_COIN_JUMP_HANDOFF`: comprueba que Coin Jump entrega la acción mediante Q (Steel normal), E (Iron traversal) o F/botón derecho (Iron yank).
- `ALLOMANCY_AIR_FEEL_CONTRACT`: exige gravedad normal para Steel; Iron mantiene su perfil localizado previo.
- Ejecutar `tools/run_player_core_playtest.bat` y recorrer el circuito en Godot 4.7.2 antes de afirmar compilación, fuerza efectiva o feel definitivo.


## Addendum 001_q — auditoría de feel y contingencia de trampolín (2026-10-11)

**Estado:** evaluación estática, no prueba jugable. Los controladores de Iron, Steel y Coin Jump no se modifican en esta iteración. La evaluación detallada está en `docs/FEEL_AUDIT_IRON_STEEL_COINJUMP_001_q.md`.

### Evaluación honesta
- Iron tiene cuerda virtual con longitud máxima, punto de anclaje superficial, conservación de componente tangencial, impulso inicial, control aéreo y FOV/distancia de cámara dinámicos. Esto es una base razonable inspirada en traversal de Spider-Man, pero no demuestra un feel equivalente. La cuerda aplica correcciones cinemáticas al hacerse tensa; hay que probar si se sienten bruscas.
- Diagnóstico correspondiente al build 001_p (SUPERADO en 001_r): la cámara reducía/desactivaba el seguimiento durante acciones alománticas. La corrección se describe en el addendum 001_r; la prioridad de la mirada manual sigue siendo obligatoria.
- Steel comparte fuerza continua y resolución de masa/soporte, usa una regla explícita para monedas apoyadas y amplía la fuerza real para contra-caída. Deben probarse los umbrales de ángulo, velocidad y el tope de escala; no hay feel de runtime aprobado.
- Coin Jump comparte el objetivo, la línea y `_apply_shared_steel_interaction()` de Steel. La fase inicial descendente y la respuesta UP tras contacto son una intención contextual, pero esa dirección no es geométricamente idéntica a la resolución de Steel normal; debe verificarse que la transición se percibe como el mismo poder.
- Riesgo a probar: `MistbornCoin.has_firm_ground_anchor_for_steel()` puede confiar en `_ground_contact` antiguo si la moneda fue movida por Iron y se queda momentáneamente con velocidad muy baja; validar el soporte geométrico actual antes de confiar solo en el flag si se reproduce.
- No se afirma que Iron, Steel o Coin Jump sean mejores que Spider-Man u otros referentes: el build actual no ha sido validado en Godot. La meta es una gramática de fuerzas más coherente con Mistborn, con fluidez, control, cámara y feedback al nivel requerido.

### Backlog de baja prioridad: posible trampolín
- **Prioridad MUY BAJA (P4), candidato futuro, NO implementado ni aprobado ahora.**
- Primero se debe probar y calibrar la fuerza real de Steel de 001_p en Godot. Si después de la validación la fuerza no consigue una captura jugable/legible en una situación importante, se puede reconsiderar una asistencia de tipo trampolín/contrafuerza contextual.
- La opción no queda descartada para siempre, pero no se debe implementar a ciegas ni reemplazar ahora la fuerza real. Cualquier futuro diseño debe evitar un freno global que suspenda gravedad o borre momentum sin contexto; reabrir la decisión con el usuario tras la prueba física.


## Addendum 001_r — Iron traversal camera-follow y pre-tensión de cuerda (2026-10-11)

### Alcance de esta iteración
- Prioridad actual: mejorar Iron antes de volver a calibrar Steel y Coin Jump. No cambia las fuerzas funcionales de Steel ni Coin Jump.
- Durante traversal rápido, la cámara puede acompañar suavemente la dirección de velocidad cuando el ratón está inactivo. La entrada manual del ratón mantiene prioridad durante la ventana de gracia; la asistencia no debe hacer girar la cámara a la fuerza.
- La asistencia yaw durante una acción alomántica usa una ganancia reducida (inicial 0,32 de la ganancia normal) y un límite inicial de 75 grados por segundo. Son parámetros de prototipo que requieren calibración en runtime. El FOV dinámico, distancia de cámara, colisión y control manual no se sustituyen.
- La cuerda virtual empieza a frenar la componente radial hacia afuera antes de llegar a su longitud máxima, según distancia de parada, velocidad radial y una desaceleración de pre-tensión configurable (inicial 24 m/s²). Se conserva la velocidad tangencial y cualquier velocidad radial hacia adentro. La predicción incluye la pequeña expansión radial de un paso tangencial discreto; cuando la cuerda ya está tensa se aplica solo la corrección radial necesaria para mantener el siguiente paso dentro del radio, conservando la velocidad tangencial. La pre-tensión no permite teletransporte ni cambia el vector completo de velocidad.
- El parámetro inicial de impulso (7,5 m/s), la aceleración tangencial y el límite de traversal no se ajustan todavía porque deben calibrarse juntos con la cámara y la tensión tras una prueba real.
- Coin Jump y Steel no se modifican funcionalmente en 001_r. La asistencia tipo trampolín continúa en backlog P4 / prioridad muy baja; no se implementa ni se usa para ocultar una falta de fuerza.

### Pruebas agregadas/actualizadas
- `CAMERA_ALLOMANCY_AUTO_FOLLOW_MATH`: confirma que la asistencia alomántica es más lenta que la normal, está limitada por velocidad angular y no se mueve con delta cero.
- `IRON_PHYSICAL_TETHER_MATH`: comprueba pre-tensión radial, conservación tangencial/inward, corrección geométrica al estar la cuerda ya tensa, corrección de sobreextensión y separación mínima del anclaje.
- `ALLOMANCY_CAMERA_YAW_LOCK`: ahora explicita la prioridad de la mirada manual sobre el seguimiento automático.

### Estado de validación
- Revisión estática y cálculos deterministas actualizados. No se encontró el binario de Godot en el entorno de trabajo; no se afirma compilación ni ejecución de la batería GDScript.
- Después de recuperar acceso a Godot 4.7.2, validar en este orden: cámara manual vs. asistencia, cuerda floja→pre-tensión→cuerda tensa, liberación con momentum conservado, aterrizaje, y después regresar a Steel/Coin Jump.
