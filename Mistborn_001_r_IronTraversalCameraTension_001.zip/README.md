# Mistborn — Iteración 001_r: Iron Traversal Camera & Tether Tension

**Build:** `Mistborn_001_r_IronTraversalCameraTension_001`  
**Motor objetivo:** Godot 4.7.2  
**Estado:** código y documentación integrados; revisión estática/matemática disponible, runtime no validado.

## Controles
- **WASD:** movimiento terrestre y control direccional en el aire.
- **Espacio:** salto; Espacio×2 dentro de la ventana inicia Coin Jump como una acción Steel sobre una moneda propia.
- **Shift:** sprint.
- **Q:** Steel; fija el objetivo por pulsación y mantiene una interacción continua con ese objetivo.
- **E:** Iron traversal con cuerda virtual en anclajes fijos.
- **F o botón derecho:** acción secundaria de Iron para atraer un objeto metálico pesado móvil.
- **Ctrl:** visión alomántica.
- **Botón central:** fijar objetivo; rueda: cambiar objetivo; X: limpiar objetivo.
- **R:** volver a la plaza; Esc: liberar/recapturar el ratón.

## Qué cambia en 001_p
- Steel no manipula directamente la velocidad vertical del jugador ni apaga gravedad para simular una captura.
- Cuando una caída debe ser frenada por una reacción Steel ascendente que recae en el jugador, el resolver calcula un multiplicador de fuerza real; la fuerza extra queda enclavada durante la acción para evitar jitter alrededor de velocidad vertical cero.
- Coin Jump usa el mismo objetivo de acción, línea alomántica, rango, resolver de fuerza, masa/soporte y telemetry que Steel normal. La moneda se empuja al suelo; al contacto firme, se vuelve anclaje para Steel según la política aprobada en 001_o.
- La moneda en vuelo sigue siendo un proyectil ligero; solo al contacto geométrico firme con adoquín/tierra compactada se considera anclaje completo para Steel, sin importar ángulo.
- La última pulsación primaria Q/E toma la propiedad de input, en ambas direcciones; la anterior conserva momentum y no se reactiva silenciosamente. Una pulsación nueva de Q/E o F/botón derecho durante Coin Jump transfiere la acción a Steel normal o Iron y evita ejecutar dos interacciones alománticas en paralelo.
- Añadidas/actualizadas pruebas: `STEEL_COUNTERFALL_REAL_FORCE`, `STEEL_GROUNDED_COIN_ANCHOR_POLICY`, `ALLOMANCY_STEEL_COIN_INTERACTION`, `ALLOMANCY_INPUT_HANDOFF`, `ALLOMANCY_COIN_JUMP_HANDOFF`, `ALLOMANCY_AIR_FEEL_CONTRACT`.

## Referencias técnicas
- [Ashwalker SteelPush (MIT)](https://github.com/HoleInWater/Ashwalker/blob/master/Assets/_Project/Scripts/Metallurgy/Metals/SteelPush.cs)
- [Ashwalker Physics Math Book](https://github.com/HoleInWater/Ashwalker/blob/master/docs/PHYSICS-MATH-BOOK.md)
- [Godot CharacterBody3D](https://docs.godotengine.org/en/stable/classes/class_characterbody3d.html)
- [Steel y monedas apoyadas en el suelo](https://mistborn.fandom.com/wiki/Steel)

## Archivos importantes
- Contrato Maestro: `LEER PRIMERO PRIORIDAD ABSOLUTA MISTBORN_MASTER_DEVELOPMENT_SPEC.md`
- Manual: `docs/MANUAL_STEEL_COUNTERFALL_SHARED_001_p.txt`
- QA: `docs/QA_STEEL_COUNTERFALL_SHARED_001_p.txt`
- Investigación: `docs/MISTBORN_STEEL_COUNTERFALL_RESEARCH_001_p.md`
- Revisión estática: `docs/STATIC_PACKAGE_REVIEW_001_p.txt`

## Validación pendiente
Godot 4.7.2 no estaba disponible durante esta preparación. No se afirma que los scripts hayan compilado ni que el feel se haya verificado. Cuando el motor esté disponible, ejecuta `tools/run_player_core_playtest.bat` y sigue los pasos del QA.

## Evaluación de feel 001_q (solo revisión estática)
- Añadida `docs/FEEL_AUDIT_IRON_STEEL_COINJUMP_001_q.md` con fortalezas, riesgos, puntuaciones de madurez (no de feel medido), mejoras recomendadas y orden de validación.
- No se modifican controladores: Iron, Steel y Coin Jump permanecen como en 001_p. No se puede afirmar la calidad real del feel sin compilar, ejecutar y probar en Godot.
- Trampolín: marcado como candidato futuro de prioridad MUY BAJA (P4), solo reconsiderarlo si la fuerza Steel real no resulta suficiente después de pruebas y calibración. No está implementado.


## 001_r — mejoras de Iron
- Seguimiento automático suave de cámara durante traversal alomántico solo cuando el ratón está inactivo; la mirada manual siempre tiene prioridad.
- El seguimiento de yaw durante una acción alomántica usa ganancia reducida (0,32) y límite de velocidad angular de 75°/s.
- La cuerda virtual incluye pre-tensión radial basada en distancia de frenado para reducir el golpe de pasar de cable flojo a cable tenso. Conserva la velocidad tangencial y respeta la longitud máxima mediante una corrección radial geométrica por paso. El estado de depuración expone el modo y delta angular de cámara, además de las velocidades radiales antes/después de la restricción.
- No cambia Steel ni Coin Jump funcionalmente. El trampolín continúa como posible contingencia futura P4 de muy baja prioridad, no implementada.
- Validación estática/matemática añadida; no se ejecutó Godot en este entorno.
