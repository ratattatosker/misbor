# Cómo poner tu .GLB en Mistborn

1. Abre la carpeta del proyecto que contiene `project.godot`.
2. Entra en `assets/characters/`.
3. Copia ahí tu archivo `.glb`.
4. No necesitas abrir el GLB por separado. Godot lo importará automáticamente al detectarlo.
5. Al ejecutar la escena principal, `ExternalCharacter` busca primero `character.glb`, luego `character.fbx` y finalmente cualquier `.glb/.fbx` que encuentre en esta carpeta.

## Importante

Abrir el archivo `.glb` en el explorador de Godot sólo lo importa/visualiza como recurso; no significa que aparezca como personaje en la escena. Mistborn instancia el archivo automáticamente desde `Visual` cuando ejecutas la escena, siempre que el archivo esté físicamente dentro de `res://assets/characters/`.

## Requisitos recomendados

- Humano con Skeleton/Armature y skinning.
- Formato GLB preferido.
- Escala de aproximadamente 1.7–1.9 m de altura.
- Materiales/texturas embebidos o incluidos.
- Huesos con nombres razonables para detectar manos, pelvis, pecho y cabeza.
- Las animaciones no son obligatorias: Mistborn genera locomoción básica cuando el archivo no trae clips.

## Para comprobar que está realmente dentro del proyecto

En el panel FileSystem de Godot debe aparecer:
`res://assets/characters/tu_archivo.glb`

Si sólo tienes el GLB en Descargas, WhatsApp, Telegram o fuera de la carpeta del proyecto, Mistborn no puede cargarlo.
