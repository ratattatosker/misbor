CHARACTER EXTERNAL ASSET

The project intentionally does not ship the heavy character mesh.

Place your real skinned character at:
  assets/characters/character.glb
or:
  assets/characters/character.fbx

The documented Quaternius-based GLB is a rig-only character source: it contains
the human mesh and Skeleton3D but no embedded animation clips. The mesh is not
bundled in the development ZIP; place the asset in this folder when used.
The Mistborn runtime supplies skeletal AnimationPlayer clips for the required
locomotion states when the external asset has no animations.

Required initial states:
  Idle / Walk / Run / Jump / Fall / Land

The external model is treated as the visual body only. Gameplay movement stays
on the CharacterBody3D. No MeshInstance3D is translated by gameplay code.

Forward convention:
  The current character asset is authored to face Godot's -Z forward direction,
  so no 180-degree visual rotation is applied.

Original character source:
  Quaternius Universal Base Characters — Superhero Male
  CC0 1.0 Universal
