# Auditoría de diseño de movimiento — Mistborn 001_q

**Base auditada:** código de `001_p` (Steel Counter-Fall + Coin Jump Shared Action + Iron Physical Tether).  
**Tipo de revisión:** lectura estática del código y comparación de principios de diseño.  
**NO es:** una evaluación de feel en ejecución, una compilación de Godot ni una certificación de gameplay. Godot no está disponible en este entorno y la versión `001_p` no se ha probado en runtime.

## Resumen ejecutivo

La arquitectura ya tiene elementos correctos para construir un buen movimiento: una cuerda virtual de longitud máxima para Iron, conservación de la componente tangencial, impulso inicial controlado, aplicación sostenida de fuerza para Steel, selección según masa/soporte y Coin Jump encaminado al mismo resolver de Steel.

Eso hace que el diseño sea prometedor, pero no permite afirmar que ya se sienta como Spider-Man ni que la física sea divertida. La propia documentación del proyecto registra una evaluación de una versión anterior (`001_h`) en la que Iron/Steel resultaban intuitivos pero no divertidos y el salto se sentía demasiado flotante. `001_p` cambia partes relevantes del movimiento, pero no se ha vuelto a comprobar en ejecución.

## Puntuación orientativa

Las notas de abajo califican la **madurez de la arquitectura por inspección**, no el tacto real del mando/teclado. El feel real queda como **sin medir**.

| Sistema | Arquitectura actual | Parecido mecánico al referente | Feel en runtime |
|---|---:|---:|---|
| Iron Heavy / traversal | 6.5/10 | 6/10 respecto a principios de Spider-Man | Sin medir |
| Steel normal | 6/10 | 7/10 respecto a la lógica alomántica descrita | Sin medir |
| Coin Jump | 7/10 de unificación con Steel | 7/10; persiste una diferencia de dirección contextual | Sin medir |
| Iron + Steel + Coin Jump juntos | 5.5/10 de madurez de integración | La propuesta es distintiva de Mistborn, pero no está validada | Sin medir |

Estas puntuaciones son estimaciones de desarrollo y no deben presentarse como resultados de una prueba de juego.

## Iron Heavy: qué ya tiene y qué falta

### Aciertos presentes en el código
- El anclaje se adquiere una vez y se mantiene durante la pulsación; la acción no cambia silenciosamente de objetivo.
- Hay una cuerda virtual con longitud máxima y un punto de unión sobre la superficie cuando el raycast identifica el collider.
- Al tensarse la cuerda, el controlador elimina la velocidad radial que la estiraría y conserva la componente tangencial.
- El impulso inicial se suma a la velocidad existente en lugar de sustituirla, y se limita la velocidad total de traversal.
- Hay dirección tangencial en el aire, FOV dinámico, distancia de cámara dinámica, colisión de cámara y señales de inclinación/cámara.

### Diferencias y riesgos frente a Spider-Man
- La tensión de la cuerda es una corrección cinemática de velocidad, no un sistema de fuerzas/resorte completo. Es una elección válida de videojuego, pero puede sentirse abrupta cuando el cable pasa de flojo a tenso.
- El impulso inicial es una ayuda de diseño que suma velocidad directamente; no nace únicamente de la fuerza continua de Iron. Esto puede hacerlo más responsivo, pero necesita calibración y una señal visual/sonora clara.
- La cuerda empieza con la longitud de la distancia actual. Si el jugador lanza casi radialmente hacia el anclaje, puede acercarse demasiado y encontrar la salvaguarda de distancia mínima sin haber acumulado suficiente velocidad tangencial: riesgo de sentirse como un tirón corto en vez de un arco.
- `camera_rig.gd` tiene FOV y distancia dinámicos, pero las reglas de auto-follow de yaw están condicionadas a que no haya una acción/input alomántico activo. En la práctica, eso desactiva el seguimiento de trayectoria durante muchas de las secuencias de Iron/Steel más importantes. Insomniac identifica cámara, FOV y animación como partes importantes de la sensación de velocidad y control, no como decoración posterior.
- No se ha verificado visualmente el blend de animación de vuelo, la lectura de tensión del cable, el aterrizaje ni la liberación.

### Mejoras recomendadas, ordenadas
1. Probar y medir la transición cable flojo → tenso; si hay tirón, amortiguar la corrección radial en pocos ticks sin perder la regla de longitud máxima.
2. Permitir un seguimiento de cámara suave durante traversal cuando el jugador deje de mover el ratón, con prioridad absoluta a la entrada manual y un límite de giro por segundo.
3. Ajustar impulso inicial, tangente, longitud de cable, velocidad máxima y llegada sobre una misma ruta de tejados; no ajustar cada variable aislada.
4. Añadir respuesta de tensión, liberación, vuelo y aterrizaje (pose, audio, pequeña sacudida y FOV) solo después de que el movimiento base esté estable.

## Steel normal: qué ya tiene y qué falta

### Aciertos presentes en el código
- Fuerza aplicada de manera continua, no un único impulso que desaparece al siguiente frame.
- Decisión compartida de quién recibe la respuesta según masa efectiva y soporte.
- Las monedas que tienen contacto firme con el suelo cuentan como anclaje completo para Steel, incluso en un empuje lateral; esto es la regla de juego aprobada.
- La contra-caída usa una fuerza real aumentada a través del resolver y mantiene la escala durante la acción, sin cambiar directamente `velocity.y` ni apagar gravedad.
- El controlador conserva un objetivo fijo durante la acción y el input manager permite el cambio explícito entre Iron y Steel.

### Diferencias y riesgos
- La respuesta de masa es binaria (el jugador o el objeto recibe la interacción). Es legible, pero puede notarse abrupta cerca del umbral de masa si los objetos de prueba no están bien categorizados.
- La amplificación de contra-caída entra por umbrales de componente vertical y velocidad de caída. Cerca de esos umbrales, una pequeña variación de ángulo puede producir una diferencia apreciable de respuesta. Conviene evaluar un ramp/smoothstep, no añadir más potencia a ciegas.
- Un tope de fuerza configurado garantiza que el sistema no crezca indefinidamente, pero no garantiza detener cualquier caída desde cualquier altura/velocidad en el tiempo deseado. La velocidad inicial, distancia y componente ascendente importan.
- La fórmula física puede ser correcta y aun así sentirse como un tirón poco expresivo si el impacto, la cámara, el sonido y la animación no comunican la fuerza.

### Mejoras recomendadas
1. Instrumentar fuerza efectiva, factor por distancia, componente ascendente, velocidad vertical antes/después y estado de soporte.
2. Hacer una matriz de pruebas: moneda apoyada, moneda en el aire, anclaje alto, objetivo lateral, distintas velocidades de caída.
3. Suavizar la entrada/salida de la asistencia de contra-caída si el salto de umbral se observa en runtime.
4. Añadir feedback audiovisual escalado por fuerza, sin que el VFX decida la física.

## Coin Jump: ¿es el mismo poder que Steel?

La base física sí está compartida: Coin Jump crea una moneda, la mantiene como objetivo de acción Steel, usa el mismo renderer/línea y llama `_apply_shared_steel_interaction()` tanto antes como después de tocar el suelo. Al detectar soporte firme, la misma regla de masa/soporte pasa de proyectil ligero a anclaje, y el mismo resolver puede transferir la reacción al jugador.

No es exactamente idéntico a Steel normal en todos los detalles de dirección. Durante la caída, Coin Jump utiliza una dirección contextual descendente; al tocar el suelo, la respuesta del personaje usa `Vector3.UP`. Steel normal obtiene su reacción geométrica desde la posición real de la fuente de metal. Esta diferencia es intencional para generar el movimiento descendente del Coin Jump, pero debe vigilarse para que no parezca una habilidad de salto separada.

### Para que se sienta como el mismo poder
- Mantener la misma fuerza, distancia, regla de soporte, contra-caída, línea y telemetría.
- Mantener solo una diferencia de **intención/objetivo**: Coin Jump invoca una moneda propia y fuerza su primera trayectoria hacia el suelo; no añade un multiplicador de salto independiente.
- Tras el contacto, dejar que el mismo resolver transfiera la reacción en una dirección consistente con la geometría del personaje y la moneda; conservar el vector ascendente puro únicamente si las pruebas muestran que la diferencia geométrica provoca un resultado claramente peor.
- La moneda debe seguir siendo un cuerpo físico y permanecer en el mundo al soltar el input.
- Comprobar moneda en el aire → contacto → anclaje, manteniendo Space, y después probar que Q/E/F transfiere la acción sin doble fuerza ni congelar el momentum.

## Posible caso límite de soporte de la moneda

`MistbornCoin.has_firm_ground_anchor_for_steel()` devuelve verdadero inmediatamente cuando `_ground_contact` sigue siendo verdadero y la velocidad lineal/angular es muy baja, antes de volver a verificar la superficie. El flag `_ground_contact` se actualiza en la rutina de colisión de proyectil, la cual no se ejecuta cuando `_projectile_active` es falso. Por ello, después de que Iron levante una moneda normal del suelo, hay un caso límite a probar si la moneda queda momentáneamente casi inmóvil en el aire: el flag antiguo podría clasificarla como anclada. No es un fallo confirmado de runtime; es un riesgo estático concreto. La versión futura debería comprobar soporte geométrico actual antes de confiar solo en el flag.

## ¿Podemos ser mejores que los referentes?

No hay base para decir que este prototipo ya se siente mejor que Spider-Man: el referente tiene años de refinamiento de control, cámara, animación, framing y audio, y nuestra versión actual no se ha vuelto a probar. Tampoco necesitamos ganarle en su propio terreno. Mistborn puede ofrecer algo que Spider-Man no tiene: una gramática común de fuerzas en la que el mismo objetivo metálico puede impulsar, frenar una caída, mover un objeto o preparar un Coin Jump.

La condición para que eso sea superior para **Mistborn** es que las tres acciones se perciban como la misma física con distintos objetivos, que el jugador conserve el control y que la cámara explique la trayectoria sin pelear con el ratón.

## Orden de trabajo recomendado
1. Runtime: compilar y ejecutar las pruebas existentes en Godot 4.7.2; registrar FAIL y logs antes de tocar parámetros.
2. Iron: comprobar enlace, tensión, control tangencial, salida, cámara y aterrizaje.
3. Steel: comprobar fuerza efectiva, soporte de moneda y contra-caída a distintas velocidades.
4. Coin Jump: comprobar fase descendente, transición de apoyo, altura/tiempo de respuesta y liberación.
5. Integración: Q↔E y Coin Jump→Q/E/F, sin fuerzas en paralelo ni pérdida artificial de momentum.
6. Feedback audiovisual y pulido.

## Nota de backlog: trampolín — prioridad muy baja

**Estado: candidato futuro, no implementado ni aprobado para la iteración actual. Prioridad: MUY BAJA (P4).**

No volver a implementar una frenada artificial ahora. Primero debe probarse la fuerza Steel real de `001_p`. Si, después de la validación en Godot y de ajustar la fuerza con datos reales, resulta incapaz de crear una captura legible/satisfactoria en una situación importante, se puede reconsiderar una asistencia de tipo “trampolín” o contrafuerza contextual como solución de diseño. Esa posibilidad no se descarta para siempre, pero solo se reabre después de probar la vía física y revisar el resultado con el usuario. Cualquier futura versión debe evitar un freno global que suspenda la gravedad o borre la velocidad sin contexto.

## Referencias
- Insomniac / GDC, *Concrete Jungle Gym: Building Traversal in Marvel's Spider-Man*: https://www.gdcvault.com/play/1026084/Concrete-Jungle-Gym-Building-Traversal
- Insomniac interview, PlayStation Blog: https://blog.playstation.com/archive/2018/09/06/insomniac-interview-the-tech-behind-marvels-spider-man/feed/
- Godot `CharacterBody3D` documentation: https://docs.godotengine.org/en/stable/classes/class_characterbody3d.html
- Ashwalker (MIT; independent Mistborn-inspired Unity prototype, not evidence that this project's feel is validated): https://github.com/HoleInWater/Ashwalker
