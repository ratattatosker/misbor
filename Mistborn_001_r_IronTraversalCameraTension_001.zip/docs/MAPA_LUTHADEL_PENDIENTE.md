# ANOTACIÓN PARA MÁS ADELANTE — MAPA Y ESCALA DE LUTHADEL

**Estado:** APARCADO. No implementar ni dedicar el siguiente paso de desarrollo a este tema hasta que el usuario lo reactive explícitamente.

**Objetivo:** retomar el análisis de escala del mapa de referencia y convertirlo en una ciudad de Luthadel jugable, densa y optimizada, en vez de un escenario vacío o una cuadrícula de bloques.

## Contexto que debe conservarse

- El usuario pidió comparar la imagen/mapa de referencia con un mapa real, medir las proporciones de las calles y estimar la escala del mapa.
- Después pidió contrastar la escala estimada con el canon de Mistborn para decidir si puede servir en el juego.
- También pidió un prompt maestro para generar la ciudad, incluyendo optimización, reglas y celdas de renderizado.
- El objetivo no es reproducir literalmente una cartografía real: es obtener una escala jugable verosímil para Luthadel que preserve la sensación del canon y permita Steel/Iron traversal.
- Debe correr en hardware modesto (Acer Aspire ES1-572, Intel i3-7100U, 16 GB RAM). Evitar una ciudad visualmente vacía; optimizar sin convertir todo en cubos sosos.
- Las calles deben admitir desplazamiento alomántico continuo y tener manzanas, casas, farolas, alcantarillas y variedad urbana. Mantener espacio para sótanos/cellars, puertas/muros, río y puentes cuando el diseño urbano los justifique.
- Distribuir alcantarillas de manera lógica como parte de una ciudad real, no como puntos uniformes puestos al azar.
- No bloquear artificialmente la altura del mundo para resolver problemas de movimiento.

## Instrucciones para retomarlo

1. Volver a solicitar/abrir la imagen de referencia exacta y registrar dimensiones en píxeles y límites del área jugable. No adivinar escala a partir de una captura recortada sin anotarlo.
2. Elegir referencias medibles: anchura de calzada, aceras, longitud de manzana, puertas, edificios, plazas y distancia entre farolas. Si el mapa no tiene escala gráfica, declarar intervalos e incertidumbre, no fingir precisión.
3. Contrastar proporciones con mapas urbanos reales de época y con descripciones/mapas canónicos disponibles de Luthadel. Separar explícitamente: dato canónico, inferencia razonable y decisión de diseño para el juego.
4. Proponer escala en metros por unidad de Godot, dimensiones de manzana, anchura de calles y altura típica/máxima de edificios. Probarlas con el controlador del jugador: carrera, salto, Steelpush, Iron pull, Coin Jump y visibilidad desde tejados.
5. Definir el streaming por celdas: tamaño de celda, radio de carga, margen de precarga, descarga, persistencia de estado, límites de draw calls, LOD/distancia, oclusión y presupuesto de objetos físicos. Evitar reconstruir todo el barrio en cada frame.
6. Generar manzanas mediante módulos reutilizables con variación controlada: fachadas, alturas, patios, callejones, tejados, interiores selectivos, alcantarillas, farolas y objetos metálicos. Las colisiones deben ser simples y estables; la silueta visible puede ser más detallada.
7. Crear zonas de prueba de traversal conectadas a calles y tejados reales, no salas flotantes desconectadas. El diseño de cada calle debe dar oportunidades legibles de empuje/tirón sin saturar de objetivos metálicos.
8. Perfilar en el equipo objetivo y registrar FPS medio, mínimos, tiempo de frame, número de celdas activas, nodos, cuerpos físicos y draw calls. La optimización se valida midiendo; no se asume.
9. Mantener el mapa fuera de la ruta crítica hasta que se reactive. No cambiar el sistema de combate/movimiento para adaptarlo a una escala todavía no aprobada.

## PROMPT MAESTRO PARA USAR AL REACTIVAR EL MAPA

> Trabaja en el proyecto Godot de Mistborn y diseña la ciudad jugable de Luthadel a partir de la imagen de referencia que proporcionaré. Antes de generar geometría, analiza las proporciones de esa imagen y compara anchuras de calles, manzanas y edificios con referencias urbanas reales y con la información canónica disponible de Luthadel. Distingue claramente datos comprobados, inferencias e hipótesis de diseño; no inventes una escala exacta si la imagen no permite medirla.
>
> El resultado debe sentirse como una ciudad de Mistborn, no como un mapa vacío ni una cuadrícula de cubos. Incluye calles y callejones conectados, manzanas de tamaños variados, fachadas y tejados transitables cuando corresponda, farolas metálicas con puntos de selección bien definidos, alcantarillas distribuidas de manera urbana lógica, patios y accesos a sótanos, y, si la estructura del mapa lo requiere, puertas, murallas, río y puentes. La densidad debe favorecer desplazamiento con Steel e Iron y rutas alternativas a nivel de calle y tejados.
>
> Optimiza para un Acer Aspire ES1-572 con Intel i3-7100U y 16 GB RAM. Usa generación modular y determinista, instanciación por celdas, carga/descarga por distancia, límites claros de física activa, colisiones simplificadas, LOD/ocultación cuando proceda y presupuestos medibles de nodos, cuerpos físicos y draw calls. No regeneres toda la ciudad por frame. No impongas un techo artificial de altura para ocultar problemas de movimiento. Mantén la estética estilizada, rica en siluetas y materiales, evitando el aspecto excesivamente cuadrado.
>
> Trabaja incrementalmente: primero calcula y documenta la escala; después crea una sola manzana representativa; valida traversal, colisiones y rendimiento; solo entonces expande a celdas vecinas. Cada paso debe ser pequeño, reversible y comprobado. Conserva la última versión estable como rollback, no rompas sistemas de movimiento que ya funcionen, y no declares éxito sin una prueba en Godot. Entrega al final el ZIP completo, un informe de métricas y una lista exacta de lo que queda pendiente.

## Criterio de finalización

La tarea no se considera terminada hasta que la escala haya sido aprobada, las calles y manzanas estén conectadas, las celdas carguen y descarguen correctamente, el traversal no atraviese colisiones ni quede atrapado, y el rendimiento se haya medido en el hardware objetivo o en una prueba equivalente claramente identificada.
