# Investigación técnica pública: Mistborn: Ashes Project

**Preparada para:** Mistborn `001_j`  
**Objetivo:** separar qué se puede verificar del proyecto Ashes, qué es visible en el prototipo y qué código interno no está disponible públicamente.

## Conclusión ejecutiva

No encontré un repositorio público que contenga el código jugable de SoulsForge/Ashes Project ni un archivo de proyecto Unreal para abrirlo. Su página oficial se define como una propuesta fan no comercial y enlaza un teaser, un prototipo temprano, arte y música; el post original de SoulsForge en Reddit confirma que lo compartido era una propuesta creativa y un prototipo preliminar, con arte y música de preproducción ([página oficial](https://ashesproject.carrd.co/); [anuncio original](https://www.reddit.com/r/Mistborn/comments/qls0nu/)). Por ello **no es posible afirmar qué clases, funciones, Blueprints, fórmulas de fuerza, curvas de aceleración, variables de cámara o estados internos usaron** sin disponer del proyecto o de una publicación técnica explícita.

Sí es posible hacer tres cosas rigurosas:
1. recopilar lo que el equipo publicó sobre su intención y pilares de diseño;
2. describir acciones de juego que el prototipo muestra o que su propia página enumera;
3. diseñar una implementación análoga en Godot y mantener separadas las inferencias de los hechos verificables.

No he copiado ni simulado una extracción de código de Ashes. El código de nuestra escena `luthadel_movement_city.gd` es original y procedural.

## 1. Evidencia primaria: alcance y dirección artística

La página oficial describe Ashes como un *non-profit fan project* y una propuesta de juego. Para Luthadel enumera los principios “gritty, oppressive, contrast, and stylized reality” y sitúa la ciudad en una transición de tecnología medieval a industrial/victoriana, cubierta de ceniza durante mil años. También describe el prototipo temprano como una prueba de primera impresión para moverse con capacidades de Steel: saltos alománticos, vuelo, disparo de monedas, tirar/empujar y otras maniobras. Su pitch de juego más amplio cita como referencia la premisa de mundo abierto de Insomniac's Spider-Man y plantea objetivos de sigilo/acción. La página lista combate, IA dinámica, conversaciones y robos como características de la propuesta general; eso **no prueba que todas estén implementadas en el prototipo publicado**. ([Ashes Project — página oficial](https://ashesproject.carrd.co/))

El post original de SoulsForge dice que el material compartido incluye un teaser, un prototipo temprano, arte y música de preproducción. En una respuesta, un miembro del equipo afirma que existían prototipos muy iniciales de otros metales, pero que el foco de iteración fue encontrar el potencial de diversión, sensación de movimiento y balance/UX para las acciones principales de traversal con Iron y Steel. ([Reddit — publicación original](https://www.reddit.com/r/Mistborn/comments/qls0nu/))

## 2. Mecánicas que se pueden analizar públicamente

| Mecánica o sistema | Qué se publicó/observa | Qué no se sabe sin el código | Consecuencia para Mistborn |
|---|---|---|---|
| Cámara y locomoción en tercera persona | La ficha oficial lo clasifica como tercera persona y presenta traversal en la ciudad. | Offset, spring arm, smoothing, FOV, camera lag, collision solver, input sampling y orden exacto de ticks. | Mantener cámara controlada por jugador; dar feedback de velocidad sin cambiar el yaw al apuntar con un metal. |
| Saltos alománticos / vuelo | La página oficial los enumera entre los objetivos del prototipo temprano. | Velocidad inicial, curva de gravedad, coyote/buffer, gravedad en descenso, caps, estado de vuelo y transiciones exactas. | Probar trayectorias y caídas con datos medibles; no copiar números inventados. |
| Steelpush | La página describe empujar metal y usa el término Steel; el prototipo muestra movimiento basado en objetos/metal. | Fórmula de masa y distancia, fuerza límite, reacción del jugador, solver de contactos, prioridad de objetivos y código que se ejecuta en cada tick. | Mantener un resolver compartido de fuerza/masa en `allomantic_force_model.gd` y `targetable.gd`; Steel no debe convertirse en dirección arbitraria por WASD. |
| Ironpull | El equipo lo incluye en el foco de traversal; la descripción oficial cita pull/push y otras maniobras. | Función exacta de adquisición, fuerza radial, gravedad, tangential assist, conservación de momento, condiciones de salida y llegada. | En `iron_controller.gd`, fijar un ancla durante la pulsación, aplicar fuerza radial dinámica, permitir corrección tangencial limitada, preservar inercia al soltar. Reducir gravedad solo como regla local en anclas pesadas y sin desactivarla. |
| Monedas / coin shots | “Coin shoots” forma parte explícita de la lista de acciones del prototipo. El material público de VFX muestra un disparo de moneda en el montaje cinematográfico. | Si el proyectil usa física real, cómo se calcula velocidad, si hay pooling, trayectoria prevista, consumo/recuperación, daño y cómo se relaciona con Steel. | Mantener moneda como objeto físico (`coin.gd`) y una ruta de interacción por el solver compartido. En nuestro proyecto, el lanzamiento normal todavía debe validarse/conectarse por separado. |
| Líneas alománticas / legibilidad de objetivos | El prototipo se comenta públicamente por las líneas azules que dan feedback de objetos/acción; es observación del material, no documentación de un algoritmo. | Si usan traces, selección de objetivos, line rendering, shaders, o un sistema de prioridades, y cómo filtran fuera de cámara. | Nuestra capa `targeting_controller.gd` es la autoridad única y los sistemas visuales no deben robar el input ni cambiar un objetivo fijado silenciosamente. |
| Impactos / shockwave de moneda | El artista de VFX comenta pequeños fragmentos que se mueven con la moneda para ayudar a construir la onda de choque del disparo en un plano de la cinemática. | Si esos elementos están vinculados al código de gameplay, cómo se calculan impactos y si se usan en el prototipo jugable. | Tratarlo como referencia visual, no evidencia de una función de combate implementada. Añadir VFX después de que la física pase pruebas. |
| Niebla y ceniza | El look visual y la niebla están muy desarrollados en la pieza cinematográfica. | Si la misma niebla se usa en el nivel de juego y con qué presupuesto de rendimiento. | Priorizar una niebla/fondo baratos y una cantidad reducida de ceniza en nuestro renderizador GL Compatibility. |
| Combate, IA, sigilo, conversaciones y atracos | Aparecen en la página como pitch/funciones objetivo del juego general. | Qué IA, percepción, navegación, combate, estado de alerta o conversación se alcanzó a implementar en la demo temprana. | No inferir que el prototipo contiene sistemas completos de esos tipos. Mantenerlos como alcance futuro separado. |

## 3. Qué técnica sí documentó un miembro del equipo

Alberto Martínez Villarán publicó un breakdown del trabajo de *Realtime Mist VFX*. Es específico de la cinemática y su pipeline, no de los sistemas de control del jugador. Explica que se renderizó en UE4.26 y se compuso luego en After Effects; un plano usó una simulación Fluid Ninja Live que alimentaba un shader raymarching para auto-sombreado, y otro usó simulaciones Fluid Ninja horneadas para mover partículas volumétricas. También exploró volúmenes de niebla/raymarching. El breakdown menciona rocas pequeñas que se mueven con la moneda para aumentar la sensación de acumulación de fuerza en el disparo de la cinemática. Fuente: [Mistborn — Ashes Project — Realtime Mist VFX](https://albmarvil.artstation.com/projects/bKy6lG).

De esto sí podemos aprender un principio de art direction: la niebla debe reaccionar y reforzar la acción, no ser solo un plano de color. No se debe convertir esa técnica cinematográfica de UE4/After Effects en una supuesta solución de gameplay de Godot. En el portátil del usuario usaremos métodos de bajo coste al comienzo.

## 4. Qué no debe confundirse con Ashes

Hay otras demos y proyectos de fans de Mistborn que explican su código, pero no son Ashes Project. No se usarán sus detalles internos como prueba de cómo SoulsForge programó sus mecánicas. Este informe tampoco asume acceso al código de Ashes solo por disponer de un tráiler o un prototipo de vídeo.

Si en el futuro el usuario obtiene el proyecto original, sus archivos fuente o un breakdown técnico de los programadores, podemos auditar clases, Blueprints, componentes y valores reales. Hasta entonces el trabajo correcto es ingeniería inspirada en comportamientos visibles, no ingeniería inversa fingida.

## 5. Cómo adaptamos los principios a Godot

La implementación actual de Mistborn usa GDScript y Godot 4.7.2. El mapa de responsabilidades relevante es:

- `scripts/player_controller.gd`: movimiento convencional, salto, gravedad, control aéreo y conservación de la velocidad del personaje.
- `scripts/targeting_controller.gd`: adquisición/selección de objetivos metálicos y objetivo fijo durante cada interacción.
- `scripts/allomantic_force_model.gd`: constantes/autoridad común para fuerza, masa, distancia y velocidad máxima.
- `scripts/targetable.gd`: perfil alomántico, masa, punto de acción, reacción del jugador y resolución de masa/soporte.
- `scripts/iron_controller.gd`: atracción hacia un ancla fijada, corrección tangencial y salida conservando momento.
- `scripts/steel_controller.gd`: empuje Steel, asistencia frontal pequeña, Coin Jump como interacción Steel sostenida y no un boost escrito a mano.
- `scripts/traversal_controller.gd` / `scripts/coin.gd`: creación, estado físico y ciclo de vida de monedas.
- `scripts/camera_rig.gd`: seguimiento y entrada de cámara, separada del targeting.
- `scripts/luthadel_movement_city.gd`: geometría original procedural, anclajes legibles y rutas físicas de tejados; utiliza `MultiMesh` para ventanas repetidas y baja el coste de draw calls.

### Decisiones para esta iteración 001_j

- Mini-ciudad compacta y original (plaza de ceniza, bloques altos, tejados, rampas, pasarelas, chimeneas, agujas distantes, luz cálida y ceniza) inspirada en los principios públicos de Ashes, no en una copia de sus assets.
- Marcos de metal más grandes y zonas de selección generosas para poder leerlos y engancharse sin apuntar a un píxel.
- Iron reduce localmente la aceleración gravitatoria al 22% y limita la velocidad de caída a 3,8 m/s solo durante la atracción aérea a una ancla pesada. La gravedad sigue activa; al soltar se restaura sin borrar la velocidad acumulada.
- Steel solo tiene una pequeña preferencia de dirección frontal cuando se mantiene W y la reacción física natural ya es hacia delante; A/D/S corresponden al control normal del personaje. La fuerza base compartida no se aumenta.
- Coin Jump: segunda pulsación de Espacio invoca moneda y empieza el mismo Steelpush hacia abajo; mantener Espacio decide durante cuánto tiempo sigue aplicándose la fuerza. No hay multiplicador ni temporizador fijo especial. Soltar antes del contacto moneda-suelo puede cortar el empuje antes de que aparezca la reacción de apoyo.

Estos valores son hipótesis iniciales de feel, no valores extraídos de Ashes ni cifras canónicas. Esta versión requiere validación en el ordenador del usuario; no se declara runtime-verified desde este entorno.

## Fuentes principales

1. [Ashes Project — página oficial](https://ashesproject.carrd.co/)
2. [SoulsForge: publicación original de Reddit](https://www.reddit.com/r/Mistborn/comments/qls0nu/)
3. [Prototipo de gameplay temprano enlazado por el proyecto](https://www.youtube.com/watch?v=-2pIZTweVwE)
4. [Mistborn — Ashes Project — Realtime Mist VFX (breakdown del artista)](https://albmarvil.artstation.com/projects/bKy6lG)
5. [Teaser trailer](https://www.youtube.com/watch?v=Sy6CmZGX2xA)
