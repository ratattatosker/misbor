# Investigación técnica — Steel Counter-Fall y Coin Jump (001_p)

## Referentes contrastados
- Ashwalker `SteelPush.cs` (licencia MIT): fuerza continua, target fixo, predicción de receptor jugador/metal, anclajes y reacción. https://github.com/HoleInWater/Ashwalker/blob/master/Assets/_Project/Scripts/Metallurgy/Metals/SteelPush.cs
- Ashwalker Physics & Mathematics Handbook: fuerza, masa, soporte, momentum y reacción. https://github.com/HoleInWater/Ashwalker/blob/master/docs/PHYSICS-MATH-BOOK.md
- Godot CharacterBody3D: el movimiento se controla por `velocity` y `move_and_slide()`, por lo que una fuerza sobre nuestro tipo de cuerpo se representa como aceleración integrada sobre velocidad; no implica asignar una velocidad de rebote. https://docs.godotengine.org/en/stable/classes/class_characterbody3d.html

## Decisión de implementación
1. Steel continúa usando `MistbornTargetable.apply_allomantic_interaction()` como autoridad real del reparto de reacción.
2. `calculate_steel_counterfall_strength()` calcula un multiplicador cuando el jugador está cayendo y el solver predice que la reacción ascendente recae sobre él. Es una fuerza real aplicada en ticks, no una corrección artificial de `velocity.y`.
3. La escala máxima se mantiene en el controlador durante la acción sostenida para que el frenado no desaparezca al cruzar v.y=0. Se limpia al terminar la acción o dejar de recibir la reacción.
4. Coin Jump no tiene un motor de física distinto: durante el descenso la moneda recibe Steel; al apoyar en suelo firme, la regla 001_o la convierte en anclaje y el mismo resolver devuelve la reacción al jugador. Su diferencia es la selección/ubicación automática de la moneda y el sentido explícito hacia abajo.
5. El usuario aprobó tratar monedas apoyadas sobre adoquines/tierra compactada como ancladas para Steel, aun en empuje lateral. No simulamos deslizamiento lateral en terreno ordinario.
6. La última pulsación primaria entre Steel Q e Iron E toma la entrada; el anterior preserva momentum pero no se reactiva sin nueva pulsación. Una pulsación nueva de Q/E/F (botón derecho) también termina Coin Jump y entrega el objetivo/renderer al poder elegido.

## Límite de verificación
No había ejecutable Godot disponible en el entorno de preparación. Los tests añadidos son hipótesis verificables cuando se ejecute Godot 4.7.2; sus nombres y aserciones no significan que ya hayan pasado en runtime.
