# Investigación técnica — Steel en Mistborn

Fecha de revisión: 2026-10-11
Proyecto: Mistborn 001_n — Steel Traversal

## Referentes investigados

### Ashwalker (Unity, C#)
- Repositorio: https://github.com/HoleInWater/Ashwalker
- Código de SteelPush: https://github.com/HoleInWater/Ashwalker/blob/master/Assets/_Project/Scripts/Metallurgy/Metals/SteelPush.cs
- Manual físico: https://github.com/HoleInWater/Ashwalker/blob/master/docs/PHYSICS-MATH-BOOK.md
- Licencia consultada: MIT, https://github.com/HoleInWater/Ashwalker/blob/master/LICENSE
- Observaciones: SteelPush recalcula la dirección desde el origen del alomántico hacia el centro de masa del metal, actualiza la fuerza de manera continua durante la pulsación y diferencia objetivos ligeros de anclajes pesados. El manual describe tercera ley de Newton, masa, gravedad e inercia como base del comportamiento. El repo es una referencia implementada, no una fuente de valores universales; su fuerza y escalas son propias del juego.

### RigidBodyController (Godot, GDScript)
- Repositorio: https://github.com/FreeFlyFall/RigidBodyController
- Archivo principal: https://github.com/FreeFlyFall/RigidBodyController/blob/master/move.gd
- Licencia consultada: MIT (metadatos públicos del repositorio).
- Observaciones: demuestra cómo combinar fuerzas externas, impulso, inercia y control aéreo. Se estudió como referencia, no se sustituyó el CharacterBody3D de Mistborn ni se copió el controlador completo.

### Canon / reglas de Steel
- Referencia general: https://mistborn.fandom.com/wiki/Steel
- Las líneas azules conectan al alomántico con fuentes de metal; Steel empuja el metal directamente alejándolo. Objetos más ligeros salen despedidos; contra metales anclados o más pesados, la reacción desplaza al alomántico.

## Decisiones de implementación en Mistborn

1. Mantener Q como Steel y fijar un solo objetivo por pulsación; no hay reacquisición mientras siga pulsado.
2. Mantener `MistbornTargetable.apply_allomantic_interaction()` como autoridad de fuerza, masa y soporte; no crear un segundo modelo de Steel ni aplicar un impulso manual aparte.
3. Añadir una consulta predictiva sin efectos secundarios que usa exactamente la misma dirección de reacción, masa efectiva y cadena de soporte para decidir si una caída requiere recuperación.
4. Solo activar la amortiguación tipo trampoline cuando el jugador será el destinatario de la reacción. Los metales ligeros y libres reciben su empuje inmediatamente, incluso si el jugador está cayendo.
5. Cambiar la amortiguación vertical de velocidad lineal a decaimiento exponencial con umbral pequeño de reposo, y continuar el resolver normal en el mismo tick al terminar.
6. Latch del input Q si se solapa con entrada Iron para evitar adquirir Steel al soltar el otro botón manteniendo Q.
7. No alterar Iron, su cable virtual, su solver ni sus controles en esta iteración.

## Límites y validación

- No se copió un controlador comercial o de terceros completo. Las referencias MIT se estudiaron; el cambio de Mistborn reutiliza su arquitectura existente y los principios documentados.
- Las funciones matemáticas y las pruebas automatizadas están añadidas al proyecto, pero solo pueden certificarse al ejecutar `tools/run_player_core_playtest.bat` con Godot 4.7.2.
- No se afirma compilación, estabilidad de física ni calidad final del feel en runtime dentro de este entorno.
