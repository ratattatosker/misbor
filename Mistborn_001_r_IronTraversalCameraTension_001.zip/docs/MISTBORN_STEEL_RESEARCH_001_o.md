# Investigación técnica — Steel 001_o: monedas ancladas en suelo

Fecha: 2026-10-11

## Decisión de diseño
Las monedas en el suelo típico de la ciudad (adoquines/tierra compactada) se consideran anclajes completos para Steel, también ante una línea de fuerza principalmente lateral. No implementamos deslizamiento lateral de monedas sobre ese suelo. Es una simplificación explícita de jugabilidad y de representación del terreno, no una afirmación de que todas las superficies reales tengan fricción infinita.

## Regla
- Aire: moneda ligera, recibe el empuje.
- Contacto firme con el suelo de la ciudad: Steel trata la moneda como anclaje estático, sea cual sea el ángulo del empuje.
- En una interacción mantenida, aterrizar cambia el destinatario de la reacción a jugador en el mismo sistema de Steel.
- La excepción no cambia Iron ni el modelo de otras clases de objetos.

## Implementación
- `MistbornCoin.has_firm_ground_anchor_for_steel()` lanza un raycast estrecho bajo el punto más bajo estimado de la moneda y comprueba una normal de suelo.
- `MistbornAllomanticForceModel.grounded_coin_anchor_mass()` centraliza la política y devuelve masa de anclaje estático solo para Steel sobre un target `COIN` en contacto firme.
- `MistbornTargetable.apply_allomantic_interaction()` y `predicts_player_receives_allomantic_response()` usan la misma consulta.
- Test determinista añadido: `STEEL_GROUNDED_COIN_ANCHOR_POLICY`.

## Fuentes de referencia
- Regla general de Steel/monedas en suelo: https://mistborn.fandom.com/wiki/Steel
- Reglas de Steelpush en *Mistborn Adventure Game* (2011): https://files.spawningpool.net/docs/Vault2.0.-.TTRPG-Gamebooks/Mistborn/Mistborn%20Adventure%20Game%20-%20Core%20Rulebook%20%282011%29%20%7BCFG8001%7D.pdf
- Discusión con aportes del desarrollador del prototipo Invested sobre monedas ancladas frente a monedas en caída: https://www.17thshard.com/forums/topic/74011-the-open-secret-that-steelpushing-makes-no-sense/

## Estado de validación
Revisión estática en preparación; Godot 4.7.2 no se ejecutó. La detección geométrica y el comportamiento de la transición deben probarse en runtime.
