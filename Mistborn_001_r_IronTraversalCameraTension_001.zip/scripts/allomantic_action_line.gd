class_name MistbornAllomanticActionLine
extends MeshInstance3D

const ACTION_LINE_SHADER: Shader = preload("res://scripts/allomantic_sight_lines.gdshader")
const FORCE_MODEL = preload("res://scripts/allomantic_force_model.gd")

var _mesh: CylinderMesh
var _material: ShaderMaterial
var _active: bool = false

func _ready() -> void:
	_mesh = CylinderMesh.new()
	_mesh.radial_segments = 8
	_mesh.rings = 1
	_mesh.top_radius = 0.055
	_mesh.bottom_radius = 0.055
	_mesh.height = 1.0
	_material = ShaderMaterial.new()
	_material.shader = ACTION_LINE_SHADER
	mesh = _mesh
	material_override = _material
	cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	gi_mode = GeometryInstance3D.GI_MODE_DISABLED
	visible = false

func set_line(origin: Vector3, target: Vector3, color: Color, width: float = 0.055) -> void:
	if _mesh == null:
		return
	var axis := target - origin
	var distance := axis.length()
	if distance <= 0.001:
		clear_line()
		return
	if distance > FORCE_MODEL.ALLOMANTIC_RADIUS + 0.001:
		# Active Allomancy exists only inside the same 35 m sphere as the action range.
		clear_line()
		return
	axis /= distance

	# A volumetric tube removes the unstable ribbon-plane problem entirely.
	# Its local Y axis is the Allomantic connection axis; camera translation and
	# camera-facing calculations never participate in the line orientation.
	var reference := Vector3.UP
	if abs(axis.dot(reference)) > 0.985:
		reference = Vector3.RIGHT
	var x_axis := reference.cross(axis).normalized()
	var z_axis := axis.cross(x_axis).normalized()
	global_position = (origin + target) * 0.5
	global_basis = Basis(x_axis, axis, z_axis)

	_mesh.height = distance
	var radius := clampf(width * 0.5, 0.028, 0.060)
	_mesh.top_radius = radius
	_mesh.bottom_radius = radius
	_mesh.radial_segments = 8
	_material.set_shader_parameter("sight_color", color)
	_material.set_shader_parameter("glow_strength", 4.2)
	_material.set_shader_parameter("pulse_speed", 1.1)
	_material.set_shader_parameter("turbulence", 0.0)
	_material.set_shader_parameter("speck_strength", 0.0)
	_active = true
	visible = true

func clear_line() -> void:
	_active = false
	visible = false

func is_line_active() -> bool:
	return _active
