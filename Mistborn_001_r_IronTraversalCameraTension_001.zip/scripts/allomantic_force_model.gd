class_name MistbornAllomanticForceModel
extends RefCounted

## Feel-first traversal model.
## Shared power authority: Steel and Iron, including Steel's special coin interaction,
## derive their gameplay power from this single model so a power reduction cannot leave
## the Steel pathways out of sync.
## The numbers are gameplay controls, not claims about a literal Cosmere equation.
## The goal is that metal is perceived as the cause of motion while the player
## retains immediate, comfortable control.

const ALLOMANTIC_RADIUS: float = 35.0
const SHARED_RANGE: float = ALLOMANTIC_RADIUS
const COMFORT_PUSH_DISTANCE: float = 16.0
const STRONG_PUSH_DISTANCE: float = 24.0
const EXCEPTIONAL_PUSH_DISTANCE: float = 30.0
const PLAYER_MASS: float = 75.0
const BASE_FORCE_NEWTONS: float = 1450.0
const MAX_TRAVERSAL_SPEED: float = 34.0
const HERO_STRENGTH: float = 1.20

## Binary mass-response model. There is no proportional sharing for the current pass:
## lighter target -> target receives the interaction; target as heavy as/heavier
## than the player -> player receives the interaction. Support mass is added to
## the target mass before this comparison.
const STATIC_EFFECTIVE_MASS: float = 1000000.0
const MAX_TARGET_RESPONSE_ACCELERATION: float = 80.0
const MAX_BLOCKING_CHAIN_DEPTH: int = 16
const BLOCKING_CHAIN_PROBE_DISTANCE: float = 2.0

static func effective_interaction_mass(target_mass: float, support_mass: float) -> float:
	return maxf(target_mass, 0.001) + maxf(support_mass, 0.0)

static func target_is_lighter_than_player(player_mass: float, effective_target_mass: float) -> bool:
	# Equality is treated as the heavy side for this binary pass: the player moves.
	return maxf(effective_target_mass, 0.001) < maxf(player_mass, 0.001)

static func player_receives_response(player_mass: float, effective_target_mass: float) -> bool:
	return not target_is_lighter_than_player(player_mass, effective_target_mass)

static func target_receives_response(player_mass: float, effective_target_mass: float) -> bool:
	return target_is_lighter_than_player(player_mass, effective_target_mass)

static func grounded_coin_anchor_mass(action_name: StringName, target_type: String, has_firm_ground_contact: bool) -> float:
	# Mistborn gameplay assumption: coins resting on Scadrian cobblestone or compacted earth
	# are treated as fully anchored for Steel, regardless of the push line's horizontal angle.
	# This intentionally does not simulate lateral coin skidding on common street surfaces.
	# Airborne coins remain light projectiles until firm ground contact is detected.
	if action_name == &"steel" and target_type.to_upper() == "COIN" and has_firm_ground_contact:
		return STATIC_EFFECTIVE_MASS
	return 0.0

static func target_force_for_mass(force_magnitude_value: float, target_mass: float) -> float:
	var mass := maxf(target_mass, 0.001)
	return minf(maxf(force_magnitude_value, 0.0), mass * MAX_TARGET_RESPONSE_ACCELERATION)

static func effective_mass_from_profile(profile: StringName, declared_mass: float) -> float:
	if declared_mass > 0.0:
		return declared_mass
	match profile:
		&"ANCHOR": return STATIC_EFFECTIVE_MASS
		&"PROJECTILE": return 0.03
		&"CHARACTER": return PLAYER_MASS
		&"SMALL_OBJECT": return 8.0
		&"DECORATIVE": return 150.0
	return 100.0

static func range_factor(distance: float) -> float:
	var t := clampf(distance / SHARED_RANGE, 0.0, 1.0)
	# Traversal calibration: keep a strong, readable response in the comfortable
	# single-push envelope (~12–18 m), while making the 35 m shared range a reach
	# limit rather than a promise of one-push travel.
	return clampf(1.0 - 0.58 * pow(t, 0.85), 0.42, 1.0)

static func force_magnitude(distance: float, strength: float = 1.0) -> float:
	return BASE_FORCE_NEWTONS * range_factor(distance) * maxf(strength, 0.0)

static func player_acceleration(distance: float, strength: float = 1.0) -> float:
	return force_magnitude(distance, strength) / PLAYER_MASS

static func calculate_steel_counterfall_strength(
	base_strength: float,
	distance: float,
	player_mass: float,
	gravity: float,
	vertical_velocity: float,
	player_reaction_direction: Vector3,
	player_receives_response: bool,
	desired_stop_time: float = 0.42,
	max_strength_scale: float = 8.0,
	minimum_upward_component: float = 0.45
) -> float:
	# Counter-fall is still Steel's real force through the shared resolver. It does
	# not edit CharacterBody3D.velocity, pause gravity, or invent a second impulse.
	# Scale force only while the actor is falling and the same support/mass solver
	# predicts that the actor receives a sufficiently upward Steel reaction.
	var safe_base := maxf(base_strength, 0.001)
	if not player_receives_response or vertical_velocity >= -0.05:
		return safe_base
	if player_reaction_direction.length_squared() <= 0.0001:
		return safe_base
	var reaction := player_reaction_direction.normalized()
	var upward_component := reaction.y
	if upward_component < clampf(minimum_upward_component, 0.0, 1.0):
		return safe_base
	var mass := maxf(player_mass, 1.0)
	var base_force := force_magnitude(distance, safe_base)
	var base_vertical_acceleration := (base_force / mass) * upward_component
	if base_vertical_acceleration <= 0.001:
		return safe_base
	# To stop a fall in the target time, the upward acceleration must first
	# cancel gravity and then remove the current downward velocity over that time.
	var required_vertical_acceleration := maxf(gravity, 0.0) + absf(vertical_velocity) / maxf(desired_stop_time, 0.05)
	var required_scale := required_vertical_acceleration / base_vertical_acceleration
	var cap := maxf(max_strength_scale, 1.0)
	return safe_base * clampf(maxf(required_scale, 1.0), 1.0, cap)

static func shared_range() -> float:
	return SHARED_RANGE

static func comfort_push_distance() -> float:
	return COMFORT_PUSH_DISTANCE

static func strong_push_distance() -> float:
	return STRONG_PUSH_DISTANCE

static func exceptional_push_distance() -> float:
	return EXCEPTIONAL_PUSH_DISTANCE


