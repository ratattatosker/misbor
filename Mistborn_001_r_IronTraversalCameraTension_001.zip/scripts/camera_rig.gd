class_name MistbornCameraRig
extends Node3D

@export_category("Look")
@export var mouse_sensitivity: float = 0.08
@export var min_pitch_deg: float = -72.0
@export var max_pitch_deg: float = 62.0
@export var look_smoothing: float = 24.0
@export var camera_follow_speed: float = 2.6
@export var camera_follow_start_speed: float = 2.8
@export var camera_follow_strength: float = 0.78
@export_range(0.05, 0.75, 0.05) var allomancy_traversal_camera_follow_strength: float = 0.32
@export_range(20.0, 160.0, 5.0) var normal_camera_max_yaw_rate_degrees: float = 120.0
@export_range(20.0, 120.0, 5.0) var allomancy_camera_max_yaw_rate_degrees: float = 75.0

@export_category("Distance")
@export var camera_distance: float = 4.5
@export var min_camera_distance: float = 1.8
@export var camera_collision_margin: float = 0.18
@export var distance_smoothing: float = 20.0

@export_category("Follow")
@export var follow_height: float = 1.45

@export_category("Game Feel")
@export var base_fov: float = 70.0
@export var traversal_fov: float = 82.0
@export var high_speed_fov: float = 92.0
@export var sprint_fov: float = 75.0
@export var fov_smoothing: float = 8.0
@export var traversal_distance_bonus: float = 0.75
@export var traversal_look_assist_degrees: float = 9.0
@export var traversal_look_assist_speed: float = 6.0
@export var high_speed_distance_bonus: float = 0.85

var _yaw: float = 0.0
var _pitch: float = deg_to_rad(-12.0)
var _current_distance: float = 4.5
var _mouse_capture: bool = true
var _camera: Camera3D
var _player: CharacterBody3D
var _look_idle_left := 0.0
var _last_auto_follow_yaw_delta: float = 0.0
var _last_auto_follow_mode: String = "IDLE"

func _ready() -> void:
	_camera = $Camera3D
	_player = get_parent() as CharacterBody3D
	_current_distance = camera_distance
	rotation.y = _yaw
	rotation.x = _pitch
	_capture_mouse()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and _mouse_capture:
		var motion := event as InputEventMouseMotion
		_look_idle_left = 0.18
		_yaw -= deg_to_rad(motion.relative.x * mouse_sensitivity)
		_pitch -= deg_to_rad(motion.relative.y * mouse_sensitivity)
		_pitch = clampf(_pitch, deg_to_rad(min_pitch_deg), deg_to_rad(max_pitch_deg))
		return

	if event is InputEventMouseButton and (event as InputEventMouseButton).pressed:
		_capture_mouse()
		return

	if event is InputEventKey and (event as InputEventKey).pressed and not (event as InputEventKey).echo:
		var key := event as InputEventKey
		if key.physical_keycode == KEY_ESCAPE:
			_release_mouse()

func _process(delta: float) -> void:
	_look_idle_left = maxf(_look_idle_left - delta, 0.0)
	_last_auto_follow_yaw_delta = 0.0
	_last_auto_follow_mode = "IDLE"
	# Input state is the reliable same-frame guard: the controller's active flag
	# is updated later in PlayerController._physics_process.
	var allomantic_input_held := Input.is_action_pressed("steel_push") or Input.is_action_pressed("iron_pull") or Input.is_action_pressed("iron_yank")
	if Input.is_action_just_pressed("release_mouse"):
		_release_mouse()
	rotation.y = lerp_angle(rotation.y, _yaw, minf(look_smoothing * delta, 1.0))
	rotation.x = lerpf(rotation.x, _pitch, minf(look_smoothing * delta, 1.0))

	var horizontal_speed := 0.0
	var traversal_active := false
	if _player != null:
		horizontal_speed = Vector3(_player.velocity.x, 0.0, _player.velocity.z).length()
		var traversal: MistbornTraversalController = _player.get_node_or_null("Traversal") as MistbornTraversalController
		var steel: MistbornSteelController = _player.get_node_or_null("Steel") as MistbornSteelController
		var iron: MistbornIronController = _player.get_node_or_null("Iron") as MistbornIronController
		traversal_active = (traversal != null and ((not _player.is_on_floor() and traversal.has_method("get_traversal_state") and String(traversal.get_traversal_state()).begins_with("FLIGHT")))) or (steel != null and steel.has_method("is_active") and steel.is_active()) or (iron != null and iron.has_method("is_active") and iron.is_active())

	var speed_ratio := clampf(horizontal_speed / 18.0, 0.0, 1.0)
	var allomancy_active := false
	if _player != null:
		var steel_for_camera: MistbornSteelController = _player.get_node_or_null("Steel") as MistbornSteelController
		var iron_for_camera: MistbornIronController = _player.get_node_or_null("Iron") as MistbornIronController
		var traversal_for_camera: MistbornTraversalController = _player.get_node_or_null("Traversal") as MistbornTraversalController
		allomancy_active = (steel_for_camera != null and steel_for_camera.has_method("is_active") and steel_for_camera.is_active()) or (iron_for_camera != null and iron_for_camera.has_method("is_active") and iron_for_camera.is_active())
	var velocity_dir := Vector3.ZERO
	if _player != null and horizontal_speed > 0.25:
		velocity_dir = Vector3(_player.velocity.x, 0.0, _player.velocity.z).normalized()

	# Camera Follow: once the mouse has been idle, let the camera gently catch up
	# to travel direction even during Iron/Steel traversal. Manual mouse look always
	# wins for the full idle grace window. Allomancy uses a lower follow gain and a
	# strict yaw-rate cap so the camera supports velocity readability without steering
	# against player intent or snapping around during fast swings.
	var manual_look_has_priority := _look_idle_left > 0.0
	if manual_look_has_priority:
		_last_auto_follow_mode = "MANUAL_PRIORITY"
	if not manual_look_has_priority and _player != null and velocity_dir.length_squared() > 0.001 and horizontal_speed >= camera_follow_start_speed:
		var camera_dir := -global_transform.basis.z
		camera_dir.y = 0.0
		if camera_dir.length_squared() > 0.001:
			camera_dir = camera_dir.normalized()
			var follow_angle := atan2(camera_dir.cross(velocity_dir).y, camera_dir.dot(velocity_dir))
			var follow_strength := camera_follow_strength
			var max_yaw_rate := normal_camera_max_yaw_rate_degrees
			if traversal_active and allomancy_active:
				follow_strength = allomancy_traversal_camera_follow_strength
				max_yaw_rate = allomancy_camera_max_yaw_rate_degrees
			elif traversal_active:
				follow_strength = 1.0
			var follow_response := camera_follow_speed * follow_strength
			_last_auto_follow_yaw_delta = calculate_auto_follow_yaw_delta(follow_angle, follow_response, delta, max_yaw_rate)
			if absf(_last_auto_follow_yaw_delta) > 0.00001:
				_last_auto_follow_mode = "ALLOMANCY_TRAVERSAL" if traversal_active and allomancy_active else ("TRAVERSAL" if traversal_active else "NORMAL")
			_yaw += _last_auto_follow_yaw_delta

	if not allomancy_active and not allomantic_input_held and traversal_active and _player != null and velocity_dir.length_squared() > 0.001:
		var camera_dir := -global_transform.basis.z
		camera_dir.y = 0.0
		if camera_dir.length_squared() > 0.001:
			camera_dir = camera_dir.normalized()
			var assist_angle := atan2(camera_dir.cross(velocity_dir).y, camera_dir.dot(velocity_dir))
			var max_assist := deg_to_rad(traversal_look_assist_degrees)
			assist_angle = clampf(assist_angle, -max_assist, max_assist)
			_yaw += assist_angle * minf(traversal_look_assist_speed * delta, 1.0) * 0.55

	var target_fov := base_fov
	if traversal_active:
		target_fov = lerpf(traversal_fov, high_speed_fov, speed_ratio)
	elif horizontal_speed >= 5.6:
		target_fov = lerpf(base_fov, sprint_fov, clampf(horizontal_speed / 7.4, 0.0, 1.0))
	_camera.fov = lerpf(_camera.fov, target_fov, minf(fov_smoothing * delta, 1.0))

	position.y = follow_height + speed_ratio * 0.08
	# Small banking cue: enough to communicate lateral re-direction, never enough
	# to make the camera feel like it is steering the player.
	var desired_roll := 0.0
	if not allomancy_active and not allomantic_input_held and traversal_active and _player != null:
		var local_velocity := global_transform.basis.inverse() * _player.velocity
		desired_roll = clampf(-local_velocity.x / 28.0, -0.08, 0.08)
	rotation.z = lerpf(rotation.z, desired_roll, minf(9.0 * delta, 1.0))
	var distance_bonus := 0.0
	if traversal_active:
		distance_bonus = traversal_distance_bonus
		if horizontal_speed > 14.0:
			distance_bonus += high_speed_distance_bonus * speed_ratio
	var desired_distance := _solve_camera_distance(camera_distance + distance_bonus)
	_current_distance = lerpf(_current_distance, desired_distance, minf(distance_smoothing * delta, 1.0))
	_camera.position = Vector3(0.0, 0.0, _current_distance)

	if _player != null:
		var fade := 1.0
		if _current_distance < 2.8:
			fade = remap(_current_distance, min_camera_distance, 2.8, 0.35, 1.0)
		if _player.has_method("set_camera_occlusion_fade"):
			_player.set_camera_occlusion_fade(fade)

static func calculate_auto_follow_yaw_delta(follow_angle: float, response: float, delta: float, max_yaw_rate_degrees: float) -> float:
	if delta <= 0.0 or response <= 0.0 or max_yaw_rate_degrees <= 0.0:
		return 0.0
	var requested_delta := follow_angle * minf(maxf(response, 0.0) * delta, 1.0)
	var maximum_delta := deg_to_rad(maxf(max_yaw_rate_degrees, 0.0)) * delta
	return clampf(requested_delta, -maximum_delta, maximum_delta)

func _solve_camera_distance(desired_distance: float = -1.0) -> float:
	if desired_distance <= 0.0:
		desired_distance = camera_distance
	var from := global_position
	var to := global_position + global_transform.basis * Vector3(0.0, 0.0, desired_distance)
	var params := PhysicsRayQueryParameters3D.create(from, to)
	params.collision_mask = 1
	params.collide_with_areas = false
	params.collide_with_bodies = true
	if _player != null:
		params.exclude = [_player.get_rid()]
	else:
		var empty_exclude: Array[RID] = []
		params.exclude = empty_exclude

	var hit := get_world_3d().direct_space_state.intersect_ray(params)
	if hit.is_empty():
		return desired_distance

	var hit_position_variant: Variant = hit.get("position")
	if not hit_position_variant is Vector3:
		return desired_distance
	var hit_position: Vector3 = hit_position_variant
	var safe_distance := from.distance_to(hit_position) - camera_collision_margin
	return clampf(safe_distance, min_camera_distance, desired_distance)

func reset_for_playtest(yaw_deg: float = 0.0, pitch_deg: float = -12.0) -> void:
	_yaw = deg_to_rad(yaw_deg)
	_pitch = deg_to_rad(pitch_deg)
	_look_idle_left = 0.0
	_current_distance = camera_distance
	rotation.y = _yaw
	rotation.x = _pitch
	rotation.z = 0.0
	if _camera != null:
		_camera.fov = base_fov

func set_playtest_look(yaw_deg: float, pitch_deg: float = -12.0) -> void:
	_yaw = deg_to_rad(yaw_deg)
	_pitch = clampf(deg_to_rad(pitch_deg), deg_to_rad(min_pitch_deg), deg_to_rad(max_pitch_deg))
	_look_idle_left = 9999.0
	rotation.y = _yaw
	rotation.x = _pitch


func _capture_mouse() -> void:
	_mouse_capture = true
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _release_mouse() -> void:
	_mouse_capture = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func get_debug_state() -> Dictionary:
	return {
		"yaw_deg": rad_to_deg(rotation.y),
		"pitch_deg": rad_to_deg(rotation.x),
		"distance": _current_distance,
		"mouse_captured": _mouse_capture,
		"auto_follow_mode": _last_auto_follow_mode,
		"auto_follow_yaw_delta_deg": rad_to_deg(_last_auto_follow_yaw_delta),
		"allomancy_follow_strength": allomancy_traversal_camera_follow_strength,
		"allomancy_max_yaw_rate_deg_s": allomancy_camera_max_yaw_rate_degrees
	}
