class_name MistbornCoin
extends RigidBody3D

@export_category("Coin")
@export var coin_radius: float = 0.16
@export_category("Allomancy")
@export var coin_thickness: float = 0.05
@export var coin_ground_mask: int = 1

var _targetable: MistbornTargetable
var _projectile_active := false
var _ground_contact := false
var _steel_special_protected := false
var _steel_special_response_pending := false
var _steel_special_force_ticks := 0
var _steel_special_ground_force_ticks := 0
var _projectile_lifetime := 0.0
var _projectile_material: StandardMaterial3D
var _visual_mesh: MeshInstance3D
var _player_ref: CharacterBody3D
var _pickup_lock_left: float = 0.0
@export var auto_collect_on_contact: bool = true
@export var pickup_radius: float = 0.82
@export var pickup_center_height: float = 0.90
@export var world_coin_selection_priority: float = 0.02

func _ready() -> void:
	add_to_group("mistborn_coin_body")
	collision_layer = 0
	collision_mask = coin_ground_mask
	gravity_scale = 1.0
	mass = 0.03
	linear_damp = 0.15
	angular_damp = 1.25
	continuous_cd = true
	_player_ref = get_tree().get_first_node_in_group("mistborn_player") as CharacterBody3D
	_build_physical_collision()
	_build_coin_visual()
	_build_target_proxy()

func configure_target_id(value: String) -> void:
	if _targetable == null or not is_instance_valid(_targetable):
		return
	_targetable.target_id = value
	name = value

func get_targetable() -> MistbornTargetable:
	return _targetable if _targetable != null and is_instance_valid(_targetable) else null


func _build_target_proxy() -> void:
	_targetable = MistbornTargetable.new()
	_targetable.name = "Targetable"
	_targetable.display_name = "Moneda"
	_targetable.target_type = "COIN"
	# Las monedas que están sueltas y no forman parte de la acción actual son
	# objetivos de último recurso. Siguen siendo seleccionables, pero nunca deben
	# robar protagonismo a anclas u objetos contextuales.
	_targetable.selection_priority = 0.02
	_targetable.target_size_priority = 0.15
	_targetable.target_height_priority = 0.30
	_targetable.target_accessibility = 0.50
	_targetable.is_metallic = true
	_targetable.steel_pushable = true
	_targetable.iron_pullable = true
	_targetable.allomantic_profile = "PROJECTILE"
	_targetable.allomantic_visual_mass = 0.03
	_targetable.show_in_allomantic_sight = true
	_targetable.requires_line_of_sight = true
	_targetable.set_physical_body(self)
	var collision := CollisionShape3D.new()
	collision.name = "TargetCollision"
	var shape := CylinderShape3D.new()
	shape.radius = coin_radius * 1.2
	shape.height = coin_thickness * 1.4
	collision.shape = shape
	_targetable.add_child(collision)
	add_child(_targetable)

func _build_physical_collision() -> void:
	var collision := CollisionShape3D.new()
	collision.name = "CoinPhysicalCollision"
	var shape := CylinderShape3D.new()
	shape.radius = coin_radius
	shape.height = coin_thickness
	collision.shape = shape
	add_child(collision)

func _build_coin_visual() -> void:
	_visual_mesh = MeshInstance3D.new()
	_visual_mesh.name = "CoinVisual"
	var mesh := CylinderMesh.new()
	mesh.top_radius = coin_radius
	mesh.bottom_radius = coin_radius
	mesh.height = coin_thickness
	mesh.radial_segments = 24
	_visual_mesh.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.68, 0.52, 0.18, 1.0)
	material.metallic = 0.92
	material.roughness = 0.28
	_projectile_material = material
	_visual_mesh.material_override = material
	_visual_mesh.rotation_degrees.x = 8.0
	add_child(_visual_mesh)

func _physics_process(delta: float) -> void:
	_pickup_lock_left = maxf(_pickup_lock_left - delta, 0.0)
	_process_projectile_collision(delta)
	_process_auto_pickup()


func _process_auto_pickup() -> void:
	if _steel_special_protected or not auto_collect_on_contact or not is_inside_tree() or not visible:
		return
	var player: CharacterBody3D = _player_ref
	if player == null or not is_instance_valid(player):
		_player_ref = get_tree().get_first_node_in_group("mistborn_player") as CharacterBody3D
		player = _player_ref
	if player == null or not is_instance_valid(player):
		return
	if _pickup_lock_left > 0.0:
		return
	var pickup_center: Vector3 = player.global_position + Vector3.UP * pickup_center_height
	if global_position.distance_to(pickup_center) > pickup_radius:
		return
	collect_into_inventory(player)

func collect_into_inventory(actor: Node3D) -> bool:
	if actor == null or not is_instance_valid(actor):
		return false
	if _targetable == null or not is_instance_valid(_targetable):
		return false
	var player := actor as CharacterBody3D
	if player == null:
		return false
	var traversal := player.get_node_or_null("Traversal") as MistbornTraversalController
	if traversal == null:
		return false
	if not traversal.collect_world_coin(self):
		return false
	var pool := get_tree().get_first_node_in_group("mistborn_coin_pool") as MistbornCoinPool
	if pool != null and is_instance_valid(pool):
		pool.reclaim(self)
	else:
		queue_free()
	return true

func set_steel_special_protected(value: bool) -> void:
	_steel_special_protected = value
	if value:
		auto_collect_on_contact = false

func is_steel_special_protected() -> bool:
	return _steel_special_protected

func begin_steel_special_drop() -> void:
	_steel_special_force_ticks = 0
	_steel_special_ground_force_ticks = 0
	if _player_ref == null or not is_instance_valid(_player_ref):
		_player_ref = get_tree().get_first_node_in_group("mistborn_player") as CharacterBody3D
	if _player_ref != null and is_instance_valid(_player_ref):
		add_collision_exception_with(_player_ref)
	_projectile_active = true
	_ground_contact = false
	_steel_special_protected = true
	_steel_special_response_pending = true
	_pickup_lock_left = 0.20
	_projectile_lifetime = 4.0
	gravity_scale = 1.0
	freeze = false
	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO
	auto_collect_on_contact = false
	if _targetable != null and is_instance_valid(_targetable):
		_targetable.selectable = true
	if _projectile_material != null:
		_projectile_material.emission_enabled = true
		_projectile_material.emission = Color(0.78, 0.60, 0.18, 1.0)
		_projectile_material.emission_energy_multiplier = 3.0

func launch_physical_projectile(direction: Vector3, speed: float = 25.0) -> void:
	if _player_ref == null or not is_instance_valid(_player_ref):
		_player_ref = get_tree().get_first_node_in_group("mistborn_player") as CharacterBody3D
	if _player_ref != null and is_instance_valid(_player_ref):
		add_collision_exception_with(_player_ref)
	_projectile_active = true
	_ground_contact = false
	_steel_special_protected = false
	_pickup_lock_left = 0.14
	freeze = false
	_projectile_lifetime = 4.0
	gravity_scale = 1.0
	freeze = false
	linear_velocity = direction.normalized() * speed
	angular_velocity = Vector3.ZERO
	if _projectile_material != null:
		_projectile_material.emission_enabled = true
		_projectile_material.emission = Color(0.78, 0.60, 0.18, 1.0)
		_projectile_material.emission_energy_multiplier = 3.0

func _orient_visual_to_surface(surface_normal: Vector3) -> void:
	if _visual_mesh == null or not is_instance_valid(_visual_mesh):
		return
	var y_axis := surface_normal.normalized()
	if y_axis.length_squared() <= 0.0001:
		y_axis = Vector3.UP
	# CylinderMesh uses local Y for the coin-face normal. Choose a reference axis
	# that is not parallel to the hit normal, then make a stable orthonormal basis.
	var reference := Vector3.UP
	if absf(reference.dot(y_axis)) > 0.98:
		reference = Vector3.FORWARD
	var x_axis := reference.cross(y_axis).normalized()
	if x_axis.length_squared() <= 0.0001:
		reference = Vector3.RIGHT
		x_axis = reference.cross(y_axis).normalized()
	var z_axis := x_axis.cross(y_axis).normalized()
	_visual_mesh.global_basis = Basis(x_axis, y_axis, z_axis).orthonormalized()

func _process_projectile_collision(delta: float) -> void:
	if not _projectile_active:
		return
	_projectile_lifetime -= delta
	if _projectile_lifetime <= 0.0:
		_projectile_cancel()
		return
	var world := get_world_3d()
	if world == null:
		return
	var from := global_position
	var to := from + linear_velocity * delta
	var query := PhysicsRayQueryParameters3D.create(from, to)
	# Una moneda también debe reconocer superficies físicas del mundo. Antes la
	# consulta solo veía Areas (targets), por lo que un edificio no producía una
	# respuesta de impacto explícita.
	query.collision_mask = 1 | 2
	query.collide_with_bodies = true
	query.collide_with_areas = true
	var exclude_ids: Array[RID] = [get_rid()]
	if _player_ref != null and is_instance_valid(_player_ref):
		exclude_ids.append(_player_ref.get_rid())
	if _targetable != null and is_instance_valid(_targetable):
		exclude_ids.append(_targetable.get_rid())
	query.exclude = exclude_ids
	var hit := world.direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return
	var collider_variant: Variant = hit.get("collider")
	var hit_position: Variant = hit.get("position", global_position)
	var hit_normal: Variant = hit.get("normal", Vector3.UP)
	if hit_position is Vector3:
		# Deja la moneda justo contra la superficie, evitando enterrarla en el
		# edificio por un pequeño margen numérico.
		var normal: Vector3 = Vector3.UP
		if hit_normal is Vector3:
			var candidate_normal: Vector3 = hit_normal
			if candidate_normal.length_squared() > 0.0001:
				normal = candidate_normal.normalized()
		global_position = hit_position + normal * 0.012
		if _visual_mesh != null:
			_orient_visual_to_surface(normal)
	if collider_variant is MistbornTargetable:
		var collider: MistbornTargetable = collider_variant
		if collider.has_method("receive_coin_hit"):
			var direction: Vector3 = linear_velocity.normalized()
			collider.call("receive_coin_hit", 30.0, direction)

	# The special Steel coin remains a normal physical object. Contact with the floor
	# only ends its temporary protection and returns it to ordinary pickup behavior.
	var floor_contact: bool = false
	if hit_normal is Vector3:
		var normal_for_ground: Vector3 = (hit_normal as Vector3).normalized()
		var hit_is_ground_layer: bool = false
		if collider_variant is CollisionObject3D:
			hit_is_ground_layer = (collider_variant as CollisionObject3D).get_collision_layer_value(1)
		floor_contact = hit_is_ground_layer and normal_for_ground.y >= 0.55

	if floor_contact:
		_ground_contact = true
		# A special coin stays protected and remains the active Steel target after
		# contact. SteelController continues the same sustained interaction against
		# the blocked coin while it remains valid and inside shared range; no impulse is emitted.
		if not _steel_special_response_pending:
			_steel_special_protected = false
			auto_collect_on_contact = true
			_pickup_lock_left = maxf(_pickup_lock_left, 0.35)
		linear_velocity = Vector3.ZERO
		angular_velocity = Vector3.ZERO
		freeze = false
		_projectile_active = false
		gravity_scale = 1.0
		if not _steel_special_response_pending and _projectile_material != null:
			_projectile_material.emission_enabled = false
	else:
		# A wall/target hit does not finish the special Steel interaction. The coin
		# remains physical and continues toward the floor.
		_ground_contact = false

func _projectile_cancel() -> void:
	_projectile_active = false
	gravity_scale = 1.0
	linear_velocity = Vector3.ZERO
	if _steel_special_response_pending:
		finish_steel_special_interaction()
	else:
		_steel_special_protected = false
	if _projectile_material != null:
		_projectile_material.emission_enabled = false

func is_grounded_on_solid() -> bool:
	var world := get_world_3d()
	if world == null:
		return false
	var from := global_position + Vector3.UP * 0.03
	var to := global_position + Vector3.DOWN * 0.24
	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.collision_mask = coin_ground_mask
	query.collide_with_bodies = true
	query.collide_with_areas = false
	query.exclude = [get_rid()]
	return not world.direct_space_state.intersect_ray(query).is_empty()

func has_ground_contact() -> bool:
	return _ground_contact

func has_firm_ground_anchor_for_steel() -> bool:
	# Canonical game rule: coins in contact with the usual cobblestone/compacted-earth
	# street ground are a stable Steel anchor in any push direction; do not simulate
	# lateral skidding. A newly impacted, stationary coin can trust its collision flag
	# for the immediate resting state; moving coins must pass the short geometric probe
	# so the flag cannot keep a coin anchored after it rolls/falls off an edge.
	if _ground_contact and linear_velocity.length_squared() <= 0.04 and angular_velocity.length_squared() <= 0.04:
		return true
	# The small probe tolerance covers solver jitter without treating a genuinely airborne
	# coin as anchored. Terrain uses coin_ground_mask (normally the solid world layer).
	var world := get_world_3d()
	if world == null:
		return false
	var local_y_axis := global_transform.basis.y.normalized()
	var axis_up_dot := clampf(absf(local_y_axis.dot(Vector3.UP)), 0.0, 1.0)
	var vertical_half_extent := coin_radius * sqrt(maxf(0.0, 1.0 - axis_up_dot * axis_up_dot)) + (coin_thickness * 0.5 * axis_up_dot)
	var lowest_point := global_position - Vector3.UP * vertical_half_extent
	var from := lowest_point + Vector3.UP * 0.018
	var to := lowest_point - Vector3.UP * 0.025
	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.collision_mask = coin_ground_mask
	query.collide_with_bodies = true
	query.collide_with_areas = false
	var excluded: Array[RID] = [get_rid()]
	if _targetable != null and is_instance_valid(_targetable):
		excluded.append(_targetable.get_rid())
	query.exclude = excluded
	var hit := world.direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return false
	var normal_variant: Variant = hit.get("normal", Vector3.ZERO)
	if not normal_variant is Vector3:
		return false
	return (normal_variant as Vector3).normalized().dot(Vector3.UP) >= 0.55

func is_projectile_active() -> bool:
	return _projectile_active

func is_steel_special_response_pending() -> bool:
	return _steel_special_response_pending

func record_steel_special_force_tick(ground_phase: bool) -> void:
	_steel_special_force_ticks += 1
	if ground_phase:
		_steel_special_ground_force_ticks += 1

func finish_steel_special_interaction() -> void:
	_steel_special_response_pending = false
	_steel_special_protected = false
	auto_collect_on_contact = true
	_pickup_lock_left = maxf(_pickup_lock_left, 0.35)
	if _projectile_material != null:
		_projectile_material.emission_enabled = false

func get_debug_state() -> Dictionary:
	var phase := "INACTIVE"
	if _steel_special_response_pending:
		phase = "GROUND_PUSH" if _ground_contact else "DESCENT"
	return {
		"target_id": _targetable.target_id if _targetable != null and is_instance_valid(_targetable) else "",
		"linear_velocity": linear_velocity,
		"projectile_active": _projectile_active,
		"ground_contact": _ground_contact,
		"steel_special_protected": _steel_special_protected,
		"steel_special_response_pending": _steel_special_response_pending,
		"steel_special_phase": phase,
		"steel_special_force_ticks": _steel_special_force_ticks,
		"steel_special_ground_force_ticks": _steel_special_ground_force_ticks,
		"physical_body": "RigidBody3D"
	}


func prepare_for_pool() -> void:
	_steel_special_force_ticks = 0
	_steel_special_ground_force_ticks = 0
	if _player_ref != null and is_instance_valid(_player_ref):
		remove_collision_exception_with(_player_ref)
	process_mode = Node.PROCESS_MODE_DISABLED
	scale = Vector3.ONE
	_projectile_active = false
	_ground_contact = false
	_steel_special_protected = false
	_steel_special_response_pending = false
	_projectile_lifetime = 0.0
	_pickup_lock_left = 0.0
	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO
	gravity_scale = 1.0
	freeze = true
	visible = false
	collision_layer = 0
	collision_mask = 0
	auto_collect_on_contact = true
	if _targetable != null and is_instance_valid(_targetable):
		_targetable.selectable = false
		_targetable.set_preview(false)
	if _projectile_material != null:
		_projectile_material.emission_enabled = false

func prepare_for_world() -> void:
	_steel_special_force_ticks = 0
	_steel_special_ground_force_ticks = 0
	if _player_ref != null and is_instance_valid(_player_ref):
		remove_collision_exception_with(_player_ref)
	process_mode = Node.PROCESS_MODE_INHERIT
	scale = Vector3.ONE
	_projectile_active = false
	_ground_contact = false
	_steel_special_protected = false
	_steel_special_response_pending = false
	_projectile_lifetime = 0.0
	_pickup_lock_left = 0.08
	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO
	gravity_scale = 1.0
	freeze = false
	visible = true
	collision_layer = 0
	collision_mask = coin_ground_mask
	auto_collect_on_contact = true
	if _targetable != null and is_instance_valid(_targetable):
		_targetable.selectable = true
		_targetable.set_preview(false)
	if _projectile_material != null:
		_projectile_material.emission_enabled = false
