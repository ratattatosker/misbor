class_name MistbornCoinPool
extends Node

@export var warm_pool_size: int = 6

var _available: Array[MistbornCoin] = []

func _ready() -> void:
	add_to_group("mistborn_coin_pool")
	for i in range(maxi(warm_pool_size, 1)):
		var coin := _create_coin()
		if coin == null:
			continue
		_available.append(coin)

func _create_coin() -> MistbornCoin:
	var coin := MistbornCoin.new()
	coin.name = "__PooledCoin"
	add_child(coin)
	coin.prepare_for_pool()
	return coin

func acquire(parent: Node) -> MistbornCoin:
	if parent == null or not is_instance_valid(parent):
		return null
	var coin: MistbornCoin = null
	while not _available.is_empty() and coin == null:
		var candidate: MistbornCoin = _available.pop_back()
		if is_instance_valid(candidate):
			coin = candidate
	if coin == null:
		coin = _create_coin()
		if coin == null:
			return null
	coin.reparent(parent, true)
	coin.prepare_for_world()
	return coin

func reclaim(coin: MistbornCoin) -> void:
	if coin == null or not is_instance_valid(coin):
		return
	if coin.get_parent() != self:
		coin.reparent(self, true)
	coin.prepare_for_pool()
	if not _available.has(coin):
		_available.append(coin)
