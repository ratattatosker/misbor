class_name MistbornDebugOverlay
extends CanvasLayer

const FORCE_MODEL = preload("res://scripts/allomantic_force_model.gd")

var _panel: Panel
var _label: Label
var _visible := false
var _player: MistbornPlayerController
var _camera: MistbornCameraRig
var _targeting: MistbornTargetingController
var _steel: MistbornSteelController
var _iron: MistbornIronController
var _traversal: MistbornTraversalController
var _sample_accumulator := 0.0
var _mode_label: Label

func _ready() -> void:
	_player = get_parent().get_node_or_null("Player") as MistbornPlayerController
	if _player != null:
		_camera = _player.get_node_or_null("CameraRig") as MistbornCameraRig
		_targeting = _player.get_node_or_null("Targeting") as MistbornTargetingController
		_steel = _player.get_node_or_null("Steel") as MistbornSteelController
		_iron = _player.get_node_or_null("Iron") as MistbornIronController
		_traversal = _player.get_node_or_null("Traversal") as MistbornTraversalController
	_build_ui()
	set_process(_visible)

func _build_ui() -> void:
	_panel = Panel.new()
	_panel.position = Vector2(16, 16)
	_panel.size = Vector2(430, 285)
	_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE

	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.025, 0.025, 0.035, 0.88)
	style.border_color = Color(0.35, 0.4, 0.48, 0.7)
	style.set_border_width_all(1)
	style.corner_radius_top_left = 6
	style.corner_radius_top_right = 6
	style.corner_radius_bottom_left = 6
	style.corner_radius_bottom_right = 6
	_panel.add_theme_stylebox_override("panel", style)
	add_child(_panel)
	_panel.visible = _visible

	_label = Label.new()
	_label.position = Vector2(12, 10)
	_label.size = Vector2(406, 265)
	_label.add_theme_font_size_override("font_size", 15)
	_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(_label)

	_mode_label = Label.new()
	_mode_label.anchor_left = 0.5
	_mode_label.anchor_right = 0.5
	_mode_label.offset_left = -180.0
	_mode_label.offset_right = 180.0
	_mode_label.offset_top = 32.0
	_mode_label.offset_bottom = 64.0
	_mode_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_mode_label.add_theme_font_size_override("font_size", 17)
	_mode_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_mode_label)
	_mode_label.visible = _visible

func _unhandled_input(event: InputEvent) -> void:
	if not event.is_action_pressed("toggle_debug"):
		return
	_visible = not _visible
	_panel.visible = _visible
	_mode_label.visible = _visible
	set_process(_visible)
	if _visible:
		_sample_accumulator = 0.0
		_update_text()

func _process(delta: float) -> void:
	_sample_accumulator += delta
	if _sample_accumulator < 0.05:
		return
	_sample_accumulator = 0.0
	_update_text()

func _update_text() -> void:
	if _player == null:
		_label.text = "MISTBORN — PUNTO CERO\n\nPlayer no encontrado."
		return

	var player_state: Dictionary = _player.get_debug_state()
	var camera_state := _camera.get_debug_state() if _camera != null else {}
	var target_state: Dictionary = _targeting.get_debug_state() if _targeting != null else {}
	var steel_state: Dictionary = _steel.get_debug_state() if _steel != null else {}
	var iron_state: Dictionary = _iron.get_debug_state() if _iron != null else {}
	var traversal_state: Dictionary = _traversal.get_debug_state() if _traversal != null else {}
	var fps: float = Engine.get_frames_per_second()
	_mode_label.text = "ALLomantic Sight" if target_state.get("sight_active", false) else ("SOFT LOCK" if target_state.get("locked", false) else "AUTO FOCUS")

	_label.text = (
		"MISTBORN — PUNTO CERO\n"
		+ "MOVIMIENTO · ALLOMANCY CORE\n\n"
		+ "Estado: %s\n" % _derive_state(player_state)
		+ "Velocidad: %.2f m/s\n" % player_state["horizontal_speed"]
		+ "Suelo: %s   Sprint: %s\n" % [str(player_state["grounded"]), str(player_state["sprinting"])]
		+ "Agachado: %s\n" % [str(player_state["crouching"])]
		+ "Posición: %s\n" % _format_vector(player_state["position"])
		+ "Cámara yaw/pitch: %.1f° / %.1f°\n" % [camera_state.get("yaw_deg", 0.0), camera_state.get("pitch_deg", 0.0)]
		+ "Distancia cámara: %.2f m\n" % camera_state.get("distance", 0.0)
		+ "Objetivo: %s\n" % target_state.get("target_name", "NINGUNO")
		+ "Steel: %s   Target: %s\n" % [str(steel_state.get("active", false)), steel_state.get("target_name", "NINGUNO")]
		+ "Iron: %s   Target: %s\n" % [str(iron_state.get("active", false)), iron_state.get("target_name", "NINGUNO")]
		+ "Traversal: %s   Monedas: %d\n" % [traversal_state.get("state", "UNKNOWN"), int(traversal_state.get("coin_count", 0))]
		+ "Action target: %s\n" % target_state.get("action_target_name", "NINGUNO")
		+ "Steel bloqueado: %s\n" % steel_state.get("blocked_reason", "")
		+ "Iron bloqueado: %s\n" % iron_state.get("blocked_reason", "")
		+ "Focus: %s\n" % target_state.get("focus_name", "NINGUNO")
		+ "Soft Lock: %s   Sight: %s\n" % [str(target_state.get("locked", false)), str(target_state.get("sight_active", false))]
		+ "Acción allomántica: %s\n" % target_state.get("allomantic_action", "NINGUNA")
		+ "Candidatos retícula: %d   Visión: %d\n" % [int(target_state.get("candidate_count", 0)), int(target_state.get("sight_count", 0))]
		+ "Contexto target: %s   Radio Allomántico: %.1f m   FPS: %d\n\n" % [target_state.get("mode", "EXPLORATION"), FORCE_MODEL.SHARED_RANGE, fps]
		+ "WASD mover · Shift sprint · Space salto · Space×2 Steel+Coin · Q Steel · E Iron\n"
		+ "MMB fijar · Ctrl visión · Rueda del ratón objetivo · X limpiar\n"
		+ "F3 debug · Esc libera mouse"
	)

func _derive_state(state: Dictionary) -> String:
	if state["crouching"]:
		return "CROUCH"
	if not state["grounded"]:
		return "AIR"
	if state["sprinting"]:
		return "SPRINT"
	if state["horizontal_speed"] > 0.15:
		return "RUN"
	return "IDLE"

func _format_vector(value: Vector3) -> String:
	return "(%.2f, %.2f, %.2f)" % [value.x, value.y, value.z]
