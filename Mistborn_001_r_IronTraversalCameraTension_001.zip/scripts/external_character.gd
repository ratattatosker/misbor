class_name MistbornExternalCharacter
extends Node3D

## External character bridge.
## The visual asset remains external to normal project ZIPs.
## Expected file:
##   res://assets/characters/character.glb
## or:
##   res://assets/characters/character.fbx

@export_category("External Character")
@export_file("*.glb", "*.fbx") var preferred_asset: String = "res://assets/characters/character.glb"
@export var auto_hide_when_missing: bool = false
@export var model_forward_offset_degrees: float = 180.0
@export var auto_ground_model: bool = true

var _character_instance: Node3D
var _skeleton: Skeleton3D
var _coin_socket: Node3D
var _target_socket: Node3D
var _line_origin_socket: Node3D
var _sight_socket: Node3D
var _fade_alpha: float = 1.0
var _forced_crouched: bool = false
var _animation_player: AnimationPlayer
var _animation_tree: AnimationTree
var _animation_names: Array[StringName] = []
var _fallback_animation_names: Dictionary = {}
var _is_procedural_fallback: bool = false
var _fallback_root: Node3D
var _fallback_left_arm: Node3D
var _fallback_right_arm: Node3D
var _fallback_left_leg: Node3D
var _fallback_right_leg: Node3D
var _fallback_torso: Node3D
var _fallback_phase: float = 0.0
var _fallback_materials: Array[StandardMaterial3D] = []

const SEARCH_PATHS := [
	"res://assets/characters/character.glb",
	"res://assets/characters/character.fbx"
]

func _ready() -> void:
	_load_external_character()

func _load_external_character() -> void:
	var path := _resolve_asset_path()
	if path.is_empty():
		if auto_hide_when_missing:
			visible = false
			return
		_build_procedural_fallback()
		return

	var packed := load(path) as PackedScene
	if packed == null:
		push_error("External character could not be imported as PackedScene: %s" % path)
		return

	_character_instance = packed.instantiate() as Node3D
	if _character_instance == null:
		push_error("External character did not instantiate as Node3D: %s" % path)
		return

	_character_instance.name = "CharacterModel"
	_character_instance.rotation.y = deg_to_rad(model_forward_offset_degrees)
	add_child(_character_instance)

	_skeleton = _find_skeleton(_character_instance)
	_animation_player = _find_animation_player(_character_instance)
	_animation_tree = _find_animation_tree(_character_instance)
	_ensure_animation_source()
	_cache_animation_names()
	if _animation_player != null:
		# Imported GLBs may autoplay their first clip (often crouch/combat).
		# Stop that before our state machine selects the correct gameplay pose.
		_animation_player.stop()
	_create_gameplay_sockets()
	_prepare_material_fade()

	# Imported humanoid assets often put the origin at hips or leave a small
	# root-space offset. Re-seat the visual model on the gameplay floor.
	await get_tree().process_frame
	if auto_ground_model:
		_ground_model_to_visual_floor()

	# The external asset may ship an AnimationTree that drives a crouch/combat pose.
	# This prototype uses the explicit state-driven AnimationPlayer, so the imported
	# tree must not override it.
	if _animation_tree != null:
		_animation_tree.active = false

func _build_procedural_fallback() -> void:
	# Low-cost placeholder for gameplay validation when no artist-authored model is included.
	# This is deliberately a proxy, not final character art.
	_is_procedural_fallback = true
	_character_instance = Node3D.new()
	_character_instance.name = "ProceduralMistbornProxy"
	add_child(_character_instance)
	_fallback_root = _character_instance

	var cloak_mat := _make_proxy_material(Color(0.075, 0.082, 0.095, 1.0))
	var tunic_mat := _make_proxy_material(Color(0.13, 0.135, 0.15, 1.0))
	var lining_mat := _make_proxy_material(Color(0.27, 0.065, 0.085, 1.0))
	var mask_mat := _make_proxy_material(Color(0.025, 0.026, 0.031, 1.0))
	var trim_mat := _make_proxy_material(Color(0.39, 0.37, 0.32, 1.0))
	var eye_mat := _make_proxy_material(Color(0.46, 0.50, 0.54, 1.0))
	var glove_mat := _make_proxy_material(Color(0.10, 0.105, 0.115, 1.0))
	var boot_mat := _make_proxy_material(Color(0.045, 0.047, 0.052, 1.0))

	# Cloak silhouette: narrow shoulders, widening hem, low polygon count.
	var outer_cloak := CylinderMesh.new()
	outer_cloak.top_radius = 0.19
	outer_cloak.bottom_radius = 0.38
	outer_cloak.height = 0.84
	outer_cloak.radial_segments = 7
	_add_proxy_mesh(_fallback_root, "OuterMistcloak", outer_cloak, cloak_mat, Vector3(0.0, 0.55, 0.055))
	var inner_cloak := CylinderMesh.new()
	inner_cloak.top_radius = 0.12
	inner_cloak.bottom_radius = 0.28
	inner_cloak.height = 0.68
	inner_cloak.radial_segments = 7
	_add_proxy_mesh(_fallback_root, "CloakLining", inner_cloak, lining_mat, Vector3(0.0, 0.52, -0.105))

	_fallback_torso = Node3D.new()
	_fallback_torso.name = "TorsoRig"
	_fallback_torso.position = Vector3(0.0, 1.08, -0.035)
	_fallback_root.add_child(_fallback_torso)
	var torso_mesh := CapsuleMesh.new()
	torso_mesh.radius = 0.205
	torso_mesh.height = 0.64
	torso_mesh.radial_segments = 8
	torso_mesh.rings = 3
	_add_proxy_mesh(_fallback_torso, "Torso", torso_mesh, tunic_mat, Vector3(0.0, 0.0, 0.0))
	var shoulder_mesh := BoxMesh.new()
	shoulder_mesh.size = Vector3(0.55, 0.16, 0.31)
	_add_proxy_mesh(_fallback_torso, "ShoulderMantle", shoulder_mesh, cloak_mat, Vector3(0.0, 0.20, 0.0))
	var clasp_mesh := BoxMesh.new()
	clasp_mesh.size = Vector3(0.12, 0.035, 0.024)
	_add_proxy_mesh(_fallback_torso, "CloakClasp", clasp_mesh, trim_mat, Vector3(0.0, 0.18, -0.174))

	# Hood and shadowed face; facial detail stays intentionally minimal.
	var hood_mesh := SphereMesh.new()
	hood_mesh.radius = 0.17
	hood_mesh.height = 0.34
	hood_mesh.radial_segments = 8
	hood_mesh.rings = 5
	var hood := _add_proxy_mesh(_fallback_root, "Hood", hood_mesh, cloak_mat, Vector3(0.0, 1.58, 0.01))
	hood.scale = Vector3(0.96, 1.12, 1.0)
	var mask_mesh := SphereMesh.new()
	mask_mesh.radius = 0.115
	mask_mesh.height = 0.22
	mask_mesh.radial_segments = 8
	mask_mesh.rings = 4
	_add_proxy_mesh(_fallback_root, "FaceShadow", mask_mesh, mask_mat, Vector3(0.0, 1.565, -0.105))
	var eye_mesh := BoxMesh.new()
	eye_mesh.size = Vector3(0.030, 0.012, 0.008)
	_add_proxy_mesh(_fallback_root, "EyeLeft", eye_mesh, eye_mat, Vector3(-0.044, 1.598, -0.216))
	_add_proxy_mesh(_fallback_root, "EyeRight", eye_mesh, eye_mat, Vector3(0.044, 1.598, -0.216))

	# Articulated proxy limbs. Meshes are cheap and use no textures/shaders.
	_fallback_left_arm = _make_proxy_pivot("ArmLeftRig", Vector3(-0.30, 1.22, -0.015), _fallback_root)
	_fallback_right_arm = _make_proxy_pivot("ArmRightRig", Vector3(0.30, 1.22, -0.015), _fallback_root)
	var arm_mesh_l := CapsuleMesh.new()
	arm_mesh_l.radius = 0.078
	arm_mesh_l.height = 0.54
	arm_mesh_l.radial_segments = 7
	arm_mesh_l.rings = 3
	_add_proxy_mesh(_fallback_left_arm, "ArmLeft", arm_mesh_l, cloak_mat, Vector3(0.0, -0.25, 0.0), Vector3(0.0, 0.0, -9.0))
	var arm_mesh_r := CapsuleMesh.new()
	arm_mesh_r.radius = 0.078
	arm_mesh_r.height = 0.54
	arm_mesh_r.radial_segments = 7
	arm_mesh_r.rings = 3
	_add_proxy_mesh(_fallback_right_arm, "ArmRight", arm_mesh_r, cloak_mat, Vector3(0.0, -0.25, 0.0), Vector3(0.0, 0.0, 9.0))
	var hand_mesh_l := SphereMesh.new()
	hand_mesh_l.radius = 0.070
	hand_mesh_l.height = 0.14
	hand_mesh_l.radial_segments = 7
	hand_mesh_l.rings = 3
	_add_proxy_mesh(_fallback_left_arm, "GloveLeft", hand_mesh_l, glove_mat, Vector3(0.0, -0.505, -0.005))
	var hand_mesh_r := SphereMesh.new()
	hand_mesh_r.radius = 0.070
	hand_mesh_r.height = 0.14
	hand_mesh_r.radial_segments = 7
	hand_mesh_r.rings = 3
	_add_proxy_mesh(_fallback_right_arm, "GloveRight", hand_mesh_r, glove_mat, Vector3(0.0, -0.505, -0.005))

	_fallback_left_leg = _make_proxy_pivot("LegLeftRig", Vector3(-0.12, 0.62, 0.005), _fallback_root)
	_fallback_right_leg = _make_proxy_pivot("LegRightRig", Vector3(0.12, 0.62, 0.005), _fallback_root)
	var leg_mesh_l := CapsuleMesh.new()
	leg_mesh_l.radius = 0.086
	leg_mesh_l.height = 0.52
	leg_mesh_l.radial_segments = 7
	leg_mesh_l.rings = 3
	_add_proxy_mesh(_fallback_left_leg, "LegLeft", leg_mesh_l, boot_mat, Vector3(0.0, -0.25, 0.0))
	var leg_mesh_r := CapsuleMesh.new()
	leg_mesh_r.radius = 0.086
	leg_mesh_r.height = 0.52
	leg_mesh_r.radial_segments = 7
	leg_mesh_r.rings = 3
	_add_proxy_mesh(_fallback_right_leg, "LegRight", leg_mesh_r, boot_mat, Vector3(0.0, -0.25, 0.0))
	var foot_mesh_l := BoxMesh.new()
	foot_mesh_l.size = Vector3(0.16, 0.095, 0.27)
	_add_proxy_mesh(_fallback_left_leg, "BootLeft", foot_mesh_l, boot_mat, Vector3(0.0, -0.50, -0.055))
	var foot_mesh_r := BoxMesh.new()
	foot_mesh_r.size = Vector3(0.16, 0.095, 0.27)
	_add_proxy_mesh(_fallback_right_leg, "BootRight", foot_mesh_r, boot_mat, Vector3(0.0, -0.50, -0.055))

	# Gameplay forces keep their established target socket. Rendered blue lines get
	# a separate chest socket so visual canon never shifts the physics origin.
	_coin_socket = _make_proxy_pivot("CoinSocket", Vector3(0.0, 1.12, -0.12), _fallback_root)
	_target_socket = _make_proxy_pivot("TargetPoint", Vector3(0.0, 1.00, -0.06), _fallback_root)
	_line_origin_socket = _make_proxy_pivot("AllomanticLineOrigin", Vector3(0.0, 1.34, -0.075), _fallback_root)
	_sight_socket = _make_proxy_pivot("AllomanticSightOrigin", Vector3(0.0, 1.55, -0.15), _fallback_root)
	set_fade_alpha(_fade_alpha)

func _make_proxy_material(color: Color) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.88
	material.metallic = 0.04
	_fallback_materials.append(material)
	return material

func _make_proxy_pivot(node_name: String, local_position: Vector3, parent: Node3D) -> Node3D:
	var pivot := Node3D.new()
	pivot.name = node_name
	pivot.position = local_position
	parent.add_child(pivot)
	return pivot

func _add_proxy_mesh(parent: Node3D, node_name: String, mesh: Mesh, material: StandardMaterial3D, local_position: Vector3, local_rotation_degrees: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = local_position
	instance.rotation_degrees = local_rotation_degrees
	parent.add_child(instance)
	return instance

func _update_procedural_fallback(state: String, horizontal_speed: float, vertical_speed: float) -> void:
	if not _is_procedural_fallback or _fallback_root == null:
		return
	var moving := state == "RUN" or state == "SPRINT"
	if moving and not _forced_crouched:
		var pace := 4.4 if state == "RUN" else 6.2
		_fallback_phase = fmod(_fallback_phase + pace / 60.0, TAU)
		var swing_degrees := 18.0 if state == "RUN" else 25.0
		var swing := sin(_fallback_phase) * deg_to_rad(swing_degrees)
		if _fallback_left_leg != null:
			_fallback_left_leg.rotation.x = swing
		if _fallback_right_leg != null:
			_fallback_right_leg.rotation.x = -swing
		if _fallback_left_arm != null:
			_fallback_left_arm.rotation.x = -swing * 0.62
		if _fallback_right_arm != null:
			_fallback_right_arm.rotation.x = swing * 0.62
		_fallback_root.position.y = absf(sin(_fallback_phase * 2.0)) * (0.018 if state == "RUN" else 0.028)
	else:
		if _fallback_left_leg != null:
			_fallback_left_leg.rotation.x = lerpf(_fallback_left_leg.rotation.x, 0.0, 0.24)
		if _fallback_right_leg != null:
			_fallback_right_leg.rotation.x = lerpf(_fallback_right_leg.rotation.x, 0.0, 0.24)
		if _fallback_left_arm != null:
			_fallback_left_arm.rotation.x = lerpf(_fallback_left_arm.rotation.x, 0.0, 0.24)
		if _fallback_right_arm != null:
			_fallback_right_arm.rotation.x = lerpf(_fallback_right_arm.rotation.x, 0.0, 0.24)
		_fallback_root.position.y = 0.0
	if state == "AIR" and vertical_speed > 0.0:
		if _fallback_left_arm != null:
			_fallback_left_arm.rotation.z = lerpf(_fallback_left_arm.rotation.z, deg_to_rad(-18.0), 0.18)
		if _fallback_right_arm != null:
			_fallback_right_arm.rotation.z = lerpf(_fallback_right_arm.rotation.z, deg_to_rad(18.0), 0.18)
	else:
		if _fallback_left_arm != null:
			_fallback_left_arm.rotation.z = lerpf(_fallback_left_arm.rotation.z, deg_to_rad(-9.0), 0.14)
		if _fallback_right_arm != null:
			_fallback_right_arm.rotation.z = lerpf(_fallback_right_arm.rotation.z, deg_to_rad(9.0), 0.14)

func _resolve_asset_path() -> String:
	if not preferred_asset.is_empty() and ResourceLoader.exists(preferred_asset):
		return preferred_asset
	for path in SEARCH_PATHS:
		if ResourceLoader.exists(path):
			return path

	# Convenience fallback: the director may drop one GLB/FBX into the character
	# folder without renaming it. The project will use the first valid asset found.
	var dir := DirAccess.open("res://assets/characters")
	if dir != null:
		dir.list_dir_begin()
		var candidate := dir.get_next()
		while not candidate.is_empty():
			if not dir.current_is_dir():
				var lower := candidate.to_lower()
				if lower.ends_with(".glb") or lower.ends_with(".fbx"):
					dir.list_dir_end()
					return "res://assets/characters/" + candidate
			candidate = dir.get_next()
		dir.list_dir_end()
	return ""

func _find_skeleton(root: Node) -> Skeleton3D:
	if root is Skeleton3D:
		return root as Skeleton3D
	for child in root.get_children():
		var result := _find_skeleton(child)
		if result != null:
			return result
	return null

func _find_animation_player(root: Node) -> AnimationPlayer:
	if root is AnimationPlayer:
		return root as AnimationPlayer
	for child in root.get_children():
		var result := _find_animation_player(child)
		if result != null:
			return result
	return null

func _find_animation_tree(root: Node) -> AnimationTree:
	if root is AnimationTree:
		return root as AnimationTree
	for child in root.get_children():
		var result := _find_animation_tree(child)
		if result != null:
			return result
	return null

func _normalise_animation_name(value: StringName) -> String:
	return String(value).to_lower().replace(" ", "_").replace("-", "_")

func _find_animation_by_keywords(keywords: Array[String]) -> StringName:
	# Exact matches win first so `idle` cannot accidentally select `crouch_idle`.
	for animation_name in _animation_names:
		var normalised := _normalise_animation_name(animation_name)
		if normalised.contains("crouch") or normalised.contains("kneel") or normalised.contains("prone"):
			continue
		for keyword in keywords:
			if normalised == keyword:
				return animation_name
	# General fallback skips poses that would visually keep the character crouched.
	for animation_name in _animation_names:
		var normalised := _normalise_animation_name(animation_name)
		if normalised.contains("crouch") or normalised.contains("kneel") or normalised.contains("prone"):
			continue
		for keyword in keywords:
			if normalised.contains(keyword):
				return animation_name
	return StringName("")

func _play_animation_for_state(state: String, vertical_speed: float, horizontal_speed: float = 0.0) -> void:
	if _animation_player == null or _animation_names.is_empty():
		return

	var desired := StringName("")
	match state:
		"IDLE":
			desired = _find_animation_by_keywords(["idle", "breathing_idle", "stand"])
		"RUN":
			if horizontal_speed >= 6.2:
				desired = _find_animation_by_keywords(["run", "jog", "sprint"])
			else:
				desired = _find_animation_by_keywords(["walk", "walking"])
		"SPRINT":
			desired = _find_animation_by_keywords(["run", "jog", "sprint"])
		"AIR":
			if vertical_speed > 0.15:
				desired = _find_animation_by_keywords(["jump", "jump_start"])
			else:
				desired = _find_animation_by_keywords(["fall", "jump_loop", "air"])
		"LAND":
			desired = _find_animation_by_keywords(["land", "jump_land"])
		"CROUCH":
			desired = _find_animation_by_keywords(["crouch_idle", "crouch"])

	# Never use an arbitrary first clip for idle: imported GLBs often store a crouch
	# or combat clip first, which would lock the character into the wrong pose.

	if desired.is_empty():
		match state:
			"IDLE":
				desired = _fallback_animation_names.get("IDLE", StringName(""))
			"RUN":
				desired = _fallback_animation_names.get("RUN", StringName(""))
			"SPRINT":
				desired = _fallback_animation_names.get("SPRINT", StringName(""))
			"AIR":
				desired = _fallback_animation_names.get("AIR_JUMP" if vertical_speed > 0.15 else "AIR_FALL", StringName(""))
			"LAND":
				desired = _fallback_animation_names.get("LAND", StringName(""))
	if desired.is_empty():
		return
	if state == "RUN":
		# The fallback walk clip was authored around the gameplay walk cadence.
		# Keep it close to 1x and use only a small correction for starting/stopping,
		# avoiding the fast-forward feeling caused by tying clip speed directly to
		# every frame of movement velocity.
		var reference_speed := 4.6
		_animation_player.speed_scale = clampf(horizontal_speed / reference_speed, 0.92, 1.04)
	elif state == "SPRINT":
		var sprint_reference := 7.4
		_animation_player.speed_scale = clampf(horizontal_speed / sprint_reference, 0.94, 1.06)
	else:
		_animation_player.speed_scale = 1.0
	if _animation_player.current_animation != String(desired):
		_animation_player.play(desired, 0.12)

func _ensure_animation_source() -> void:
	# Prefer authored clips when they expose a sensible gameplay state, but always
	# keep a small procedural fallback library so an arbitrary first GLB clip can
	# never force the player into crouch/T-pose during gameplay.
	if _animation_player == null:
		_animation_player = AnimationPlayer.new()
		_animation_player.name = "MistbornAnimationPlayer"
		_animation_player.root_node = NodePath("..")
		_character_instance.add_child(_animation_player)

	var fallback_library_name := &"MistbornFallback"
	if not _animation_player.has_animation_library(fallback_library_name):
		var library := AnimationLibrary.new()
		library.add_animation(&"Idle", _build_idle_animation())
		library.add_animation(&"Walk", _build_locomotion_animation(&"Walk", 1.02, 20.0, 0.045))
		library.add_animation(&"Run", _build_locomotion_animation(&"Run", 0.76, 30.0, 0.06))
		library.add_animation(&"Jump", _build_jump_animation())
		library.add_animation(&"Fall", _build_fall_animation())
		library.add_animation(&"Land", _build_land_animation())
		_animation_player.add_animation_library(fallback_library_name, library)

	_fallback_animation_names = {
		"IDLE": StringName("MistbornFallback/Idle"),
		"RUN": StringName("MistbornFallback/Walk"),
		"SPRINT": StringName("MistbornFallback/Run"),
		"AIR_JUMP": StringName("MistbornFallback/Jump"),
		"AIR_FALL": StringName("MistbornFallback/Fall"),
		"LAND": StringName("MistbornFallback/Land")
	}

func _cache_animation_names() -> void:
	_animation_names.clear()
	if _animation_player == null:
		return
	for animation_name in _animation_player.get_animation_list():
		_animation_names.append(animation_name)

func _bone_index(candidates: Array[String]) -> int:
	if _skeleton == null:
		return -1
	for candidate in candidates:
		var idx := _skeleton.find_bone(candidate)
		if idx >= 0:
			return idx
	return -1

func _bone_track_path(bone_index: int, property_name: String) -> NodePath:
	var skeleton_path: NodePath = _animation_player.get_path_to(_skeleton)
	return NodePath("%s:pose/bones/%d/%s" % [String(skeleton_path), bone_index, property_name])

func _add_bone_rotation_track(animation: Animation, bone_index: int, keys: Array) -> void:
	if bone_index < 0:
		return
	var track := animation.add_track(Animation.TYPE_VALUE)
	animation.track_set_path(track, _bone_track_path(bone_index, "rotation"))
	animation.track_set_interpolation_type(track, Animation.INTERPOLATION_LINEAR)
	animation.value_track_set_update_mode(track, Animation.UPDATE_CONTINUOUS)
	for key in keys:
		animation.track_insert_key(track, float(key[0]), key[1])

func _add_bone_position_track(animation: Animation, bone_index: int, keys: Array) -> void:
	if bone_index < 0:
		return
	var track := animation.add_track(Animation.TYPE_VALUE)
	animation.track_set_path(track, _bone_track_path(bone_index, "position"))
	animation.track_set_interpolation_type(track, Animation.INTERPOLATION_LINEAR)
	animation.value_track_set_update_mode(track, Animation.UPDATE_CONTINUOUS)
	for key in keys:
		animation.track_insert_key(track, float(key[0]), key[1])

func _q(x_deg: float, y_deg: float = 0.0, z_deg: float = 0.0) -> Quaternion:
	return Quaternion.from_euler(Vector3(deg_to_rad(x_deg), deg_to_rad(y_deg), deg_to_rad(z_deg)))

func _loop_animation(animation: Animation, length: float) -> Animation:
	animation.length = length
	animation.loop_mode = Animation.LOOP_LINEAR
	return animation

func _build_idle_animation() -> Animation:
	var a := _loop_animation(Animation.new(), 2.8)
	var hips := _bone_index(["Hips", "hips", "Pelvis"])
	var spine := _bone_index(["Spine", "spine"])
	var chest := _bone_index(["Chest", "UpperChest", "spine_03"])
	var head := _bone_index(["Head", "head"])
	var upper_arm_l := _bone_index(["UpperArm_L", "LeftUpperArm", "upperarm_l"])
	var upper_arm_r := _bone_index(["UpperArm_R", "RightUpperArm", "upperarm_r"])
	var hand_l := _bone_index(["Hand_L", "LeftHand", "hand_l"])
	var hand_r := _bone_index(["Hand_R", "RightHand", "hand_r"])

	_add_bone_position_track(a, hips, [
		[0.0, Vector3(0.0, 0.0, 0.0)],
		[0.7, Vector3(0.0, 0.018, 0.0)],
		[1.4, Vector3(0.0, 0.0, 0.0)],
		[2.1, Vector3(0.0, -0.006, 0.0)],
		[2.8, Vector3(0.0, 0.0, 0.0)]
	])
	_add_bone_rotation_track(a, spine, [[0.0, _q(0, 0, -0.7)], [1.4, _q(0, 0, 0.7)], [2.8, _q(0, 0, -0.7)]])
	_add_bone_rotation_track(a, chest, [[0.0, _q(0.7, 0, 0)], [1.4, _q(-0.7, 0, 0)], [2.8, _q(0.7, 0, 0)]])
	_add_bone_rotation_track(a, head, [[0.0, _q(-0.2, 0, 0.4)], [1.4, _q(0.2, 0, -0.4)], [2.8, _q(-0.2, 0, 0.4)]])
	_add_bone_rotation_track(a, upper_arm_l, [[0.0, _q(1.0, 0, 0)], [1.4, _q(-1.0, 0, 0)], [2.8, _q(1.0, 0, 0)]])
	_add_bone_rotation_track(a, upper_arm_r, [[0.0, _q(-1.0, 0, 0)], [1.4, _q(1.0, 0, 0)], [2.8, _q(-1.0, 0, 0)]])
	_add_bone_rotation_track(a, hand_l, [[0.0, _q(0, 0, -1.0)], [1.4, _q(0, 0, 1.0)], [2.8, _q(0, 0, -1.0)]])
	_add_bone_rotation_track(a, hand_r, [[0.0, _q(0, 0, 1.0)], [1.4, _q(0, 0, -1.0)], [2.8, _q(0, 0, 1.0)]])
	return a

func _build_locomotion_animation(animation_name: StringName, length: float, swing_deg: float, bob: float) -> Animation:
	var a := _loop_animation(Animation.new(), length)
	var hips := _bone_index(["Hips", "hips", "Pelvis"])
	var spine := _bone_index(["Spine", "spine"])
	var chest := _bone_index(["Chest", "UpperChest", "spine_03"])
	var head := _bone_index(["Head", "head"])
	var upper_arm_l := _bone_index(["UpperArm_L", "LeftUpperArm", "upperarm_l"])
	var upper_arm_r := _bone_index(["UpperArm_R", "RightUpperArm", "upperarm_r"])
	var forearm_l := _bone_index(["Forearm_L", "LeftLowerArm", "lowerarm_l"])
	var forearm_r := _bone_index(["Forearm_R", "RightLowerArm", "lowerarm_r"])
	var upper_leg_l := _bone_index(["UpperLeg_L", "LeftUpperLeg", "thigh_l"])
	var upper_leg_r := _bone_index(["UpperLeg_R", "RightUpperLeg", "thigh_r"])
	var lower_leg_l := _bone_index(["LowerLeg_L", "LeftLowerLeg", "calf_l"])
	var lower_leg_r := _bone_index(["LowerLeg_R", "RightLowerLeg", "calf_r"])
	var foot_l := _bone_index(["Foot_L", "LeftFoot", "foot_l"])
	var foot_r := _bone_index(["Foot_R", "RightFoot", "foot_r"])

	_add_bone_position_track(a, hips, [
		[0.0, Vector3(0, 0, 0)],
		[length * 0.25, Vector3(0, bob, 0)],
		[length * 0.5, Vector3(0, 0, 0)],
		[length * 0.75, Vector3(0, bob, 0)],
		[length, Vector3(0, 0, 0)]
	])
	_add_bone_rotation_track(a, hips, [[0.0, _q(0, 0, -1.5)], [length * 0.25, _q(0, 0, 1.5)], [length * 0.5, _q(0, 0, -1.5)], [length * 0.75, _q(0, 0, 1.5)], [length, _q(0, 0, -1.5)]])
	_add_bone_rotation_track(a, spine, [[0.0, _q(1.2, 0, -0.8)], [length * 0.5, _q(-1.2, 0, 0.8)], [length, _q(1.2, 0, -0.8)]])
	_add_bone_rotation_track(a, chest, [[0.0, _q(-0.6, 0, 0)], [length * 0.5, _q(0.6, 0, 0)], [length, _q(-0.6, 0, 0)]])
	_add_bone_rotation_track(a, head, [[0.0, _q(0, 0, 0.5)], [length * 0.5, _q(0, 0, -0.5)], [length, _q(0, 0, 0.5)]])

	var swing_times := [0.0, length * 0.25, length * 0.5, length * 0.75, length]
	var leg_l := [_q(swing_deg, 0, 0), _q(0, 0, 0), _q(-swing_deg, 0, 0), _q(0, 0, 0), _q(swing_deg, 0, 0)]
	var leg_r := [_q(-swing_deg, 0, 0), _q(0, 0, 0), _q(swing_deg, 0, 0), _q(0, 0, 0), _q(-swing_deg, 0, 0)]
	var knee_l := [_q(5, 0, 0), _q(12, 0, 0), _q(28 if animation_name == &"Run" else 20, 0, 0), _q(12, 0, 0), _q(5, 0, 0)]
	var knee_r := [_q(28 if animation_name == &"Run" else 20, 0, 0), _q(12, 0, 0), _q(5, 0, 0), _q(12, 0, 0), _q(28 if animation_name == &"Run" else 20, 0, 0)]
	_add_bone_rotation_track(a, upper_leg_l, [[swing_times[0], leg_l[0]], [swing_times[1], leg_l[1]], [swing_times[2], leg_l[2]], [swing_times[3], leg_l[3]], [swing_times[4], leg_l[4]]])
	_add_bone_rotation_track(a, upper_leg_r, [[swing_times[0], leg_r[0]], [swing_times[1], leg_r[1]], [swing_times[2], leg_r[2]], [swing_times[3], leg_r[3]], [swing_times[4], leg_r[4]]])
	_add_bone_rotation_track(a, lower_leg_l, [[swing_times[0], knee_l[0]], [swing_times[1], knee_l[1]], [swing_times[2], knee_l[2]], [swing_times[3], knee_l[3]], [swing_times[4], knee_l[4]]])
	_add_bone_rotation_track(a, lower_leg_r, [[swing_times[0], knee_r[0]], [swing_times[1], knee_r[1]], [swing_times[2], knee_r[2]], [swing_times[3], knee_r[3]], [swing_times[4], knee_r[4]]])
	_add_bone_rotation_track(a, foot_l, [[0.0, _q(-5, 0, 0)], [length * 0.25, _q(7, 0, 0)], [length * 0.5, _q(-5, 0, 0)], [length * 0.75, _q(7, 0, 0)], [length, _q(-5, 0, 0)]])
	_add_bone_rotation_track(a, foot_r, [[0.0, _q(7, 0, 0)], [length * 0.25, _q(-5, 0, 0)], [length * 0.5, _q(7, 0, 0)], [length * 0.75, _q(-5, 0, 0)], [length, _q(7, 0, 0)]])
	_add_bone_rotation_track(a, upper_arm_l, [[0.0, _q(-swing_deg * 0.72, 0, 0)], [length * 0.25, _q(0, 0, 0)], [length * 0.5, _q(swing_deg * 0.72, 0, 0)], [length * 0.75, _q(0, 0, 0)], [length, _q(-swing_deg * 0.72, 0, 0)]])
	_add_bone_rotation_track(a, upper_arm_r, [[0.0, _q(swing_deg * 0.72, 0, 0)], [length * 0.25, _q(0, 0, 0)], [length * 0.5, _q(-swing_deg * 0.72, 0, 0)], [length * 0.75, _q(0, 0, 0)], [length, _q(swing_deg * 0.72, 0, 0)]])
	_add_bone_rotation_track(a, forearm_l, [[0.0, _q(3, 0, 0)], [length * 0.5, _q(6, 0, 0)], [length, _q(3, 0, 0)]])
	_add_bone_rotation_track(a, forearm_r, [[0.0, _q(6, 0, 0)], [length * 0.5, _q(3, 0, 0)], [length, _q(6, 0, 0)]])
	return a

func _build_jump_animation() -> Animation:
	var a := Animation.new()
	a.length = 0.62
	a.loop_mode = Animation.LOOP_NONE
	var hips := _bone_index(["Hips", "hips", "Pelvis"])
	var upper_arm_l := _bone_index(["UpperArm_L", "LeftUpperArm", "upperarm_l"])
	var upper_arm_r := _bone_index(["UpperArm_R", "RightUpperArm", "upperarm_r"])
	var upper_leg_l := _bone_index(["UpperLeg_L", "LeftUpperLeg", "thigh_l"])
	var upper_leg_r := _bone_index(["UpperLeg_R", "RightUpperLeg", "thigh_r"])
	var lower_leg_l := _bone_index(["LowerLeg_L", "LeftLowerLeg", "calf_l"])
	var lower_leg_r := _bone_index(["LowerLeg_R", "RightLowerLeg", "calf_r"])
	_add_bone_rotation_track(a, hips, [[0.0, _q(-8, 0, 0)], [0.14, _q(5, 0, 0)], [0.35, _q(1, 0, 0)], [0.62, _q(0, 0, 0)]])
	_add_bone_rotation_track(a, upper_leg_l, [[0.0, _q(-24, 0, 0)], [0.14, _q(8, 0, 0)], [0.35, _q(2, 0, 0)], [0.62, _q(0, 0, 0)]])
	_add_bone_rotation_track(a, upper_leg_r, [[0.0, _q(-24, 0, 0)], [0.14, _q(8, 0, 0)], [0.35, _q(2, 0, 0)], [0.62, _q(0, 0, 0)]])
	_add_bone_rotation_track(a, lower_leg_l, [[0.0, _q(26, 0, 0)], [0.14, _q(10, 0, 0)], [0.35, _q(4, 0, 0)], [0.62, _q(0, 0, 0)]])
	_add_bone_rotation_track(a, lower_leg_r, [[0.0, _q(26, 0, 0)], [0.14, _q(10, 0, 0)], [0.35, _q(4, 0, 0)], [0.62, _q(0, 0, 0)]])
	_add_bone_rotation_track(a, upper_arm_l, [[0.0, _q(-16, 0, 0)], [0.16, _q(20, 0, 0)], [0.42, _q(24, 0, 0)], [0.62, _q(0, 0, 0)]])
	_add_bone_rotation_track(a, upper_arm_r, [[0.0, _q(-16, 0, 0)], [0.16, _q(20, 0, 0)], [0.42, _q(24, 0, 0)], [0.62, _q(0, 0, 0)]])
	return a

func _build_fall_animation() -> Animation:
	var a := _loop_animation(Animation.new(), 0.8)
	var spine := _bone_index(["Spine", "spine"])
	var chest := _bone_index(["Chest", "UpperChest", "spine_03"])
	var upper_arm_l := _bone_index(["UpperArm_L", "LeftUpperArm", "upperarm_l"])
	var upper_arm_r := _bone_index(["UpperArm_R", "RightUpperArm", "upperarm_r"])
	var upper_leg_l := _bone_index(["UpperLeg_L", "LeftUpperLeg", "thigh_l"])
	var upper_leg_r := _bone_index(["UpperLeg_R", "RightUpperLeg", "thigh_r"])
	_add_bone_rotation_track(a, spine, [[0.0, _q(-5, 0, 0)], [0.4, _q(-9, 0, 0)], [0.8, _q(-5, 0, 0)]])
	_add_bone_rotation_track(a, chest, [[0.0, _q(4, 0, 0)], [0.4, _q(7, 0, 0)], [0.8, _q(4, 0, 0)]])
	_add_bone_rotation_track(a, upper_arm_l, [[0.0, _q(18, 0, -6)], [0.4, _q(24, 0, -9)], [0.8, _q(18, 0, -6)]])
	_add_bone_rotation_track(a, upper_arm_r, [[0.0, _q(18, 0, 6)], [0.4, _q(24, 0, 9)], [0.8, _q(18, 0, 6)]])
	_add_bone_rotation_track(a, upper_leg_l, [[0.0, _q(-5, 0, 0)], [0.4, _q(-12, 0, 0)], [0.8, _q(-5, 0, 0)]])
	_add_bone_rotation_track(a, upper_leg_r, [[0.0, _q(-5, 0, 0)], [0.4, _q(-12, 0, 0)], [0.8, _q(-5, 0, 0)]])
	return a

func _build_land_animation() -> Animation:
	var a := Animation.new()
	a.length = 0.48
	a.loop_mode = Animation.LOOP_NONE
	var hips := _bone_index(["Hips", "hips", "Pelvis"])
	var spine := _bone_index(["Spine", "spine"])
	var chest := _bone_index(["Chest", "UpperChest", "spine_03"])
	var upper_leg_l := _bone_index(["UpperLeg_L", "LeftUpperLeg", "thigh_l"])
	var upper_leg_r := _bone_index(["UpperLeg_R", "RightUpperLeg", "thigh_r"])
	var lower_leg_l := _bone_index(["LowerLeg_L", "LeftLowerLeg", "calf_l"])
	var lower_leg_r := _bone_index(["LowerLeg_R", "RightLowerLeg", "calf_r"])
	_add_bone_position_track(a, hips, [[0.0, Vector3(0, 0.035, 0)], [0.14, Vector3(0, -0.04, 0)], [0.30, Vector3(0, 0.012, 0)], [0.48, Vector3(0, 0, 0)]])
	_add_bone_rotation_track(a, spine, [[0.0, _q(-2, 0, 0)], [0.14, _q(-11, 0, 0)], [0.30, _q(-5, 0, 0)], [0.48, _q(0, 0, 0)]])
	_add_bone_rotation_track(a, chest, [[0.0, _q(1, 0, 0)], [0.14, _q(7, 0, 0)], [0.30, _q(3, 0, 0)], [0.48, _q(0, 0, 0)]])
	_add_bone_rotation_track(a, upper_leg_l, [[0.0, _q(-4, 0, 0)], [0.14, _q(13, 0, 0)], [0.30, _q(6, 0, 0)], [0.48, _q(0, 0, 0)]])
	_add_bone_rotation_track(a, upper_leg_r, [[0.0, _q(-4, 0, 0)], [0.14, _q(13, 0, 0)], [0.30, _q(6, 0, 0)], [0.48, _q(0, 0, 0)]])
	_add_bone_rotation_track(a, lower_leg_l, [[0.0, _q(4, 0, 0)], [0.14, _q(-18, 0, 0)], [0.30, _q(-8, 0, 0)], [0.48, _q(0, 0, 0)]])
	_add_bone_rotation_track(a, lower_leg_r, [[0.0, _q(4, 0, 0)], [0.14, _q(-18, 0, 0)], [0.30, _q(-8, 0, 0)], [0.48, _q(0, 0, 0)]])
	return a

func _ground_model_to_visual_floor() -> void:
	if _character_instance == null:
		return

	var meshes: Array[MeshInstance3D] = []
	_collect_meshes(_character_instance, meshes)
	if meshes.is_empty():
		return

	var min_y := INF
	var inverse_visual := global_transform.affine_inverse()
	for mesh in meshes:
		if mesh == null or mesh.mesh == null:
			continue
		var aabb := mesh.get_aabb()
		for x in [aabb.position.x, aabb.end.x]:
			for y in [aabb.position.y, aabb.end.y]:
				for z in [aabb.position.z, aabb.end.z]:
					var point_global: Vector3 = mesh.global_transform * Vector3(x, y, z)
					var point_local: Vector3 = inverse_visual * point_global
					min_y = minf(min_y, point_local.y)

	if is_finite(min_y) and absf(min_y) > 0.001:
		_character_instance.position.y -= min_y

func _create_gameplay_sockets() -> void:
	if _skeleton == null:
		# Imported static meshes or rigs with unfamiliar bone names still need a
		# chest-origin visual link; this fallback does not participate in physics.
		_line_origin_socket = _make_proxy_pivot("AllomanticLineOrigin", Vector3(0.0, 1.34, -0.075), self)
		return

	_coin_socket = _make_socket("CoinSocket", [
		"pelvis", "Pelvis", "hips", "Hips", "Root"
	])
	# The gameplay force origin stays at the center/waist. The visible blue thread
	# originates separately from the sternum/chest, matching the books without
	# changing force calculations or Steel/Coin interactions.
	_target_socket = _make_socket("TargetPoint", [
		"pelvis", "Pelvis", "hips", "Hips", "spine_02", "Spine2", "spine_03", "Spine03"
	])
	_line_origin_socket = _make_socket("AllomanticLineOrigin", [
		"spine_03", "Spine03", "spine_02", "Spine2", "spine2", "Chest", "chest", "upperchest", "UpperChest", "spine_01", "Spine1"
	])
	_sight_socket = _make_socket("AllomanticSightOrigin", [
		"Hand_R", "RightHand", "hand_r", "Hand.R", "hand.r",
		"Hand_L", "LeftHand", "hand_l", "Hand.L", "hand.l"
	])

	if _coin_socket == null:
		_coin_socket = self
	if _target_socket == null:
		_target_socket = self
	if _line_origin_socket == null:
		_line_origin_socket = _make_proxy_pivot("AllomanticLineOriginFallback", Vector3(0.0, 1.34, -0.075), self)
	if _sight_socket == null:
		_sight_socket = _target_socket

func _make_socket(node_name: String, candidates: Array[String]) -> Node3D:
	var bone_name := ""
	for candidate in candidates:
		if _skeleton.find_bone(candidate) >= 0:
			bone_name = candidate
			break
	if bone_name.is_empty():
		return null

	var attachment := BoneAttachment3D.new()
	attachment.name = node_name
	attachment.bone_name = bone_name
	_skeleton.add_child(attachment)
	return attachment

func _prepare_material_fade() -> void:
	# Imported artist materials remain untouched.
	set_fade_alpha(1.0)

func _collect_meshes(root: Node, out: Array[MeshInstance3D]) -> void:
	if root is MeshInstance3D:
		out.append(root as MeshInstance3D)
	for child in root.get_children():
		_collect_meshes(child, out)

func set_fade_alpha(alpha: float) -> void:
	_fade_alpha = clampf(alpha, 0.0, 1.0)
	if _is_procedural_fallback:
		for mat in _fallback_materials:
			if mat == null:
				continue
			var color := mat.albedo_color
			color.a = _fade_alpha
			mat.albedo_color = color
			mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA if _fade_alpha < 0.999 else BaseMaterial3D.TRANSPARENCY_DISABLED
		return
	if _character_instance == null:
		return
	# Do not replace imported materials. Only modify an existing per-surface
	# override when one was already authored by the project.
	var meshes: Array[MeshInstance3D] = []
	_collect_meshes(_character_instance, meshes)
	for mesh in meshes:
		if mesh == null:
			continue
		for surface in range(mesh.get_surface_override_material_count()):
			var mat := mesh.get_surface_override_material(surface) as StandardMaterial3D
			if mat != null:
				var color := mat.albedo_color
				color.a = _fade_alpha
				mat.albedo_color = color

func set_crouched(value: bool) -> void:
	_forced_crouched = value
	if _is_procedural_fallback and _fallback_root != null:
		_fallback_root.scale.y = 0.76 if value else 1.0

func is_crouching() -> bool:
	return _forced_crouched

func get_coin_socket() -> Node3D:
	return _coin_socket

func get_target_socket() -> Node3D:
	return _target_socket

func get_allomantic_line_socket() -> Node3D:
	return _line_origin_socket

func get_allomantic_sight_socket() -> Node3D:
	return _sight_socket

func set_movement_state(state: String, horizontal_speed: float, vertical_speed: float, _grounded: bool) -> void:
	if _is_procedural_fallback:
		_update_procedural_fallback(state, horizontal_speed, vertical_speed)
		return
	_play_animation_for_state(state, vertical_speed, horizontal_speed)

func get_character_instance() -> Node3D:
	return _character_instance
