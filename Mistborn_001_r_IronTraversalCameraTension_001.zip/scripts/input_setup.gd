class_name MistbornInputSetup
extends RefCounted

static func ensure_defaults() -> void:
	# El dash y la rueda de modos ya no forman parte del juego.
	if InputMap.has_action("dash"):
		InputMap.erase_action("dash")
	if InputMap.has_action("mode_wheel"):
		InputMap.erase_action("mode_wheel")
	_add_key_action("move_forward", KEY_W)
	_add_key_action("move_backward", KEY_S)
	_add_key_action("move_left", KEY_A)
	_add_key_action("move_right", KEY_D)
	_add_key_action("jump", KEY_SPACE)
	_add_key_action("sprint", KEY_SHIFT)
	_add_key_action("crouch", KEY_Z)
	_add_key_action("toggle_debug", KEY_F3)
	_add_key_action("release_mouse", KEY_ESCAPE)
	_add_key_action("reset_playground", KEY_R)

	# Q/E son las entradas directas de Steel/Iron.
	_replace_mouse_action("steel_push", MOUSE_BUTTON_XBUTTON1)
	_replace_mouse_action("iron_pull", MOUSE_BUTTON_XBUTTON2)
	_add_key_action("steel_push", KEY_Q)
	_add_key_action("iron_pull", KEY_E)
	# Secondary Iron: pull heavy movable objects toward the player without traversing.
	# F is the keyboard binding; right mouse is the equivalent mouse binding.
	_add_key_action("iron_yank", KEY_F)
	_add_key_action("iron_yank", KEY_NONE, MOUSE_BUTTON_RIGHT)


	_add_key_action("target_lock", KEY_NONE, MOUSE_BUTTON_MIDDLE)
	# Allomantic Sight is a toggle: one press enables it, the next disables it.
	_replace_key_action("target_sight", KEY_CTRL)
	_add_key_action("target_cycle_next", KEY_NONE, MOUSE_BUTTON_WHEEL_UP)
	_add_key_action("target_cycle_previous", KEY_NONE, MOUSE_BUTTON_WHEEL_DOWN)
	_add_key_action("target_clear", KEY_X)

static func _replace_key_action(action_name: StringName, physical_key: Key) -> void:
	if not InputMap.has_action(action_name):
		InputMap.add_action(action_name, 0.2)
	else:
		InputMap.action_erase_events(action_name)
	var event := InputEventKey.new()
	event.physical_keycode = physical_key
	InputMap.action_add_event(action_name, event)

static func _replace_mouse_action(action_name: StringName, mouse_button: MouseButton) -> void:
	if not InputMap.has_action(action_name):
		InputMap.add_action(action_name, 0.08)
	else:
		InputMap.action_erase_events(action_name)

	var event := InputEventMouseButton.new()
	event.button_index = mouse_button
	event.shift_pressed = false
	event.alt_pressed = false
	InputMap.action_add_event(action_name, event)

static func _add_key_action(action_name: StringName, physical_key: Key, mouse_button: MouseButton = MOUSE_BUTTON_NONE, shift_pressed: bool = false) -> void:
	if not InputMap.has_action(action_name):
		InputMap.add_action(action_name, 0.2)

	for existing in InputMap.action_get_events(action_name):
		if existing is InputEventKey:
			var key_event := existing as InputEventKey
			if key_event.physical_keycode == physical_key and key_event.shift_pressed == shift_pressed:
				return
		elif existing is InputEventMouseButton:
			var mouse_event := existing as InputEventMouseButton
			if mouse_event.button_index == mouse_button and mouse_event.shift_pressed == shift_pressed:
				return

	if mouse_button != MOUSE_BUTTON_NONE:
		var new_mouse_event := InputEventMouseButton.new()
		new_mouse_event.button_index = mouse_button
		new_mouse_event.shift_pressed = shift_pressed
		InputMap.action_add_event(action_name, new_mouse_event)
		return

	if physical_key == KEY_NONE:
		return
	var event := InputEventKey.new()
	event.physical_keycode = physical_key
	event.shift_pressed = shift_pressed
	InputMap.action_add_event(action_name, event)
