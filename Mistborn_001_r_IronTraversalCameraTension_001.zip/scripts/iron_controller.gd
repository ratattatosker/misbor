class_name MistbornIronController
extends Node

signal iron_target_used(target: MistbornTargetable)

const FORCE_MODEL = preload("res://scripts/allomantic_force_model.gd")
const HEAVY_IRON = preload("res://scripts/iron_heavy_controller.gd")

@export_category("Iron Traversal")
@export var web_origin_height: float = 0.95
@export_range(0.0, 0.50, 0.01) var release_momentum_lock_time: float = 0.14

@export_category("Iron Traversal Feel")
@export_range(0.0, 12.0, 0.25) var initial_traversal_launch_speed: float = 7.5
@export_range(0.0, 18.0, 0.5) var arc_steering_acceleration: float = 12.0

@export_category("Iron Heavy-Object Yank")
@export_range(0.0, 40.0, 0.5) var heavy_yank_brace_deceleration: float = 18.0

@export_category("Iron Physical Tether")
@export var physical_tether_enabled: bool = true
@export_range(0.5, 8.0, 0.1) var physical_tether_minimum_length: float = 1.25
@export_range(0.0, 2.0, 0.05) var physical_tether_tangent_launch_speed: float = 3.5
@export_range(0.5, 20.0, 0.5) var physical_tether_correction_gain: float = 6.0
@export_range(1.0, 25.0, 0.5) var physical_tether_max_inward_correction_speed: float = 14.0
@export_range(4.0, 60.0, 1.0) var physical_tether_pre_tension_deceleration: float = 24.0

@export_category("Iron Upper-Cone Quadratic Assist")
@export_range(10.0, 85.0, 1.0) var upper_cone_half_angle_degrees: float = 45.0
@export_range(0.0, 2.0, 0.05) var quadratic_propulsion_boost: float = 1.15
@export_category("Iron Lamp Arrival")
@export_range(1.0, 5.0, 0.1) var mount_capture_horizontal_radius: float = 3.2
@export_range(1.0, 12.0, 0.1) var mount_capture_below_surface: float = 8.5
@export_range(0.2, 3.0, 0.1) var mount_capture_above_surface: float = 1.7
@export_range(0.5, 1.8, 0.05) var mount_clearance_radius: float = 0.95
@export_range(0.2, 1.2, 0.05) var mount_clearance_height: float = 0.55
@export_range(1.0, 4.0, 0.1) var mount_arrival_velocity_gain: float = 2.7
@export_range(1.0, 10.0, 0.1) var mount_arrival_response: float = 4.8
@export_range(10.0, 45.0, 1.0) var mount_arrival_max_acceleration: float = 28.0
@export_range(2.0, 12.0, 0.5) var mount_arrival_max_speed: float = 9.5
@export_range(0.15, 0.8, 0.05) var mount_completion_radius: float = 0.55
@export_range(0.3, 3.0, 0.1) var mount_completion_speed: float = 1.8

var _player: MistbornPlayerController
var _targeting: MistbornTargetingController
var _active: bool = false
var _last_target: MistbornTargetable
var _last_block_reason: String = ""
var _impulse_count: int = 0
var _last_arc_steer_direction: Vector3 = Vector3.ZERO
var _button_was_down: bool = false
var _yank_button_was_down: bool = false
var _yank_active: bool = false
var _yank_target: MistbornTargetable
var _iron_mode: StringName = &"none"
var _last_action_type: String = "NONE"
var _last_heavy_yank_force: float = 0.0
var _locked_target_point: Vector3 = Vector3.ZERO
var _locked_initial_distance: float = 0.0
var _locked_upper_cone_factor: float = 0.0
var _physical_tether_active: bool = false
var _physical_tether_target: MistbornTargetable
var _physical_tether_body: PhysicsBody3D
var _physical_tether_local_anchor: Vector3 = Vector3.ZERO
var _physical_tether_anchor_point: Vector3 = Vector3.ZERO
var _physical_tether_length: float = 0.0
var _last_tether_radial_speed_before: float = 0.0
var _last_tether_radial_speed_after: float = 0.0
var _mount_arrival_target: MistbornTargetable
var _mount_arrival_stage: int = 0
var _mount_clear_side: Vector3 = Vector3.RIGHT

const MOUNT_STAGE_NONE: int = 0
const MOUNT_STAGE_CLEAR_LAMP: int = 1
const MOUNT_STAGE_SETTLE_ON_TOP: int = 2

func _ready() -> void:
	_player = get_parent() as MistbornPlayerController
	_targeting = _player.get_node_or_null("Targeting") as MistbornTargetingController if _player != null else null

func physics_step(delta: float) -> void:
	_last_arc_steer_direction = Vector3.ZERO
	if _player == null or _targeting == null:
		_stop_heavy_yank()
		_stop()
		_button_was_down = false
		return

	# Explicit secondary intent: F / right mouse pulls a movable heavy object to
	# the player. E remains immediate traversal. No timing gesture or S+E chord.
	var yank_button_down := Input.is_action_pressed("iron_yank")
	var secondary_is_exclusive := yank_button_down and not Input.is_action_pressed("iron_pull") and not Input.is_action_pressed("steel_push")
	if secondary_is_exclusive:
		# If E was released and F/right mouse pressed in the same physics interval,
		# retire the previous Iron target before acquiring the secondary target.
		if _active:
			_stop()
			_button_was_down = false
		_physics_step_heavy_yank(delta)
		return
	if _yank_active or _yank_button_was_down:
		_stop_heavy_yank()

	var physical_traverse_down: bool = Input.is_action_pressed("iron_pull")
	var owns_iron_input: bool = _player.owns_allomancy_input(&"iron")
	if Input.is_action_just_pressed("iron_pull") and owns_iron_input:
		# A fresh Iron press may take over from Steel during an intentional hand-off.
		_button_was_down = false
	var button_down: bool = physical_traverse_down and owns_iron_input
	var conflicting_input: bool = Input.is_action_pressed("steel_push") and not owns_iron_input
	if not button_down or conflicting_input:
		if _active and _button_was_down and (not physical_traverse_down or not owns_iron_input):
			# Release or primary-action hand-off preserves the velocity vector. There is no pull-to-stop behavior.
			if _player.has_method("begin_iron_momentum_release"):
				_player.call("begin_iron_momentum_release", release_momentum_lock_time)
		_stop()
		_button_was_down = physical_traverse_down
		return

	# E acquires once per press; the fixed target is never silently replaced.
	# Heavy/anchored targets enter traversal immediately. The explicit secondary
	# action handles pulling movable heavy bodies, avoiding a delayed tap/hold split.
	if not _active:
		if _button_was_down:
			return
		_button_was_down = true
		var initial_target: MistbornTargetable = _get_target()
		if not _is_valid_target(initial_target):
			_stop()
			_button_was_down = true
			return
		if not _targeting.is_iron_action_active():
			_targeting.begin_action_target(initial_target, &"iron")
		_last_target = initial_target
		_mount_arrival_target = null
		_mount_arrival_stage = MOUNT_STAGE_NONE
		_last_block_reason = ""
		_locked_target_point = initial_target.get_allomantic_action_point(&"iron", _player.global_position, _player.is_on_floor())
		_locked_initial_distance = _player.get_allomantic_origin().distance_to(_locked_target_point)
		_locked_upper_cone_factor = _get_upper_cone_factor(initial_target)
		_begin_physical_tether(initial_target)
		if _locked_initial_distance <= 0.0001:
			_last_block_reason = "OBJETIVO_DEMASIADO_CERCA"
			_stop()
			_button_was_down = true
			return
		iron_target_used.emit(initial_target)

		_set_active(true)
		var target_mass := initial_target.get_allomantic_mass()
		if target_mass < _player.get_gameplay_mass():
			_iron_mode = &"light_object_pull"
			_last_action_type = "LIGHT_OBJECT_PULL"
		else:
			_iron_mode = &"heavy_traversal"
			_last_action_type = "HEAVY_TRAVERSAL_LAUNCH"
			_apply_initial_traversal_launch(initial_target)
		_cancel_release_momentum_lock()

	var target: MistbornTargetable = _last_target
	if not _is_valid_target(target):
		_last_block_reason = "OBJETIVO_INVALIDO"
		_stop()
		return

	# The arrival helper is only for a traversal toward a real landing surface.
	if _step_mount_arrival(target, delta):
		_button_was_down = true
		return

	# Fixed heavy anchors use a physical distance constraint instead of a continuous
	# radial force. This lets gravity and tangential momentum create a real swing arc.
	if _physical_tether_active and _physical_tether_target == target:
		_step_physical_tether(target, delta)
		_button_was_down = true
		return

	# The shared mass/support resolver remains the authority for the continuous pull.
	# Tangential input then bends the trajectory without overwriting its momentum.
	var current_target_point: Vector3 = target.get_allomantic_action_point(&"iron", _player.global_position, _player.is_on_floor())
	var current_distance: float = _player.get_allomantic_origin().distance_to(current_target_point)
	var progress: float = 0.0
	if _locked_initial_distance > 0.0001:
		progress = clampf(1.0 - current_distance / _locked_initial_distance, 0.0, 1.0)
	var quadratic_multiplier: float = calculate_quadratic_multiplier(progress, quadratic_propulsion_boost, _locked_upper_cone_factor)
	var acted: bool = target.apply_allomantic_interaction(&"iron", _player, delta, FORCE_MODEL.HERO_STRENGTH * quadratic_multiplier, true)
	if not acted:
		_last_block_reason = "BLOQUEADO"
	else:
		_impulse_count += 1
		if bool(target.get_meta("allomantic_player_receives_response", false)):
			_apply_iron_arc_steering(current_target_point, delta)
	_button_was_down = true

func _apply_initial_traversal_launch(target: MistbornTargetable) -> void:
	if _player == null or target == null or not is_instance_valid(target) or initial_traversal_launch_speed <= 0.0:
		return
	var origin: Vector3 = _get_physical_tether_origin() if _physical_tether_active else _player.get_allomantic_origin()
	var target_point: Vector3 = _get_physical_tether_anchor_world_point() if _physical_tether_active else target.get_allomantic_action_point(&"iron", _player.global_position, _player.is_on_floor())
	var direction := target_point - origin
	if direction.length_squared() <= 0.0001:
		return
	_player.velocity = calculate_launch_velocity(
		_player.velocity,
		direction,
		initial_traversal_launch_speed,
		FORCE_MODEL.MAX_TRAVERSAL_SPEED
	)
	if _physical_tether_active:
		_apply_tether_tangent_launch(direction.normalized())
	_player.set_allomantic_action_active()
	_last_action_type = "HEAVY_TRAVERSAL_TETHER_LAUNCH" if _physical_tether_active else "HEAVY_TRAVERSAL_LAUNCH"

func _begin_physical_tether(target: MistbornTargetable) -> void:
	_clear_physical_tether()
	if not physical_tether_enabled or target == null or not is_instance_valid(target):
		return
	var body := target.get_physical_body()
	# A hard tether is reserved for fixed anchors. Movable rigid bodies retain the
	# shared mass-response system, so the rope never silently pins a loose object.
	if not supports_physical_tether(target):
		return
	_physical_tether_target = target
	_physical_tether_body = body
	_physical_tether_anchor_point = _find_surface_tether_anchor(target)
	if _physical_tether_body != null and is_instance_valid(_physical_tether_body):
		_physical_tether_local_anchor = _physical_tether_body.to_local(_physical_tether_anchor_point)
	else:
		_physical_tether_local_anchor = Vector3.ZERO
	var origin: Vector3 = _get_physical_tether_origin()
	_physical_tether_length = clampf(
		origin.distance_to(_physical_tether_anchor_point),
		physical_tether_minimum_length,
		FORCE_MODEL.SHARED_RANGE
	)
	_physical_tether_active = origin.distance_to(_physical_tether_anchor_point) > 0.05
	if _physical_tether_active:
		target.set_meta("allomantic_active_line_endpoint", _physical_tether_anchor_point)
		_last_action_type = "IRON_PHYSICAL_TETHER_ATTACHED"

func _find_surface_tether_anchor(target: MistbornTargetable) -> Vector3:
	var fallback: Vector3 = target.get_allomantic_action_point(&"iron", _player.global_position, _player.is_on_floor())
	var body := target.get_physical_body()
	var world := target.get_world_3d()
	if body == null or world == null or _player == null:
		return fallback
	var origin: Vector3 = _get_physical_tether_origin()
	var ray_vector := fallback - origin
	if ray_vector.length_squared() <= 0.0001:
		return fallback
	var query := PhysicsRayQueryParameters3D.create(origin, fallback + ray_vector.normalized() * 0.05)
	query.collision_mask = body.collision_layer
	query.collide_with_bodies = true
	query.collide_with_areas = false
	query.exclude = [_player.get_rid()]
	var hit: Dictionary = world.direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return fallback
	var collider: Variant = hit.get("collider")
	if collider == body or (collider is Node and body.is_ancestor_of(collider)):
		var hit_position: Variant = hit.get("position")
		if hit_position is Vector3:
			return hit_position as Vector3
	return fallback

func _get_physical_tether_origin() -> Vector3:
	if _player != null and _player.has_method("get_allomantic_line_origin"):
		return _player.call("get_allomantic_line_origin") as Vector3
	return _player.get_allomantic_origin() if _player != null else Vector3.ZERO

func _get_physical_tether_anchor_world_point() -> Vector3:
	if _physical_tether_body != null and is_instance_valid(_physical_tether_body):
		_physical_tether_anchor_point = _physical_tether_body.to_global(_physical_tether_local_anchor)
	elif _physical_tether_target != null and is_instance_valid(_physical_tether_target):
		_physical_tether_anchor_point = _physical_tether_target.get_allomantic_action_point(&"iron", _player.global_position, _player.is_on_floor())
	return _physical_tether_anchor_point

func _apply_tether_tangent_launch(direction_to_anchor: Vector3) -> void:
	if _player == null or physical_tether_tangent_launch_speed <= 0.0:
		return
	var move_input: Vector2 = _player.get_last_move_input()
	if move_input.length_squared() <= 0.0025:
		return
	var local_intent := Vector3(move_input.x, 0.0, move_input.y)
	var camera_rig := _player.get_node_or_null("CameraRig") as Node3D
	var camera_yaw := camera_rig.rotation.y if camera_rig != null else _player.rotation.y
	var desired_world_direction := Basis(Vector3.UP, camera_yaw) * local_intent
	var tangent := desired_world_direction - direction_to_anchor * desired_world_direction.dot(direction_to_anchor)
	if tangent.length_squared() <= 0.0001:
		return
	_player.velocity = calculate_launch_velocity(
		_player.velocity,
		tangent.normalized(),
		physical_tether_tangent_launch_speed * clampf(move_input.length(), 0.0, 1.0),
		FORCE_MODEL.MAX_TRAVERSAL_SPEED
	)

func _step_physical_tether(target: MistbornTargetable, delta: float) -> void:
	if _player == null or target == null or not is_instance_valid(target) or delta <= 0.0:
		_stop()
		return
	var anchor := _get_physical_tether_anchor_world_point()
	target.set_meta("allomantic_active_line_endpoint", anchor)
	var origin: Vector3 = _get_physical_tether_origin()
	var tether_offset := origin - anchor
	var tether_outward := tether_offset.normalized() if tether_offset.length_squared() > 0.0001 else Vector3.ZERO
	_last_tether_radial_speed_before = _player.velocity.dot(tether_outward)
	_player.velocity = calculate_physical_tether_velocity(
		_player.velocity,
		origin,
		anchor,
		_physical_tether_length,
		delta,
		physical_tether_correction_gain,
		physical_tether_max_inward_correction_speed,
		physical_tether_minimum_length * 0.45,
		physical_tether_pre_tension_deceleration
	)
	_last_tether_radial_speed_after = _player.velocity.dot(tether_outward)
	_apply_iron_arc_steering(anchor, delta)
	var speed := _player.velocity.length()
	if speed > FORCE_MODEL.MAX_TRAVERSAL_SPEED:
		_player.velocity = _player.velocity.normalized() * FORCE_MODEL.MAX_TRAVERSAL_SPEED
	_player.set_allomantic_action_active()
	_last_action_type = "IRON_PHYSICAL_TETHER_ACTIVE"
	_last_block_reason = ""
	_impulse_count += 1

func _clear_physical_tether() -> void:
	if _physical_tether_target != null and is_instance_valid(_physical_tether_target):
		if _physical_tether_target.has_meta("allomantic_active_line_endpoint"):
			_physical_tether_target.remove_meta("allomantic_active_line_endpoint")
	_physical_tether_active = false
	_physical_tether_target = null
	_physical_tether_body = null
	_physical_tether_local_anchor = Vector3.ZERO
	_physical_tether_anchor_point = Vector3.ZERO
	_physical_tether_length = 0.0
	_last_tether_radial_speed_before = 0.0
	_last_tether_radial_speed_after = 0.0

static func supports_physical_tether(target: MistbornTargetable) -> bool:
	if target == null or not is_instance_valid(target):
		return false
	var body := target.get_physical_body()
	if body is StaticBody3D:
		return true
	if body is RigidBody3D:
		return (body as RigidBody3D).freeze
	return body == null and target.allomantic_profile == "ANCHOR"

static func calculate_physical_tether_velocity(
	current_velocity: Vector3,
	origin: Vector3,
	anchor_point: Vector3,
	maximum_length: float,
	delta: float,
	correction_gain: float,
	max_inward_correction_speed: float,
	minimum_clearance: float = 0.0,
	pre_tension_deceleration: float = 24.0
) -> Vector3:
	if maximum_length <= 0.0 or delta <= 0.0:
		return current_velocity
	var offset := origin - anchor_point
	var distance := offset.length()
	if distance <= 0.0001:
		return current_velocity
	var outward := offset / distance
	var radial_speed := current_velocity.dot(outward)

	# Surface-clearance safeguard: don't let the tether controller drive the chest
	# origin through the anchor when the line goes slack near the metal surface.
	if minimum_clearance > 0.0 and distance <= minimum_clearance and radial_speed < 0.0:
		current_velocity -= outward * radial_speed
		return current_velocity

	var excess := distance - maximum_length
	if excess > 0.0001:
		# Correct numerical/solver overextension gradually. The correction only changes
		# radial speed; tangential velocity remains untouched.
		var desired_radial_speed := -minf(excess * maxf(correction_gain, 0.0), maxf(max_inward_correction_speed, 0.0))
		if radial_speed > desired_radial_speed:
			current_velocity += outward * (desired_radial_speed - radial_speed)
		return current_velocity

	# Account for the small second-order increase in radius caused by tangential
	# movement during the next CharacterBody step. Without this, a perfectly tangent
	# swing repeatedly overshoots the limit and receives a corrective inward nudge.
	var tangent_velocity := current_velocity - outward * radial_speed
	var tangent_step_squared := tangent_velocity.length_squared() * delta * delta
	var reachable_radius_squared := maxf(maximum_length * maximum_length - tangent_step_squared, 0.0)
	var max_radial_speed_for_step := (sqrt(reachable_radius_squared) - distance) / delta
	var slack := maxf(maximum_length - distance, 0.0)

	if slack <= 0.0001:
		# The tether is already taut: preserve tangent motion and apply only the radial
		# correction needed to keep the next discrete movement step on/in the tether
		# sphere. At high tangent speeds this can be a tiny inward component, providing
		# the centripetal correction a continuous physical rope would produce.
		if radial_speed > max_radial_speed_for_step:
			current_velocity += outward * (max_radial_speed_for_step - radial_speed)
		return current_velocity

	# Predictive pre-tension: start braking outward radial speed using its stopping
	# distance before the rope reaches full extension. The trajectory-based radial cap
	# also includes the geometry of the tangential step. This avoids a single large
	# velocity cut at the slack->taut transition while preserving tangent/inward input.
	var deceleration := maxf(pre_tension_deceleration, 0.0)
	if radial_speed > 0.0 and deceleration > 0.0:
		var stopping_distance := (radial_speed * radial_speed) / (2.0 * deceleration)
		if slack <= stopping_distance or radial_speed > max_radial_speed_for_step:
			var radial_after_braking := maxf(radial_speed - deceleration * delta, 0.0)
			radial_after_braking = minf(radial_after_braking, max_radial_speed_for_step)
			current_velocity += outward * (radial_after_braking - radial_speed)
			return current_velocity

	# Handles tangential curvature or unusual initial conditions that would exceed
	# the rope length even without a positive outward radial component.
	if radial_speed > max_radial_speed_for_step:
		current_velocity += outward * (max_radial_speed_for_step - radial_speed)
	return current_velocity

func _physics_step_heavy_yank(delta: float) -> void:
	if _player == null or _targeting == null or delta <= 0.0:
		_stop_heavy_yank()
		return
	if not _yank_button_was_down:
		_yank_button_was_down = true
		var target: MistbornTargetable = _targeting.acquire_action_target(&"iron")
		if not _is_valid_target(target):
			_last_action_type = "HEAVY_OBJECT_YANK_NO_TARGET"
			_last_block_reason = "OBJETIVO_INVALIDO_PARA_TIRON"
			return
		if not HEAVY_IRON.is_movable_heavy_target(target, _player.get_gameplay_mass()):
			_last_action_type = "HEAVY_OBJECT_YANK_REQUIRES_MOVABLE_HEAVY_BODY"
			_last_block_reason = "OBJETO_NO_ES_MOVIL_Y_PESADO"
			return
		if not _targeting.is_iron_action_active():
			_targeting.begin_action_target(target, &"iron")
		_yank_target = target
		_yank_active = true
		_last_block_reason = ""
		_last_action_type = "HEAVY_OBJECT_YANK_HELD"
		iron_target_used.emit(target)

	if not _yank_active:
		# An unsuccessful acquisition consumes this press. Do not silently pick up
		# another target while the button is still held.
		return
	if _yank_target == null or not _is_valid_target(_yank_target):
		_last_block_reason = "OBJETIVO_INVALIDO_DURANTE_TIRON"
		_stop_heavy_yank()
		_yank_button_was_down = true
		return

	var result := HEAVY_IRON.apply_object_yank(
		_yank_target,
		_player,
		FORCE_MODEL.HERO_STRENGTH
	)
	if not _record_heavy_yank_result(_yank_target, result, "HEAVY_OBJECT_YANK_HELD"):
		_last_block_reason = str(result.get("reason", "TIRON_OBJETO_BLOQUEADO"))
		_stop_heavy_yank()
		_yank_button_was_down = true
		return
	if _player.is_on_floor():
		_apply_brace_stabilization(delta)
	_player.set_allomantic_action_active()

func _record_heavy_yank_result(target: MistbornTargetable, result: Dictionary, action_type: String) -> bool:
	if target == null or not is_instance_valid(target) or not bool(result.get("applied", false)):
		return false
	_last_heavy_yank_force = float(result.get("force_newtons", 0.0))
	_last_action_type = action_type
	_impulse_count += 1
	target.set_meta("allomantic_player_receives_response", false)
	target.set_meta("allomantic_target_receives_response", true)
	target.set_meta("allomantic_object_yank_mode", action_type)
	return true

func _stop_heavy_yank() -> void:
	var had_target := _yank_target != null and is_instance_valid(_yank_target)
	if had_target:
		_yank_target.set_meta("allomantic_target_receives_response", false)
		_yank_target.set_meta("allomantic_object_yank_mode", "")
		if _targeting != null and _targeting.get_action_target() == _yank_target:
			_targeting.end_action_target(&"iron")
	_yank_target = null
	_yank_active = false
	_yank_button_was_down = false

func _apply_brace_stabilization(delta: float) -> void:
	if _player == null or delta <= 0.0:
		return
	var horizontal := Vector3(_player.velocity.x, 0.0, _player.velocity.z)
	horizontal = horizontal.move_toward(Vector3.ZERO, heavy_yank_brace_deceleration * delta)
	_player.velocity.x = horizontal.x
	_player.velocity.z = horizontal.z

func _cancel_release_momentum_lock() -> void:
	if _player != null and _player.has_method("cancel_iron_momentum_release"):
		_player.call("cancel_iron_momentum_release")

func _step_mount_arrival(target: MistbornTargetable, delta: float) -> bool:
	if _player == null or target == null or not is_instance_valid(target):
		_clear_mount_arrival()
		return false
	if not target.is_mountable_on_arrival():
		_clear_mount_arrival()
		return false

	var stand_point: Vector3 = target.get_mount_stand_point()
	var player_pos: Vector3 = _player.global_position
	var flat_delta := Vector3(stand_point.x - player_pos.x, 0.0, stand_point.z - player_pos.z)
	var height_offset: float = player_pos.y - stand_point.y

	if _mount_arrival_target != target:
		if not is_mount_capture_eligible(
			flat_delta.length(),
			height_offset,
			mount_capture_horizontal_radius,
			mount_capture_below_surface,
			mount_capture_above_surface
		):
			return false
		_begin_mount_arrival(target, stand_point, player_pos)

	if _mount_arrival_target != target or _mount_arrival_stage == MOUNT_STAGE_NONE:
		return false

	# The player's CharacterBody origin is at its feet; CollisionShape3D is offset
	# upward by half the capsule height. Keep the controller goal just inside the
	# support surface so real collision resolves the final position onto the top.
	var surface_goal := Vector3(stand_point.x, stand_point.y - 0.015, stand_point.z)
	var goal := surface_goal

	if _mount_arrival_stage == MOUNT_STAGE_CLEAR_LAMP:
		# A pull from directly underneath otherwise drives the capsule into the pole/head.
		# First reach a point OUTSIDE and above the head; only then descend/inward onto
		# the perch. The added height makes this an actual clearance waypoint, not just
		# a diagonal shortcut that can scrape through the lamp collision.
		goal = calculate_mount_clearance_goal(
			surface_goal,
			_mount_clear_side,
			mount_clearance_radius,
			mount_clearance_height
		)
		var stage_error := goal - player_pos
		var stage_flat_error := Vector3(stage_error.x, 0.0, stage_error.z).length()
		if stage_flat_error <= 0.32 and absf(stage_error.y) <= 0.42:
			_mount_arrival_stage = MOUNT_STAGE_SETTLE_ON_TOP
			goal = surface_goal

	_steer_mount_arrival(goal, delta)
	_player.set_allomantic_action_active()
	_last_block_reason = "LLEGADA_FAROLA_LIMPIANDO_LATERAL" if _mount_arrival_stage == MOUNT_STAGE_CLEAR_LAMP else "LLEGADA_FAROLA_ATERRIZANDO"

	# We only finish after the actual lamp collider reports support and the player has
	# naturally slowed near the center. No position snap, no vertical drop, and no
	# permanent attachment: after arrival the ordinary grounded controller takes over.
	if _mount_arrival_stage == MOUNT_STAGE_SETTLE_ON_TOP and _player.is_on_floor() and target.is_actor_on_stand_surface(_player):
		var final_flat_error := Vector3(surface_goal.x - _player.global_position.x, 0.0, surface_goal.z - _player.global_position.z).length()
		var horizontal_speed := Vector3(_player.velocity.x, 0.0, _player.velocity.z).length()
		if final_flat_error <= mount_completion_radius and horizontal_speed <= mount_completion_speed and absf(_player.velocity.y) <= 1.25:
			_finish_mount_arrival(target)
	return true

func _begin_mount_arrival(target: MistbornTargetable, stand_point: Vector3, player_pos: Vector3) -> void:
	_mount_arrival_target = target
	var below_surface: bool = player_pos.y < stand_point.y - 0.20
	_mount_arrival_stage = MOUNT_STAGE_CLEAR_LAMP if below_surface else MOUNT_STAGE_SETTLE_ON_TOP

	var outward := Vector3(player_pos.x - stand_point.x, 0.0, player_pos.z - stand_point.z)
	if outward.length_squared() <= 0.04:
		var horizontal_velocity := Vector3(_player.velocity.x, 0.0, _player.velocity.z)
		if horizontal_velocity.length_squared() > 0.04:
			outward = -horizontal_velocity.normalized()
		else:
			var camera_rig := _player.get_node_or_null("CameraRig") as Node3D
			outward = camera_rig.global_basis.z if camera_rig != null else Vector3.BACK
			outward.y = 0.0
	if outward.length_squared() <= 0.0001:
		outward = Vector3.RIGHT
	_mount_clear_side = outward.normalized()

func _steer_mount_arrival(goal: Vector3, delta: float) -> void:
	if delta <= 0.0:
		return
	var error := goal - _player.global_position
	var desired_velocity := calculate_mount_desired_velocity(error, mount_arrival_velocity_gain, mount_arrival_max_speed)
	var correction := calculate_mount_velocity_correction(
		_player.velocity,
		desired_velocity,
		mount_arrival_response,
		mount_arrival_max_acceleration
	)
	# Gravity remains the player controller's responsibility. During airborne arrival,
	# compensate for this frame's gravity so the guidance can shape a landing instead of
	# being unable to hold a controlled upward/lateral path.
	if not _player.is_on_floor():
		correction += Vector3.UP * _player.gravity
	_player.velocity += correction * delta
	var speed := _player.velocity.length()
	if speed > FORCE_MODEL.MAX_TRAVERSAL_SPEED:
		_player.velocity = _player.velocity.normalized() * FORCE_MODEL.MAX_TRAVERSAL_SPEED

func _finish_mount_arrival(target: MistbornTargetable) -> void:
	# This is reached only after CharacterBody3D has collided with the real perch surface.
	_clear_physical_tether()
	# Momentum should already be low; clear the residual only to keep a tiny lamp top usable.
	_player.velocity.x = 0.0
	_player.velocity.z = 0.0
	_player.velocity.y = 0.0
	_last_block_reason = "MONTADO"
	_last_target = target
	_locked_target_point = target.get_mount_stand_point()
	_locked_initial_distance = 0.0
	_locked_upper_cone_factor = 0.0
	_clear_mount_arrival()
	_set_active(false)
	if _targeting != null:
		_targeting.end_action_target(&"iron")

func _clear_mount_arrival() -> void:
	_mount_arrival_target = null
	_mount_arrival_stage = MOUNT_STAGE_NONE

static func calculate_launch_velocity(current_velocity: Vector3, direction: Vector3, launch_speed: float, max_speed: float) -> Vector3:
	var result := current_velocity
	if direction.length_squared() > 0.0001 and launch_speed > 0.0:
		result += direction.normalized() * launch_speed
	var speed_limit := maxf(max_speed, 0.0)
	if speed_limit > 0.0 and result.length() > speed_limit:
		result = result.normalized() * speed_limit
	return result

static func is_mount_capture_eligible(flat_distance: float, height_offset: float, horizontal_radius: float, max_below_surface: float, max_above_surface: float) -> bool:
	return flat_distance >= 0.0 and flat_distance <= horizontal_radius and height_offset >= -max_below_surface and height_offset <= max_above_surface

static func calculate_mount_clearance_goal(surface_goal: Vector3, clear_side: Vector3, radius: float, height: float) -> Vector3:
	var outward := Vector3(clear_side.x, 0.0, clear_side.z)
	if outward.length_squared() <= 0.0001:
		outward = Vector3.RIGHT
	else:
		outward = outward.normalized()
	return surface_goal + outward * maxf(radius, 0.0) + Vector3.UP * maxf(height, 0.0)

static func calculate_mount_desired_velocity(position_error: Vector3, gain: float, max_speed: float) -> Vector3:
	if position_error.length_squared() <= 0.0001:
		return Vector3.ZERO
	var desired := position_error * maxf(gain, 0.0)
	var speed_limit := maxf(max_speed, 0.0)
	if desired.length() > speed_limit:
		desired = desired.normalized() * speed_limit
	return desired

static func calculate_mount_velocity_correction(current_velocity: Vector3, desired_velocity: Vector3, response: float, max_acceleration: float) -> Vector3:
	var correction := (desired_velocity - current_velocity) * maxf(response, 0.0)
	return correction.limit_length(maxf(max_acceleration, 0.0))

static func calculate_arc_steering_direction(direction_to_anchor: Vector3, desired_direction: Vector3) -> Vector3:
	# Project input onto the tangent plane around the anchor radius. Radial attraction
	# remains controlled exclusively by apply_allomantic_interaction(); this helper
	# cannot steer directly into/away from the anchor.
	if direction_to_anchor.length_squared() <= 0.0001 or desired_direction.length_squared() <= 0.0001:
		return Vector3.ZERO
	var radial := direction_to_anchor.normalized()
	var tangent := desired_direction - radial * desired_direction.dot(radial)
	if tangent.length_squared() <= 0.0001:
		return Vector3.ZERO
	return tangent.normalized()

func _apply_iron_arc_steering(target_point: Vector3, delta: float) -> void:
	if _player == null or _player.is_on_floor() or delta <= 0.0 or arc_steering_acceleration <= 0.0:
		return
	var move_input: Vector2 = _player.get_last_move_input()
	var input_strength := clampf(move_input.length(), 0.0, 1.0)
	if input_strength <= 0.05:
		return
	var local_intent := Vector3(move_input.x, 0.0, move_input.y)
	var camera_rig := _player.get_node_or_null("CameraRig") as Node3D
	var camera_yaw := camera_rig.rotation.y if camera_rig != null else _player.rotation.y
	var desired_world_direction := Basis(Vector3.UP, camera_yaw) * local_intent
	if desired_world_direction.length_squared() <= 0.0001:
		return
	var steering_origin: Vector3 = _get_physical_tether_origin() if _physical_tether_active else _player.get_allomantic_origin()
	var direction_to_anchor := target_point - steering_origin
	var tangent_direction := calculate_arc_steering_direction(direction_to_anchor, desired_world_direction)
	if tangent_direction.length_squared() <= 0.0001:
		return
	# Moderate player-input assist creates a steerable magnetic arc; it is bounded,
	# requires WASD input, and keeps both world gravity and radial Iron force active.
	_player.velocity += tangent_direction * arc_steering_acceleration * input_strength * delta
	var speed := _player.velocity.length()
	if speed > FORCE_MODEL.MAX_TRAVERSAL_SPEED:
		_player.velocity = _player.velocity.normalized() * FORCE_MODEL.MAX_TRAVERSAL_SPEED
	_last_arc_steer_direction = tangent_direction

func reset_for_playground() -> void:
	_stop_heavy_yank()
	_stop()
	_clear_physical_tether()
	_button_was_down = false
	_last_arc_steer_direction = Vector3.ZERO
	_impulse_count = 0
	_last_action_type = "NONE"
	_last_heavy_yank_force = 0.0

func _get_target() -> MistbornTargetable:
	if _targeting == null:
		return null
	return _targeting.acquire_action_target(&"iron")

func _get_upper_cone_factor(target: MistbornTargetable) -> float:
	if _player == null or target == null or not is_instance_valid(target):
		return 0.0

	var actor_origin := _player.get_allomantic_origin()
	var target_point := _locked_target_point
	if target_point == Vector3.ZERO:
		target_point = target.get_allomantic_action_point(&"iron", _player.global_position, _player.is_on_floor())

	var toward := target_point - actor_origin
	if toward.length_squared() <= 0.0001:
		return 0.0
	return calculate_upper_cone_factor(toward.normalized(), upper_cone_half_angle_degrees)

static func calculate_upper_cone_factor(direction_to_target: Vector3, half_angle_degrees: float) -> float:
	if direction_to_target.length_squared() <= 0.0001:
		return 0.0
	var direction := direction_to_target.normalized()
	# This is a PHYSICS assist, not a targeting rule. The target has already been
	# selected. The cone is centered on world UP and cares only about the geometry
	# of the selected target relative to the player. Player vertical velocity never
	# enters this decision.
	var up_dot := clampf(direction.dot(Vector3.UP), -1.0, 1.0)
	var cone_limit := cos(deg_to_rad(half_angle_degrees))
	if up_dot <= cone_limit:
		return 0.0

	# The factor is exactly zero at the cone edge and exactly one directly above.
	# Outside the cone, Iron therefore remains exactly at the shared Steel base power.
	return clampf((up_dot - cone_limit) / maxf(1.0 - cone_limit, 0.001), 0.0, 1.0)

static func calculate_quadratic_multiplier(progress: float, boost: float, cone_factor: float) -> float:
	var p := clampf(progress, 0.0, 1.0)
	var c := clampf(cone_factor, 0.0, 1.0)
	return 1.0 + maxf(boost, 0.0) * c * pow(p, 2.0)

func _is_valid_target(target: MistbornTargetable) -> bool:
	if target == null or not is_instance_valid(target):
		return false
	if not target.selectable or not target.is_metallic or not target.iron_pullable:
		return false
	return _player.global_position.distance_to(target.get_allomantic_visual_point()) <= FORCE_MODEL.SHARED_RANGE

func _get_current_pull_direction() -> Vector3:
	if _player == null or _last_target == null or not is_instance_valid(_last_target):
		return Vector3.ZERO
	var point := _last_target.get_allomantic_action_point(&"iron", _player.global_position, _player.is_on_floor())
	var toward := point - _player.get_allomantic_origin()
	return toward.normalized() if toward.length_squared() > 0.0001 else Vector3.ZERO

func _get_web_origin() -> Vector3:
	if _player == null:
		return Vector3.ZERO
	var origin: Vector3 = _player.global_position + Vector3.UP * web_origin_height
	var visual: Node = _player.get_node_or_null("Visual")
	if visual != null and visual.has_method("get_target_socket"):
		var socket: Node3D = visual.call("get_target_socket") as Node3D
		if socket != null and is_instance_valid(socket):
			origin = socket.global_position
	return origin

func _stop() -> void:
	_clear_physical_tether()
	_last_target = null
	_last_block_reason = ""
	_iron_mode = &"none"
	_locked_target_point = Vector3.ZERO
	_locked_initial_distance = 0.0
	_locked_upper_cone_factor = 0.0
	_clear_mount_arrival()
	_set_active(false)
	if _targeting != null:
		_targeting.end_action_target(&"iron")

func _set_active(value: bool) -> void:
	_active = value

func is_active() -> bool:
	return _active or _yank_active

func is_traversal_active() -> bool:
	# PlayerController uses this to decide whether ordinary horizontal acceleration
	# should yield to Iron. Object-yank is an interaction, not traversal.
	return _active and _iron_mode != &"light_object_pull"


func should_assist_airborne_traversal_gravity() -> bool:
	if _physical_tether_active:
		return false
	if not _active or _player == null or _player.is_on_floor() or _yank_active:
		return false
	if _mount_arrival_target != null:
		return false
	if _last_target == null or not is_instance_valid(_last_target):
		return false
	var target_body := _last_target.get_physical_body()
	if target_body is StaticBody3D:
		return true
	if target_body is RigidBody3D:
		# A freely moving object must be at least as heavy as the player before it assists traversal.
		return _last_target.get_allomantic_mass() >= _player.get_gameplay_mass()
	return false

func get_debug_state() -> Dictionary:
	var debug_target := _yank_target if _yank_active else _last_target
	return {
		"active": is_active(),
		"traversal_active": is_traversal_active(),
		"object_yank_active": _yank_active,
		"target_name": debug_target.display_name if debug_target != null and is_instance_valid(debug_target) else "NINGUNO",
		"blocked_reason": _last_block_reason,
		"range": FORCE_MODEL.SHARED_RANGE,
		"force_model": "shared_resolver_or_heavy_object_yank",
		"iron_mode": str(_iron_mode),
		"last_action_type": _last_action_type,
		"initial_traversal_launch_speed": initial_traversal_launch_speed,
		"yank_input_was_down": _yank_button_was_down,
		"heavy_yank_force_newtons": _last_heavy_yank_force,
		"gravity_assist_active": should_assist_airborne_traversal_gravity(),
		"physical_tether_active": _physical_tether_active,
		"physical_tether_length": _physical_tether_length,
		"physical_tether_anchor_point": _physical_tether_anchor_point,
		"physical_tether_correction_gain": physical_tether_correction_gain,
		"physical_tether_pre_tension_deceleration": physical_tether_pre_tension_deceleration,
		"tether_radial_speed_before": _last_tether_radial_speed_before,
		"tether_radial_speed_after": _last_tether_radial_speed_after,
		"release_momentum_lock_time": release_momentum_lock_time,
		"upper_cone_half_angle_degrees": upper_cone_half_angle_degrees,
		"upper_cone_factor": _locked_upper_cone_factor,
		"quadratic_propulsion_boost": quadratic_propulsion_boost,
		"quadratic_propulsion_initial_distance": _locked_initial_distance,
		"mount_arrival_active": _mount_arrival_target != null,
		"mount_arrival_stage": _mount_arrival_stage,
		"mount_clearance_radius": mount_clearance_radius,
		"mount_clearance_height": mount_clearance_height,
		"current_pull_direction": _get_current_pull_direction(),
		"propulsion_target_point": _locked_target_point,
		"arc_steering_acceleration": arc_steering_acceleration,
		"arc_steering_direction": _last_arc_steer_direction,
		"impulse_count": _impulse_count,
	}
