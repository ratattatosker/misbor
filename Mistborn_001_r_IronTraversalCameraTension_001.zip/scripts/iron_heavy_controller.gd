class_name MistbornIronHeavyController
extends RefCounted

## Heavy-object intent and physics are kept separate from the ordinary Iron/light-object
## resolver. This module does not own input state or targeting locks; IronController does.
const FORCE_MODEL = preload("res://scripts/allomantic_force_model.gd")

static func is_movable_heavy_target(target: MistbornTargetable, player_mass: float) -> bool:
	if target == null or not is_instance_valid(target):
		return false
	var body := target.get_physical_body() as RigidBody3D
	if body == null or not is_instance_valid(body) or body.freeze:
		return false
	return target.get_allomantic_mass() >= maxf(player_mass, 0.001)


static func apply_object_yank(
	target: MistbornTargetable,
	actor: CharacterBody3D,
	strength: float
) -> Dictionary:
	if target == null or not is_instance_valid(target) or actor == null or not is_instance_valid(actor):
		return {"applied": false, "reason": "INVALID_TARGET_OR_ACTOR"}
	var body := target.get_physical_body() as RigidBody3D
	if body == null or not is_instance_valid(body) or body.freeze:
		return {"applied": false, "reason": "BODY_NOT_MOVABLE"}
	var actor_mass := FORCE_MODEL.PLAYER_MASS
	if actor.has_method("get_gameplay_mass"):
		actor_mass = maxf(float(actor.call("get_gameplay_mass")), 0.001)
	if target.get_allomantic_mass() < actor_mass:
		return {"applied": false, "reason": "TARGET_NOT_HEAVY_ENOUGH"}
	var actor_origin: Vector3 = actor.global_position + Vector3.UP * 0.95
	if actor.has_method("get_allomantic_origin"):
		actor_origin = actor.call("get_allomantic_origin") as Vector3
	var target_point: Vector3 = target.get_allomantic_action_point(&"iron", actor.global_position, actor.is_on_floor())
	var toward_actor := actor_origin - target_point
	var distance := toward_actor.length()
	if distance <= 0.0001 or distance > FORCE_MODEL.SHARED_RANGE:
		return {"applied": false, "reason": "OUT_OF_RANGE", "distance": distance}
	var direction := toward_actor / distance
	var force := FORCE_MODEL.force_magnitude(distance, strength)
	force = FORCE_MODEL.target_force_for_mass(force, body.mass)
	if force <= 0.0:
		return {"applied": false, "reason": "ZERO_FORCE", "distance": distance}
	body.sleeping = false
	body.apply_central_force(direction * force)
	return {
		"applied": true,
		"reason": "HEAVY_OBJECT_SUSTAINED_YANK",
		"distance": distance,
		"force_newtons": force,
		"body_mass": body.mass
	}
