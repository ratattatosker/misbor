extends "res://scripts/main.gd"

# A compact, original Luthadel movement slice. Inspired by the public Ashes Project
# art-direction pillars (gritty, oppressive, high contrast, stylized reality), but
# all geometry and placement here is procedurally authored for this project.
# The city is deliberately small and mostly static for Intel HD 620 / GL Compatibility.

const CITY_GROUND := Color(0.055, 0.052, 0.052, 1.0)
const STREET_STONE := Color(0.105, 0.095, 0.089, 1.0)
const STONE_DARK := Color(0.105, 0.105, 0.112, 1.0)
const STONE_WARM := Color(0.155, 0.132, 0.120, 1.0)
const STONE_RED := Color(0.165, 0.105, 0.091, 1.0)
const STONE_COOL := Color(0.115, 0.132, 0.145, 1.0)
const ROOF_DARK := Color(0.060, 0.067, 0.074, 1.0)
const IRON := Color(0.24, 0.27, 0.29, 1.0)
const IRON_EDGE := Color(0.37, 0.40, 0.42, 1.0)
const IRON_ACCENT := Color(0.20, 0.48, 0.52, 1.0)
const STEEL_ACCENT := Color(0.58, 0.25, 0.17, 1.0)
const ASH_ACCENT := Color(0.34, 0.31, 0.29, 1.0)
const WINDOW_GLOW := Color(0.80, 0.39, 0.14, 1.0)
const WINDOW_SOFT := Color(0.46, 0.25, 0.14, 1.0)

var _city_material_cache: Dictionary = {}

func _build_experiment_playground() -> void:
	_city_material_cache.clear()
	_build_city_ground_and_streets()
	_build_city_buildings()
	_build_rooftop_routes()
	_build_allomantic_anchor_network()
	_build_city_lamps_and_props()
	_build_city_skyline()
	_build_city_signage()
	_build_ashfall()

func _build_ashfall() -> void:
	# Fewer reusable flakes than the full environment so the city remains affordable
	# on Intel HD 620. Ash is atmosphere, not a full fluid simulation.
	var material := _make_material(Color(0.48, 0.43, 0.41, 0.52), 0.0)
	var rng := RandomNumberGenerator.new()
	rng.seed = 20261010
	_ash_flakes.clear()
	_ash_fall_speeds.clear()
	_ash_drifts.clear()
	_ash_mesh = SphereMesh.new()
	_ash_mesh.radius = 0.028
	_ash_mesh.height = 0.056
	for i in range(56):
		var flake := MeshInstance3D.new()
		flake.name = "CityAshFlake_%03d" % i
		flake.mesh = _ash_mesh
		flake.material_override = material
		flake.position = Vector3(rng.randf_range(-44.0, 44.0), rng.randf_range(2.0, 23.0), rng.randf_range(-96.0, 34.0))
		add_child(flake)
		_ash_flakes.append(flake)
		_ash_fall_speeds.append(rng.randf_range(0.7, 1.6))
		_ash_drifts.append(rng.randf_range(-0.12, 0.12))

func _build_city_ground_and_streets() -> void:
	# Compact block, not the full Luthadel map. The main avenue points toward the skyline.
	_add_box_static("AshDistrictGround", Vector3(0.0, -0.50, -17.0), Vector3(118.0, 1.0, 118.0), CITY_GROUND)
	_add_box_static("MainAvenue", Vector3(0.0, 0.025, -21.0), Vector3(13.0, 0.12, 94.0), STREET_STONE)
	_add_box_static("CrossStreet", Vector3(0.0, 0.035, -22.0), Vector3(84.0, 0.14, 9.0), Color(0.090, 0.083, 0.079, 1.0))
	_add_box_static("SouthLane", Vector3(0.0, 0.02, 18.0), Vector3(56.0, 0.10, 6.0), Color(0.080, 0.076, 0.073, 1.0))
	_add_box_static("WestAlley", Vector3(-30.0, 0.025, -21.0), Vector3(5.0, 0.11, 78.0), Color(0.074, 0.071, 0.069, 1.0))
	_add_box_static("EastAlley", Vector3(30.0, 0.025, -21.0), Vector3(5.0, 0.11, 78.0), Color(0.074, 0.071, 0.069, 1.0))

	# The spawn plaza is a recognisable hub with dark stone, iron seams and a ruined fountain.
	_add_box_visual(self, Vector3(0.0, 0.10, 0.0), Vector3(14.0, 0.07, 18.0), Color(0.13, 0.12, 0.115, 1.0))
	_add_box_visual(self, Vector3(0.0, 0.145, -8.5), Vector3(13.4, 0.018, 0.08), IRON_EDGE)
	_add_box_visual(self, Vector3(-6.7, 0.145, 0.0), Vector3(0.08, 0.018, 17.0), IRON_EDGE)
	_add_box_visual(self, Vector3(6.7, 0.145, 0.0), Vector3(0.08, 0.018, 17.0), IRON_EDGE)
	_add_cylinder_visual(self, Vector3(0.0, 0.26, -4.5), 2.1, 0.34, Color(0.20, 0.19, 0.18, 1.0))
	_add_cylinder_visual(self, Vector3(0.0, 0.49, -4.5), 1.35, 0.16, IRON)
	_add_cylinder_visual(self, Vector3(0.0, 0.74, -4.5), 0.42, 0.40, Color(0.17, 0.16, 0.15, 1.0))
	_add_box_visual(self, Vector3(0.0, 0.06, 1.1), Vector3(0.28, 0.03, 11.0), Color(0.35, 0.27, 0.21, 1.0))

	# Low walls, broken curb stones and drain plates give the ground a used, oppressive feel.
	for i in range(8):
		var z := 10.0 - float(i) * 4.3
		_add_box_static("CurbWest_%02d" % i, Vector3(-7.4, 0.18, z), Vector3(0.36, 0.34, 2.6), Color(0.16, 0.145, 0.13, 1.0))
		_add_box_static("CurbEast_%02d" % i, Vector3(7.4, 0.18, z - 1.8), Vector3(0.36, 0.34, 2.6), Color(0.16, 0.145, 0.13, 1.0))
	for i in range(7):
		var z := 8.5 - float(i) * 10.2
		_add_cylinder_visual(self, Vector3(-2.2 if i % 2 == 0 else 2.2, 0.12, z), 0.72, 0.08, Color(0.20, 0.21, 0.21, 1.0))
		_add_cylinder_visual(self, Vector3(-2.2 if i % 2 == 0 else 2.2, 0.164, z), 0.56, 0.014, Color(0.075, 0.078, 0.080, 1.0))

func _build_city_buildings() -> void:
	# name, center x/z, total wall height, width, depth, palette index, accessible roof
	var buildings: Array[Dictionary] = [
		{"name":"SkaaTenement_W1", "x":-13.0, "z":-4.0, "h":8.5, "w":11.0, "d":13.0, "p":0, "ramp":true},
		{"name":"Ironworks_W", "x":-13.5, "z":-22.5, "h":14.0, "w":12.0, "d":13.0, "p":1, "ramp":false},
		{"name":"OldGuild_W", "x":-13.0, "z":-42.0, "h":10.0, "w":10.5, "d":13.0, "p":2, "ramp":false},
		{"name":"Foundry_W", "x":-25.0, "z":-18.0, "h":10.5, "w":9.0, "d":14.0, "p":3, "ramp":false},
		{"name":"WatchHouse_W", "x":-25.0, "z":-3.0, "h":15.5, "w":8.5, "d":9.0, "p":1, "ramp":false},
		{"name":"UpperTenement_W", "x":-24.0, "z":-42.0, "h":13.0, "w":9.0, "d":12.0, "p":0, "ramp":false},
		{"name":"RiversideStore_W", "x":-34.0, "z":-33.0, "h":7.5, "w":8.0, "d":13.0, "p":2, "ramp":false},
		{"name":"SkaaTenement_E1", "x":13.0, "z":-7.0, "h":11.0, "w":10.5, "d":14.0, "p":3, "ramp":true},
		{"name":"GrandTenement_E", "x":14.0, "z":-26.0, "h":16.0, "w":12.5, "d":13.0, "p":2, "ramp":false},
		{"name":"OldGuild_E", "x":13.0, "z":-44.0, "h":10.0, "w":11.0, "d":12.5, "p":0, "ramp":false},
		{"name":"WatchHouse_E", "x":25.0, "z":-7.0, "h":14.0, "w":8.0, "d":10.0, "p":1, "ramp":false},
		{"name":"Foundry_E", "x":26.0, "z":-25.0, "h":11.5, "w":9.0, "d":15.0, "p":3, "ramp":false},
		{"name":"UpperTenement_E", "x":25.0, "z":-44.0, "h":13.0, "w":9.0, "d":12.0, "p":2, "ramp":false},
		{"name":"NorthManor_W", "x":-11.0, "z":-60.0, "h":17.0, "w":14.0, "d":12.0, "p":1, "ramp":false},
		{"name":"NorthManor_E", "x":11.0, "z":-61.0, "h":19.0, "w":14.0, "d":12.0, "p":3, "ramp":false}
	]

	for i in range(buildings.size()):
		var b: Dictionary = buildings[i]
		var size := Vector3(float(b["w"]), float(b["h"]), float(b["d"]))
		var center := Vector3(float(b["x"]), float(b["h"]) * 0.5, float(b["z"]))
		var body := _add_box_static(String(b["name"]), center, size, _wall_color(int(b["p"])))
		_add_building_facade(body, size, int(b["p"]), i)
		_add_roof_parapets(String(b["name"]), center, size, bool(b["ramp"]))
		_add_rooftop_details(String(b["name"]), center, size, i)
		if bool(b["ramp"]):
			var roof_y := float(b["h"])
			var front_z := float(b["z"]) + float(b["d"]) * 0.5 - 0.4
			var start_z := front_z + maxf(15.0, roof_y * 1.9)
			_add_ramp(String(b["name"]) + "_RoofRamp", float(b["x"]), start_z, front_z, roof_y)

	# Small roofline additions create the tall, narrow silhouette without expensive assets.
	_add_spire("WestBellSpire", Vector3(-25.0, 17.2, -3.0), 5.8, 1.35, Color(0.13, 0.135, 0.15, 1.0))
	_add_spire("EastBellSpire", Vector3(25.0, 15.4, -7.0), 6.8, 1.45, Color(0.13, 0.135, 0.15, 1.0))
	_add_spire("NorthBellSpire", Vector3(11.0, 20.2, -61.0), 8.0, 1.7, Color(0.12, 0.12, 0.135, 1.0))

func _add_building_facade(parent: Node3D, size: Vector3, palette_index: int, variant: int) -> void:
	var wall_half_x := size.x * 0.5
	var wall_half_z := size.z * 0.5
	# Batch repeated facade elements into MultiMeshes. The city still reads as dense,
	# but doesn't create hundreds of separate draw calls on the user's integrated GPU.
	var pilasters: Array[Vector3] = []
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			pilasters.append(Vector3(sx * (wall_half_x - 0.20), 0.0, sz * (wall_half_z + 0.035)))
	_add_box_batch(parent, "FacadePilasters", Vector3(0.30, size.y + 0.10, 0.22), pilasters, Color(0.075, 0.073, 0.074, 1.0), 0.15)

	var belt_positions: Array[Vector3] = []
	for floor_y in range(1, int(floor(size.y / 3.0))):
		var local_y := -size.y * 0.5 + float(floor_y) * 2.7
		belt_positions.append(Vector3(0.0, local_y, wall_half_z + 0.035))
		belt_positions.append(Vector3(0.0, local_y, -wall_half_z - 0.035))
	_add_box_batch(parent, "FacadeStoneBelts", Vector3(size.x + 0.12, 0.15, 0.12), belt_positions, Color(0.22, 0.19, 0.17, 1.0), 0.10)

	var rows := maxi(2, int(floor(size.y / 2.8)))
	var cols := maxi(3, int(floor(size.x / 2.15)))
	var available_width := maxf(size.x - 2.0, 1.0)
	var available_height := maxf(size.y - 1.8, 1.0)
	var front_glow: Array[Vector3] = []
	var front_soft: Array[Vector3] = []
	var back_glow: Array[Vector3] = []
	var back_soft: Array[Vector3] = []
	var side_soft: Array[Vector3] = []
	for row in range(rows):
		var wy := -size.y * 0.5 + 1.3 + float(row) * (available_height / maxf(float(rows - 1), 1.0))
		for col in range(cols):
			var wx := -available_width * 0.5 + float(col) * (available_width / maxf(float(cols - 1), 1.0))
			var glow := (row * 3 + col + variant) % 4 == 0
			var front_pos := Vector3(wx, wy, wall_half_z + 0.055)
			if glow:
				front_glow.append(front_pos)
			else:
				front_soft.append(front_pos)
			if (col + row + palette_index) % 2 == 0:
				var back_pos := Vector3(wx, wy, -wall_half_z - 0.055)
				if glow:
					back_glow.append(back_pos)
				else:
					back_soft.append(back_pos)
			if col % 2 == 0:
				var side_z := wx * size.z / maxf(size.x, 1.0)
				side_soft.append(Vector3(wall_half_x + 0.055, wy, side_z))
				side_soft.append(Vector3(-wall_half_x - 0.055, wy, side_z))
	var window_size := Vector3(0.58, 0.95, 0.065)
	_add_box_batch(parent, "WindowsFrontGlow", window_size, front_glow, WINDOW_GLOW, 0.05, true)
	_add_box_batch(parent, "WindowsFrontSoft", window_size, front_soft, WINDOW_SOFT)
	_add_box_batch(parent, "WindowsBackGlow", window_size, back_glow, WINDOW_GLOW, 0.05, true)
	_add_box_batch(parent, "WindowsBackSoft", window_size, back_soft, WINDOW_SOFT)
	_add_box_batch(parent, "WindowsSides", Vector3(0.065, 0.90, 0.58), side_soft, WINDOW_SOFT)

	# Rusted soot streaks and a few balconies break the strict box shapes.
	for i in range(2 + (variant % 2)):
		var local_x := -size.x * 0.34 + float(i) * size.x * 0.32
		var streak_height := size.y * (0.32 + float((i + variant) % 3) * 0.08)
		_add_city_visual(parent, Vector3(local_x, -size.y * 0.13, wall_half_z + 0.07), Vector3(0.18 + float(i % 2) * 0.12, streak_height, 0.035), Color(0.055, 0.052, 0.052, 1.0), 0.0)
	if variant % 3 != 1:
		_add_city_visual(parent, Vector3(0.0, -size.y * 0.5 + 1.3, wall_half_z + 0.26), Vector3(minf(size.x * 0.70, 5.0), 0.18, 0.65), Color(0.19, 0.135, 0.105, 1.0), 0.05)

func _add_box_batch(parent: Node3D, batch_name: String, box_size: Vector3, positions: Array[Vector3], color: Color, metallic: float = 0.0, emissive: bool = false) -> void:
	if positions.is_empty():
		return
	var batch_mesh := BoxMesh.new()
	batch_mesh.size = box_size
	var multimesh := MultiMesh.new()
	multimesh.transform_format = MultiMesh.TRANSFORM_3D
	multimesh.mesh = batch_mesh
	multimesh.instance_count = positions.size()
	for i in range(positions.size()):
		multimesh.set_instance_transform(i, Transform3D(Basis.IDENTITY, positions[i]))
	var instance := MultiMeshInstance3D.new()
	instance.name = batch_name
	instance.multimesh = multimesh
	instance.material_override = _city_material(color, metallic, emissive)
	parent.add_child(instance)

func _add_roof_parapets(building_name: String, center: Vector3, size: Vector3, ramp_gap: bool) -> void:
	var roof_y := center.y + size.y * 0.5 + 0.36
	var rail_h := 0.72
	var rail_t := 0.32
	var half_x := size.x * 0.5
	var half_z := size.z * 0.5
	# Rear edge and two sides. The roof is reachable on purpose; parapets are low enough to vault.
	_add_box_static(building_name + "_ParapetBack", Vector3(center.x, roof_y, center.z - half_z + 0.16), Vector3(size.x, rail_h, rail_t), IRON)
	_add_box_static(building_name + "_ParapetWest", Vector3(center.x - half_x + 0.16, roof_y, center.z), Vector3(rail_t, rail_h, size.z), IRON)
	_add_box_static(building_name + "_ParapetEast", Vector3(center.x + half_x - 0.16, roof_y, center.z), Vector3(rail_t, rail_h, size.z), IRON)
	if ramp_gap:
		var flank_width := maxf((size.x - 3.8) * 0.5, 0.8)
		_add_box_static(building_name + "_ParapetFrontL", Vector3(center.x - (flank_width + 3.8) * 0.5, roof_y, center.z + half_z - 0.16), Vector3(flank_width, rail_h, rail_t), IRON)
		_add_box_static(building_name + "_ParapetFrontR", Vector3(center.x + (flank_width + 3.8) * 0.5, roof_y, center.z + half_z - 0.16), Vector3(flank_width, rail_h, rail_t), IRON)
	else:
		_add_box_static(building_name + "_ParapetFront", Vector3(center.x, roof_y, center.z + half_z - 0.16), Vector3(size.x, rail_h, rail_t), IRON)

func _add_rooftop_details(building_name: String, center: Vector3, size: Vector3, variant: int) -> void:
	var top_y := center.y + size.y * 0.5
	# Chimneys occupy corners instead of the central landing lanes.
	for i in range(1 + variant % 2):
		var x_off := -size.x * 0.25 + float(i) * size.x * 0.42
		_add_box_static(building_name + "_Chimney_%02d" % i, Vector3(center.x + x_off, top_y + 0.75, center.z - size.z * 0.20), Vector3(0.70, 1.5, 0.72), Color(0.075, 0.067, 0.063, 1.0))
		_add_box_visual(self, Vector3(center.x + x_off, top_y + 1.55, center.z - size.z * 0.20), Vector3(0.94, 0.18, 0.95), IRON)
	# Wide, low metal service rails serve as readable urban traversal silhouettes.
	if size.x >= 10.0:
		_add_city_visual(self, Vector3(center.x, top_y + 0.25, center.z + size.z * 0.30), Vector3(size.x * 0.58, 0.18, 0.22), IRON_EDGE, 0.55)

func _add_ramp(ramp_name: String, x: float, low_z: float, high_z: float, roof_height: float) -> void:
	var horizontal_length := absf(low_z - high_z)
	if horizontal_length <= 0.5 or roof_height <= 0.5:
		return
	var ramp_length := sqrt(horizontal_length * horizontal_length + roof_height * roof_height)
	var thickness := 0.36
	var ramp := _add_box_static(ramp_name, Vector3(x, roof_height * 0.5 - thickness * 0.42, (low_z + high_z) * 0.5), Vector3(3.0, thickness, ramp_length), Color(0.13, 0.12, 0.115, 1.0))
	# Positive X rotation makes the -Z end rise. CharacterBody floor angle accepts this slope.
	ramp.rotation.x = atan2(roof_height, horizontal_length)
	_add_city_visual(ramp, Vector3(0.0, thickness * 0.5 + 0.025, 0.0), Vector3(2.65, 0.035, ramp_length * 0.98), IRON_EDGE, 0.35)
	for side in [-1.0, 1.0]:
		var rail := _add_box_static(ramp_name + ("_RailL" if side < 0.0 else "_RailR"), Vector3(x + side * 1.42, roof_height * 0.5 - thickness * 0.42 + 0.38, (low_z + high_z) * 0.5), Vector3(0.15, 0.76, ramp_length * 0.92), IRON)
		rail.rotation.x = ramp.rotation.x

func _build_rooftop_routes() -> void:
	# Elevated catwalks connect actual roof collision surfaces so the routes can be traversed physically.
	_add_box_static("HighCatwalk_WestEast", Vector3(0.0, 15.0, -22.5), Vector3(23.0, 0.40, 2.6), Color(0.10, 0.115, 0.125, 1.0))
	_add_box_visual(self, Vector3(0.0, 15.23, -22.5), Vector3(22.5, 0.045, 2.2), IRON_EDGE)
	_add_box_static("HighCatwalkRail_L", Vector3(0.0, 15.9, -23.7), Vector3(22.8, 0.75, 0.18), IRON)
	_add_box_static("HighCatwalkRail_R", Vector3(0.0, 15.9, -21.3), Vector3(22.8, 0.75, 0.18), IRON)

	_add_box_static("MidCatwalk_WestToCentre", Vector3(-6.0, 10.9, -39.5), Vector3(13.5, 0.36, 2.3), Color(0.10, 0.11, 0.12, 1.0))
	_add_box_visual(self, Vector3(-6.0, 11.11, -39.5), Vector3(13.0, 0.035, 2.0), IRON_EDGE)
	_add_box_static("MidCatwalkRail_W", Vector3(-6.0, 11.55, -40.55), Vector3(13.5, 0.58, 0.14), IRON)
	_add_box_static("MidCatwalkRail_E", Vector3(-6.0, 11.55, -38.45), Vector3(13.5, 0.58, 0.14), IRON)

	# Traversal over the street: a pipe bridge and two suspended metal crossbars.
	_add_box_static("StreetPipeBridge", Vector3(0.0, 9.6, -10.5), Vector3(8.5, 0.42, 1.2), IRON)
	_add_cylinder_static("BridgePipeL", Vector3(-3.4, 10.35, -10.5), 0.12, 7.4, IRON_EDGE, true)
	_add_cylinder_static("BridgePipeR", Vector3(3.4, 10.35, -10.5), 0.12, 7.4, IRON_EDGE, true)
	_add_city_visual(self, Vector3(0.0, 10.0, -10.5), Vector3(8.0, 0.08, 0.08), WINDOW_GLOW, 0.25, true)

func _build_allomantic_anchor_network() -> void:
	# Oversized, architectural metal anchors. Their targeting volumes are intentionally
	# generous and align with a visible iron frame, so aiming is a choice rather than pixel hunting.
	_add_city_anchor("Anchor_PlazaGate", "Arco de hierro de la plaza", Vector3(0.0, 7.9, -11.0), 5.0, 4.2)
	_add_city_anchor("Anchor_WestLow", "Anclaje oeste · bajo", Vector3(-11.5, 10.2, -8.0), 4.5, 3.2)
	_add_city_anchor("Anchor_WestHigh", "Anclaje oeste · alto", Vector3(-24.4, 16.8, -5.8), 4.8, 3.8)
	_add_city_anchor("Anchor_WestRoof", "Anclaje de tejado oeste", Vector3(-13.5, 15.5, -25.0), 4.8, 3.8)
	_add_city_anchor("Anchor_Catwalk", "Anclaje del puente alto", Vector3(0.0, 16.2, -22.5), 5.2, 3.6)
	_add_city_anchor("Anchor_EastRoof", "Anclaje de tejado este", Vector3(14.0, 17.5, -26.0), 4.8, 3.8)
	_add_city_anchor("Anchor_EastHigh", "Anclaje este · alto", Vector3(25.0, 15.0, -8.0), 4.8, 3.6)
	_add_city_anchor("Anchor_Foundry", "Anclaje de la fundición", Vector3(-24.0, 12.7, -20.0), 5.0, 3.8)
	_add_city_anchor("Anchor_NorthGate", "Anclaje del arco norte", Vector3(0.0, 21.5, -48.0), 5.8, 4.2)
	_add_city_anchor("Anchor_SouthAlley", "Anclaje al sur de la plaza", Vector3(0.0, 6.2, 12.5), 4.6, 3.4)

	# Movable metal scraps allow force/mass tests without leaving the city scene.
	_add_target_box("CityMetalCrate_8kg", "Cajón metálico · 8 kg", "SMALL_OBJECT", Vector3(-4.0, 0.75, 8.0), Vector3(1.2, 1.2, 1.2), 2.5)
	_add_movable_heavy_iron_crate("CityHeavyIronCrate", "Cajón de hierro · 120 kg", Vector3(2.5, 0.72, -3.6), Vector3(1.35, 1.44, 1.35), 120.0)
	_add_target_box("CityMetalPlate_25kg", "Placa de hierro · 25 kg", "METAL_OBJECT", Vector3(4.0, 0.9, 8.0), Vector3(1.5, 1.6, 1.4), 2.5)
	_add_metal_cylinder_static("CityManhole_01", "Tapa de alcantarilla", Vector3(-2.4, 0.11, 3.5), 0.85, 0.10, 2.0)

func _add_city_anchor(target_id: String, display_name: String, center: Vector3, width: float, height: float) -> MistbornTargetable:
	var body := StaticBody3D.new()
	body.name = target_id + "_Frame"
	body.position = center
	body.collision_layer = 1
	body.collision_mask = 1
	var physical := CollisionShape3D.new()
	var physical_shape := BoxShape3D.new()
	physical_shape.size = Vector3(0.70, height * 0.82, 0.70)
	physical.shape = physical_shape
	body.add_child(physical)
	add_child(body)

	var post_w := 0.28
	var top_y := height * 0.5
	var half_w := width * 0.5
	# A broad, almost gate-like iron frame: it reads at distance and keeps its metal identity.
	_add_city_visual(body, Vector3(-half_w, 0.0, 0.0), Vector3(post_w, height, 0.48), IRON, 0.72)
	_add_city_visual(body, Vector3(half_w, 0.0, 0.0), Vector3(post_w, height, 0.48), IRON, 0.72)
	_add_city_visual(body, Vector3(0.0, top_y, 0.0), Vector3(width + 0.55, post_w, 0.58), IRON_EDGE, 0.78)
	_add_city_visual(body, Vector3(0.0, -top_y, 0.0), Vector3(width + 0.55, post_w, 0.58), IRON_EDGE, 0.72)
	_add_city_visual(body, Vector3(0.0, 0.0, 0.0), Vector3(0.14, height * 0.62, 0.66), IRON_ACCENT, 0.9, true)
	_add_city_visual(body, Vector3(0.0, top_y + 0.28, 0.0), Vector3(width * 0.58, 0.11, 0.82), STEEL_ACCENT, 0.6)

	var target := MistbornTargetable.new()
	target.name = "Target_" + target_id
	target.target_id = target_id
	target.display_name = display_name
	target.target_type = "ANCHOR"
	target.selection_priority = 5.2
	target.target_size_priority = 1.0
	target.target_height_priority = 0.94
	target.target_accessibility = 0.95
	target.is_metallic = true
	target.steel_pushable = true
	target.iron_pullable = true
	target.allomantic_profile = "ANCHOR"
	target.allomantic_visual_mass = 1000000.0
	target.show_in_allomantic_sight = true
	# These large frames are magnetic anchors, not landing surfaces. The roofs and catwalks
	# are the actual collision/support surfaces, avoiding invisible landing atop a frame.
	target.standable_on = false
	target.mountable_on_arrival = false
	var area_collision := CollisionShape3D.new()
	var area_shape := BoxShape3D.new()
	area_shape.size = Vector3(width + 2.4, height + 1.8, 3.6)
	area_collision.shape = area_shape
	target.add_child(area_collision)
	body.add_child(target)
	target.set_physical_body(body)
	return target

func _add_movable_heavy_iron_crate(
	target_id: String,
	display_name: String,
	center: Vector3,
	size: Vector3,
	mass_kg: float
) -> MistbornTargetable:
	# Unlike the lightweight visual test props inherited from the older main scene,
	# this is a genuine RigidBody3D. Iron Heavy can therefore pull it without moving
	# the player, while a sustained traversal input still pulls the player toward it.
	var body := RigidBody3D.new()
	body.name = target_id + "_Body"
	body.position = center
	body.mass = maxf(mass_kg, 0.1)
	body.collision_layer = 1
	body.collision_mask = 1
	body.linear_damp = 0.7
	body.angular_damp = 4.0
	var physics_material := PhysicsMaterial.new()
	physics_material.friction = 0.82
	physics_material.bounce = 0.0
	body.physics_material_override = physics_material

	var physical_shape := CollisionShape3D.new()
	var physical_box := BoxShape3D.new()
	physical_box.size = size
	physical_shape.shape = physical_box
	body.add_child(physical_shape)

	var target := MistbornTargetable.new()
	target.name = "Target_" + target_id
	target.target_id = target_id
	target.display_name = display_name
	target.target_type = "METAL_OBJECT"
	target.selection_priority = 6.0
	target.target_size_priority = 0.86
	target.target_height_priority = 0.62
	target.target_accessibility = 0.96
	target.is_metallic = true
	target.steel_pushable = true
	target.iron_pullable = true
	target.allomantic_profile = "DECORATIVE"
	target.allomantic_visual_mass = maxf(mass_kg, 0.1)
	target.show_in_allomantic_sight = true
	target.standable_on = false
	target.mountable_on_arrival = false
	var target_collision := CollisionShape3D.new()
	var target_box := BoxShape3D.new()
	target_box.size = size * 1.22
	target_collision.shape = target_box
	target.add_child(target_collision)
	_add_city_visual(target, Vector3.ZERO, size, IRON, 0.82)
	_add_city_visual(target, Vector3(0.0, size.y * 0.31, 0.0), Vector3(size.x * 1.015, 0.10, size.z * 1.015), IRON_EDGE, 0.9)
	_add_city_visual(target, Vector3(0.0, -size.y * 0.31, 0.0), Vector3(size.x * 1.015, 0.10, size.z * 1.015), IRON_EDGE, 0.9)
	_add_city_visual(target, Vector3(0.0, 0.0, -size.z * 0.505), Vector3(size.x * 0.42, size.y * 0.60, 0.035), IRON_ACCENT, 0.72, true)
	body.add_child(target)
	target.set_physical_body(body)
	add_child(body)
	return target

func _build_city_lamps_and_props() -> void:
	var lamp_positions: Array[Vector3] = [
		Vector3(-5.4, 0.0, 7.0), Vector3(5.4, 0.0, 4.0),
		Vector3(-5.4, 0.0, -15.0), Vector3(5.4, 0.0, -31.0),
		Vector3(-5.4, 0.0, -47.0), Vector3(5.4, 0.0, -57.0)
	]
	for i in range(lamp_positions.size()):
		_add_city_lamp("AshLamp_%02d" % i, lamp_positions[i], i % 2 == 0)

	# Awning frames, hanging signboards and chains (stylized, static details).
	for side in [-1.0, 1.0]:
		for i in range(3):
			var x := side * (8.0 + float(i % 2) * 1.1)
			var z := -5.0 - float(i) * 13.0
			_add_city_visual(self, Vector3(x, 3.35, z), Vector3(0.13, 5.2, 0.13), IRON, 0.65)
			_add_city_visual(self, Vector3(x + side * 1.3, 4.8, z), Vector3(2.9, 0.14, 0.14), IRON_EDGE, 0.55)
			var awning_color := Color(0.16, 0.065, 0.055, 1.0) if i % 2 == 0 else Color(0.20, 0.15, 0.11, 1.0)
			_add_city_visual(self, Vector3(x + side * 1.3, 4.55, z), Vector3(3.0, 0.10, 2.4), awning_color, 0.0)

	# Two low-intensity warm light pools; no dynamic shadows on integrated graphics.
	_add_city_omni_light("PlazaLanternGlow", Vector3(-5.2, 4.0, 1.5), Color(1.0, 0.47, 0.19, 1.0), 0.55, 9.0)
	_add_city_omni_light("NorthStreetGlow", Vector3(5.0, 5.5, -34.0), Color(0.87, 0.39, 0.16, 1.0), 0.42, 10.0)

func _add_city_lamp(lamp_name: String, ground: Vector3, warm: bool) -> void:
	var root := Node3D.new()
	root.name = lamp_name
	root.position = ground
	add_child(root)
	_add_city_visual(root, Vector3(0.0, 2.3, 0.0), Vector3(0.18, 4.6, 0.18), IRON, 0.7)
	_add_city_visual(root, Vector3(0.0, 4.4, 0.0), Vector3(0.85, 0.22, 0.75), Color(0.17, 0.14, 0.12, 1.0), 0.6)
	_add_city_visual(root, Vector3(0.0, 4.62, 0.0), Vector3(0.42, 0.26, 0.42), WINDOW_GLOW if warm else WINDOW_SOFT, 0.0, true)
	_add_city_visual(root, Vector3(0.0, 4.78, 0.0), Vector3(0.16, 0.16, 0.16), IRON_EDGE, 0.65)

func _add_city_omni_light(light_name: String, at: Vector3, color: Color, energy: float, light_range: float) -> void:
	var light := OmniLight3D.new()
	light.name = light_name
	light.position = at
	light.light_color = color
	light.light_energy = energy
	light.omni_range = light_range
	light.shadow_enabled = false
	add_child(light)

func _build_city_skyline() -> void:
	# A layered, non-colliding skyline makes the district feel like one block in a vast city.
	var skyline: Array[Dictionary] = [
		{"x":-43.0, "z":-62.0, "w":10.0, "h":28.0, "d":9.0},
		{"x":-32.0, "z":-69.0, "w":9.0, "h":35.0, "d":8.0},
		{"x":-19.0, "z":-72.0, "w":12.0, "h":24.0, "d":10.0},
		{"x":0.0, "z":-76.0, "w":16.0, "h":42.0, "d":11.0},
		{"x":21.0, "z":-72.0, "w":12.0, "h":28.0, "d":10.0},
		{"x":36.0, "z":-68.0, "w":11.0, "h":36.0, "d":9.0},
		{"x":47.0, "z":-60.0, "w":8.0, "h":23.0, "d":8.0}
	]
	for i in range(skyline.size()):
		var b: Dictionary = skyline[i]
		var h := float(b["h"])
		var center := Vector3(float(b["x"]), h * 0.5, float(b["z"]))
		var size := Vector3(float(b["w"]), h, float(b["d"]))
		_add_city_visual(self, center, size, Color(0.060 + float(i % 3) * 0.009, 0.062, 0.071, 1.0), 0.0)
		_add_spire("DistantSpire_%02d" % i, Vector3(center.x, h + 2.0, center.z), 7.0 + float(i % 3) * 3.5, 1.5 + float(i % 2) * 0.4, Color(0.075, 0.078, 0.090, 1.0))

	# The Imperial skyline landmark: massive silhouette, deliberately distant and not targetable.
	_add_city_visual(self, Vector3(0.0, 18.0, -83.0), Vector3(20.0, 36.0, 15.0), Color(0.048, 0.049, 0.058, 1.0), 0.0)
	# Stepped, low-poly cupola under the central needle recalls the domes and long
	# spires visible in Ashes concept art while remaining a handful of draw calls.
	_add_tapered_roof("DistantImperialDomeLower", Vector3(0.0, 35.5, -83.0), 8.6, 6.0, 2.4, Color(0.075, 0.071, 0.078, 1.0))
	_add_tapered_roof("DistantImperialDomeUpper", Vector3(0.0, 37.6, -83.0), 6.0, 3.5, 2.0, Color(0.065, 0.064, 0.073, 1.0))
	_add_tapered_roof("DistantImperialDomeCap", Vector3(0.0, 39.3, -83.0), 3.5, 1.75, 1.4, Color(0.060, 0.060, 0.069, 1.0))
	_add_spire("DistantImperialNeedle", Vector3(0.0, 38.0, -83.0), 24.0, 3.0, Color(0.043, 0.044, 0.052, 1.0))
	_add_spire("ImperialNeedleWest", Vector3(-7.0, 26.0, -83.0), 18.0, 2.3, Color(0.048, 0.048, 0.056, 1.0))
	_add_spire("ImperialNeedleEast", Vector3(8.0, 28.0, -83.0), 16.0, 2.1, Color(0.048, 0.048, 0.056, 1.0))

func _add_tapered_roof(roof_name: String, bottom_position: Vector3, bottom_radius: float, top_radius: float, height: float, color: Color) -> void:
	var mesh_node := MeshInstance3D.new()
	mesh_node.name = roof_name
	mesh_node.position = bottom_position + Vector3.UP * (height * 0.5)
	var roof_mesh := CylinderMesh.new()
	roof_mesh.top_radius = top_radius
	roof_mesh.bottom_radius = bottom_radius
	roof_mesh.height = height
	roof_mesh.radial_segments = 12
	mesh_node.mesh = roof_mesh
	mesh_node.material_override = _city_material(color, 0.18, false)
	add_child(mesh_node)

func _add_spire(spire_name: String, base_position: Vector3, height: float, radius: float, color: Color) -> void:
	var mesh_node := MeshInstance3D.new()
	mesh_node.name = spire_name
	mesh_node.position = base_position + Vector3.UP * (height * 0.5)
	var cone := CylinderMesh.new()
	cone.top_radius = 0.04
	cone.bottom_radius = radius
	cone.height = height
	cone.radial_segments = 7
	mesh_node.mesh = cone
	mesh_node.material_override = _city_material(color, 0.16, false)
	add_child(mesh_node)
	var cap := MeshInstance3D.new()
	cap.position = base_position + Vector3.UP * (height + 0.2)
	var cap_mesh := CylinderMesh.new()
	cap_mesh.top_radius = 0.02
	cap_mesh.bottom_radius = radius * 0.23
	cap_mesh.height = 0.8
	cap_mesh.radial_segments = 6
	cap.mesh = cap_mesh
	cap.material_override = _city_material(Color(0.16, 0.14, 0.13, 1.0), 0.2, false)
	add_child(cap)

func _build_city_signage() -> void:
	_add_city_label("DISTRICT_TITLE", "DISTRITO DE LA CENIZA", Vector3(0.0, 3.5, 5.0), Color(0.75, 0.68, 0.57, 1.0), 23)
	_add_city_label("IRON_ROUTE", "IRON · ANCLAS GRANDES / E + WASD EN EL AIRE", Vector3(-15.0, 13.5, -15.0), IRON_ACCENT, 18)
	_add_city_label("STEEL_ROUTE", "STEEL · APUNTA A UN ANCLA / Q + W PARA ASISTENCIA FRONTAL", Vector3(14.0, 12.0, -12.0), STEEL_ACCENT, 16)
	_add_city_label("COIN_JUMP", "COIN JUMP · SPACE / SPACE MANTENIDO = DURACIÓN DEL EMPUJE", Vector3(0.0, 1.8, 10.0), Color(0.78, 0.62, 0.32, 1.0), 15)
	_add_city_label("ROOFTOPS", "TEJADOS · PASARELAS · PUNTOS DE ANCLAJE", Vector3(0.0, 18.2, -31.0), Color(0.68, 0.71, 0.72, 1.0), 18)
	_add_city_label("RESET_HINT", "R · VOLVER A LA PLAZA", Vector3(0.0, 1.9, 6.6), Color(0.74, 0.70, 0.64, 1.0), 15)

func _add_city_label(label_name: String, text: String, position: Vector3, color: Color, font_size: int) -> void:
	var label := Label3D.new()
	label.name = label_name
	label.text = text
	label.position = position
	label.font_size = font_size
	label.modulate = color
	label.outline_size = 5
	label.outline_modulate = Color(0.015, 0.014, 0.017, 0.98)
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = false
	add_child(label)

func _city_wall_color(index: int) -> Color:
	var palette: Array[Color] = [STONE_WARM, STONE_COOL, STONE_RED, STONE_DARK]
	return palette[posmod(index, palette.size())]

func _wall_color(index: int) -> Color:
	return _city_wall_color(index)

func _add_city_visual(parent: Node3D, local_position: Vector3, size: Vector3, color: Color, metallic: float = 0.0, emissive: bool = false) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.position = local_position
	var box := BoxMesh.new()
	box.size = size
	instance.mesh = box
	instance.material_override = _city_material(color, metallic, emissive)
	parent.add_child(instance)
	return instance

func _city_material(color: Color, metallic: float = 0.0, emissive: bool = false) -> StandardMaterial3D:
	var key := "%s_%.2f_%s" % [color.to_html(true), metallic, str(emissive)]
	if _city_material_cache.has(key):
		return _city_material_cache[key] as StandardMaterial3D
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.metallic = clampf(metallic, 0.0, 1.0)
	mat.roughness = 0.78
	if emissive:
		mat.emission_enabled = true
		mat.emission = color
		mat.emission_energy_multiplier = 0.62
	_city_material_cache[key] = mat
	return mat
