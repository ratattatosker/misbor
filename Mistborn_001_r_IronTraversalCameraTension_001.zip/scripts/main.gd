extends Node3D

const InputSetup = preload("res://scripts/input_setup.gd")
const DebugOverlay = preload("res://scripts/debug_overlay.gd")
const Minimap = preload("res://scripts/minimap.gd")
const SightHighlightShader: Shader = preload("res://scripts/allomantic_sight.gdshader")
const SightLinesShader: Shader = preload("res://scripts/allomantic_sight_lines.gdshader")
const CoinPool = preload("res://scripts/coin_pool.gd")
const Reticle = preload("res://scripts/reticle.gd")

var _player: MistbornPlayerController
var _debug_overlay: CanvasLayer
var _minimap_layer: CanvasLayer
var _minimap: MistbornMinimap
var _ash_flakes: Array[MeshInstance3D] = []
var _ash_fall_speeds: Array[float] = []
var _ash_drifts: Array[float] = []
var _ash_mesh: SphereMesh
var _runtime_prewarm_started := false
var _runtime_prewarm_complete := false
var _coin_pool: MistbornCoinPool
var _coordinate_layer: CanvasLayer
var _coordinate_label: Label
var _coordinate_sample_accumulator: float = 0.0
var _reticle: MistbornReticle
var _playground_hud_layer: CanvasLayer
var _playground_status_label: Label
var _playground_hud_refresh_left: float = 0.0

@export var enable_debug_overlay: bool = false
@export var playground_mode: bool = false

func _ready() -> void:
	InputSetup.ensure_defaults()
	_player = $Player as MistbornPlayerController
	_build_environment()
	_build_coin_pool()
	_build_minimap()
	_build_coordinate_readout()
	_build_reticle()
	if playground_mode:
		_build_playground_hud()
	if enable_debug_overlay:
		_build_debug_overlay()
	call_deferred("_run_runtime_prewarm")



func _build_coin_pool() -> void:
	_coin_pool = CoinPool.new()
	_coin_pool.name = "CoinPool"
	_coin_pool.warm_pool_size = 6
	add_child(_coin_pool)

func _prewarm_runtime_assets() -> void:
	if _runtime_prewarm_started:
		return
	_runtime_prewarm_started = true

	# Shader warm-up only. Actual coin instances are pre-created by CoinPool so
	# the first player throw/jump reuses an already initialized gameplay object.
	var prewarm_viewport := SubViewport.new()
	prewarm_viewport.name = "__RuntimePrewarmViewport"
	prewarm_viewport.size = Vector2i(8, 8)
	prewarm_viewport.transparent_bg = true
	prewarm_viewport.render_target_update_mode = SubViewport.UPDATE_ONCE
	add_child(prewarm_viewport)

	var prewarm_camera := Camera3D.new()
	prewarm_camera.position = Vector3(0.0, 0.0, 2.0)
	prewarm_camera.current = true
	prewarm_viewport.add_child(prewarm_camera)

	var highlight_quad := MeshInstance3D.new()
	var highlight_mesh := QuadMesh.new()
	highlight_mesh.size = Vector2(1.0, 1.0)
	highlight_quad.mesh = highlight_mesh
	var highlight_material := ShaderMaterial.new()
	highlight_material.shader = SightHighlightShader
	highlight_material.set_shader_parameter("sight_color", Color(0.10, 0.48, 1.0, 0.72))
	highlight_quad.material_override = highlight_material
	prewarm_viewport.add_child(highlight_quad)

	var line_quad := MeshInstance3D.new()
	var line_mesh := QuadMesh.new()
	line_mesh.size = Vector2(1.0, 1.0)
	line_quad.mesh = line_mesh
	line_quad.position = Vector3(0.0, 0.0, -0.01)
	var line_material := ShaderMaterial.new()
	line_material.shader = SightLinesShader
	line_material.set_shader_parameter("sight_color", Color(0.08, 0.58, 1.0, 0.78))
	line_material.set_shader_parameter("glow_strength", 4.8)
	line_quad.material_override = line_material
	prewarm_viewport.add_child(line_quad)

	await get_tree().process_frame
	await get_tree().process_frame

	if is_instance_valid(prewarm_viewport):
		prewarm_viewport.queue_free()

func _run_runtime_prewarm() -> void:
	# Durante este tramo el jugador queda congelado solo hasta terminar el
	# calentamiento; así la primera entrada de Steel Coin Interaction nunca compite con él.
	if _player == null:
		return

	var previous_process_mode: Node.ProcessMode = _player.process_mode
	_player.process_mode = Node.PROCESS_MODE_DISABLED

	await _prewarm_runtime_assets()

	await _prewarm_steel_coin_interaction()
	_runtime_prewarm_complete = true

	_player.process_mode = previous_process_mode


func is_runtime_prewarm_complete() -> bool:
	return _runtime_prewarm_complete


func _prewarm_steel_coin_interaction() -> void:
	if _player == null:
		return
	var traversal: MistbornTraversalController = _player.get_node_or_null("Traversal") as MistbornTraversalController
	if traversal != null:
		await traversal.prewarm_steel_coin_interaction()


func _build_reticle() -> void:
	var layer := CanvasLayer.new()
	layer.name = "ReticleLayer"
	layer.layer = 25
	add_child(layer)

	_reticle = Reticle.new()
	_reticle.name = "Reticle"
	_reticle.set_anchors_preset(Control.PRESET_CENTER)
	_reticle.position = Vector2(-14.0, -14.0)
	_reticle.size = Vector2(28.0, 28.0)
	layer.add_child(_reticle)

func _build_playground_hud() -> void:
	_playground_hud_layer = CanvasLayer.new()
	_playground_hud_layer.name = "MovementLabHUDLayer"
	_playground_hud_layer.layer = 40
	add_child(_playground_hud_layer)

	var panel := PanelContainer.new()
	panel.name = "MovementLabHelpPanel"
	panel.set_anchors_preset(Control.PRESET_TOP_LEFT)
	panel.position = Vector2(18.0, 62.0)
	panel.custom_minimum_size = Vector2(360.0, 0.0)
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = Color(0.020, 0.024, 0.030, 0.91)
	panel_style.border_color = Color(0.31, 0.39, 0.45, 0.88)
	panel_style.set_border_width_all(1)
	panel_style.set_corner_radius_all(7)
	panel_style.content_margin_left = 12.0
	panel_style.content_margin_right = 12.0
	panel_style.content_margin_top = 10.0
	panel_style.content_margin_bottom = 10.0
	panel.add_theme_stylebox_override("panel", panel_style)
	_playground_hud_layer.add_child(panel)

	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation", 6)
	panel.add_child(stack)

	var heading := Label.new()
	heading.text = "MISTBORN  /  LUTHADEL · LABORATORIO DE TRAVERSAL"
	heading.add_theme_font_size_override("font_size", 15)
	heading.add_theme_color_override("font_color", Color(0.82, 0.88, 0.94, 1.0))
	stack.add_child(heading)

	var instructions := Label.new()
	instructions.name = "Controls"
	instructions.text = "WASD mover · ratón cámara · Shift correr\nSpace saltar · Space×2 Coin Jump; mantén el segundo Space para prolongar el empuje\nQ Steel: reacción física; W añade una pequeña asistencia SOLO si ya sales hacia delante\nA/D/S cambian la trayectoria mediante el movimiento del personaje, no dirigen Steel\nE Iron: atrae hacia el ancla fijada; la gravedad sigue activa pero la caída se amortigua mientras tiras de anclas pesadas\nSuelta Q/E para cortar la fuerza y conservar inercia\nCtrl visión alomántica · botón central fijar objetivo\nR volver a la plaza · Esc liberar/recapturar ratón"
	instructions.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	instructions.add_theme_font_size_override("font_size", 13)
	instructions.add_theme_color_override("font_color", Color(0.76, 0.79, 0.82, 1.0))
	stack.add_child(instructions)

	var divider := HSeparator.new()
	divider.add_theme_stylebox_override("separator", StyleBoxLine.new())
	stack.add_child(divider)

	_playground_status_label = Label.new()
	_playground_status_label.name = "LiveMovementStatus"
	_playground_status_label.text = "Preparando estado..."
	_playground_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_playground_status_label.add_theme_font_size_override("font_size", 13)
	_playground_status_label.add_theme_color_override("font_color", Color(0.66, 0.82, 0.88, 1.0))
	stack.add_child(_playground_status_label)
	_update_playground_hud()

func _update_playground_hud() -> void:
	if _playground_status_label == null or _player == null:
		return
	var horizontal_speed := Vector3(_player.velocity.x, 0.0, _player.velocity.z).length()
	var ground_state := "SUELO" if _player.is_on_floor() else "AIRE"
	var action_state := "NINGUNA"
	var target_name := ""
	var steel := _player.get_node_or_null("Steel") as MistbornSteelController
	var iron := _player.get_node_or_null("Iron") as MistbornIronController
	if steel != null and steel.is_active():
		action_state = "STEEL"
		var steel_state: Dictionary = steel.get_debug_state()
		target_name = str(steel_state.get("target_name", "NINGUNO"))
	elif iron != null and iron.is_active():
		action_state = "IRON"
		var iron_state: Dictionary = iron.get_debug_state()
		target_name = str(iron_state.get("target_name", "NINGUNO"))
	var target_line := ""
	if not target_name.is_empty():
		target_line = "\nOBJETIVO: " + target_name
	_playground_status_label.text = "ESTADO: %s  ·  V: %.1f m/s  ·  Vy: %.1f m/s\nACCIÓN: %s%s" % [ground_state, horizontal_speed, _player.velocity.y, action_state, target_line]

func _reset_playground_player() -> void:
	if _player == null or not is_instance_valid(_player):
		return
	for action in [&"move_forward", &"move_backward", &"move_left", &"move_right", &"jump", &"sprint", &"crouch", &"steel_push", &"iron_pull", &"iron_yank", &"target_lock"]:
		Input.action_release(action)
	var steel := _player.get_node_or_null("Steel") as MistbornSteelController
	var iron := _player.get_node_or_null("Iron") as MistbornIronController
	var targeting := _player.get_node_or_null("Targeting") as MistbornTargetingController
	var traversal := _player.get_node_or_null("Traversal") as MistbornTraversalController
	if steel != null:
		steel.reset_for_playground()
	if iron != null:
		iron.reset_for_playground()
	if targeting != null:
		targeting.reset_for_playground()
	if traversal != null:
		traversal.reset_for_playground()
	_player.velocity = Vector3.ZERO
	_player.global_position = Vector3(0.0, 0.015, 0.0)
	var visual := _player.get_node_or_null("Visual") as Node3D
	if visual != null:
		visual.rotation.y = 0.0
	var camera_rig := _player.get_node_or_null("CameraRig")
	if camera_rig != null and camera_rig.has_method("reset_for_playtest"):
		camera_rig.call("reset_for_playtest", 0.0, -12.0)
	if _player.has_method("cancel_iron_momentum_release"):
		_player.call("cancel_iron_momentum_release")
	_update_playground_hud()

func _build_debug_overlay() -> void:
	_debug_overlay = DebugOverlay.new()
	add_child(_debug_overlay)



func _build_coordinate_readout() -> void:
	_coordinate_layer = CanvasLayer.new()
	_coordinate_layer.name = "CoordinateReadoutLayer"
	_coordinate_layer.layer = 30
	add_child(_coordinate_layer)

	_coordinate_label = Label.new()
	_coordinate_label.name = "Coordinates"
	_coordinate_label.anchor_left = 1.0
	_coordinate_label.anchor_right = 1.0
	_coordinate_label.offset_left = -285.0
	_coordinate_label.offset_right = -18.0
	_coordinate_label.offset_top = 16.0
	_coordinate_label.offset_bottom = 48.0
	_coordinate_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_coordinate_label.add_theme_font_size_override("font_size", 17)
	_coordinate_label.add_theme_color_override("font_color", Color(0.92, 0.96, 1.0, 0.96))
	_coordinate_label.add_theme_color_override("font_outline_color", Color(0.0, 0.0, 0.0, 0.86))
	_coordinate_label.add_theme_constant_override("outline_size", 5)
	_coordinate_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_coordinate_layer.add_child(_coordinate_label)
	_update_coordinate_readout()

func _process(delta: float) -> void:
	if playground_mode:
		if Input.is_action_just_pressed("reset_playground"):
			_reset_playground_player()
		_playground_hud_refresh_left += delta
		if _playground_hud_refresh_left >= 0.12:
			_playground_hud_refresh_left = 0.0
			_update_playground_hud()
	_coordinate_sample_accumulator += delta
	if _coordinate_sample_accumulator >= 0.05:
		_coordinate_sample_accumulator = 0.0
		_update_coordinate_readout()

	for i in range(_ash_flakes.size()):
		var flake := _ash_flakes[i]
		if flake == null or not is_instance_valid(flake):
			continue
		flake.position.y -= _ash_fall_speeds[i] * delta
		flake.position.x += _ash_drifts[i] * delta
		if flake.position.y < 0.05:
			flake.position.y = 16.0

func _update_coordinate_readout() -> void:
	if _coordinate_label == null:
		return
	if _player == null:
		_coordinate_label.text = "XYZ  --"
		return
	var p: Vector3 = _player.global_position
	_coordinate_label.text = "X %8.2f   Y %8.2f   Z %8.2f" % [p.x, p.y, p.z]

func _build_minimap() -> void:
	_minimap_layer = CanvasLayer.new()
	_minimap_layer.name = "MinimapLayer"
	_minimap_layer.layer = 20
	add_child(_minimap_layer)
	_minimap = Minimap.new()
	_minimap.name = "Minimap"
	_minimap.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	_minimap.offset_left = 18.0
	_minimap.offset_top = -270.0
	_minimap.offset_right = 250.0
	_minimap.offset_bottom = -38.0
	_minimap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_minimap_layer.add_child(_minimap)

func _build_environment() -> void:
	_build_environment_lighting()
	if playground_mode:
		_build_experiment_playground()
	else:
		_build_neighborhood()
		_build_neighborhood_targets()
		_build_neighborhood_signs()

func _build_experiment_playground() -> void:
	# Laboratorio de traversal. Es deliberadamente abierto para que el jugador
	# pueda probar rangos, altura, masa, Iron/Steel y Steel Coin Interaction sin geometría urbana
	# interfiriendo con la lectura. Todas las distancias de prueba relevantes
	# respetan el radio alomántico vigente de 35 m.
	_add_box_static("PlaygroundGround", Vector3(0, -0.45, 0), Vector3(220, 0.9, 220), Color(0.060, 0.058, 0.055, 1.0))
	_add_box_static("PlaygroundNorthLane", Vector3(0, 0.01, -55), Vector3(9.0, 0.12, 110), Color(0.095, 0.090, 0.086, 1.0))
	_add_box_static("PlaygroundSouthLane", Vector3(0, 0.01, 55), Vector3(9.0, 0.12, 110), Color(0.095, 0.090, 0.086, 1.0))
	_add_box_static("PlaygroundEastLane", Vector3(55, 0.01, 0), Vector3(110, 0.12, 9.0), Color(0.095, 0.090, 0.086, 1.0))
	_add_box_static("PlaygroundWestLane", Vector3(-55, 0.01, 0), Vector3(110, 0.12, 9.0), Color(0.095, 0.090, 0.086, 1.0))

	# Referencia visual exacta del radio alomántico vigente.
	for i in range(36):
		var angle := TAU * float(i) / 36.0
		var r := 35.0
		var p := Vector3(cos(angle) * r, 0.065, sin(angle) * r)
		var marker := _add_box_static("Range35_%02d" % i, p, Vector3(1.8, 0.035, 0.16), Color(0.15, 0.26, 0.34, 0.52))
		marker.rotation.y = -angle
	_add_playground_label("RANGO ALLOMÁNTICO · 35 m", Vector3(0, 0.42, -35.7))

	# Corredor de farolas altas para Iron/Steel. Sólo la punta es targetable.
	for i in range(9):
		var z := -72.0 + i * 18.0
		_add_playground_lamp("LabLamp_W_%02d" % i, Vector3(-14.0, 0.0, z), 11.0)
		_add_playground_lamp("LabLamp_E_%02d" % i, Vector3(14.0, 0.0, z), 11.0)

	# Escalera vertical experimental: anclajes a distintas alturas, pero todos
	# dentro de una esfera de 35 m desde el centro del laboratorio.
	var heights := [4.0, 8.0, 12.0, 16.0, 20.0, 24.0, 28.0]
	for i in range(heights.size()):
		var h: float = heights[i]
		_add_target_to_world("VerticalAnchor_%02d" % i, "Anclaje vertical %02d m" % int(h), "ANCHOR", Vector3(0, h, -22.0), Vector3(1.15, 0.55, 1.15), 4.0 + i * 0.1)

	# Banco de dirección: objetivos delante, laterales y detrás para probar
	# la restricción absoluta de intención durante Steel.
	_add_target_to_world("Direction_Front", "Dirección · delante", "ANCHOR", Vector3(0, 2.5, -22.0), Vector3(1.0, 0.65, 1.0), 5.0)
	_add_target_to_world("Direction_FrontLeft", "Dirección · delante izquierda", "ANCHOR", Vector3(-13.0, 2.5, -20.0), Vector3(1.0, 0.65, 1.0), 4.8)
	_add_target_to_world("Direction_FrontRight", "Dirección · delante derecha", "ANCHOR", Vector3(13.0, 2.5, -20.0), Vector3(1.0, 0.65, 1.0), 4.8)
	_add_target_to_world("Direction_Back", "Dirección · detrás (debe descartarse)", "ANCHOR", Vector3(0, 2.5, 22.0), Vector3(1.0, 0.65, 1.0), 5.0)

	# Banco de masas: pequeño, medio y anclaje pesado.
	_add_target_to_world("MassSmall", "Masa · 8 kg", "SMALL_OBJECT", Vector3(-18.0, 1.5, 16.0), Vector3(1.0, 1.0, 1.0), 2.0)
	_add_target_to_world("MassMedium", "Masa · 25 kg", "METAL_OBJECT", Vector3(-6.0, 1.5, 16.0), Vector3(1.2, 1.2, 1.2), 2.2)
	_add_target_to_world("MassAnchor", "Masa · anclaje pesado", "ANCHOR", Vector3(8.0, 1.5, 16.0), Vector3(1.4, 1.4, 1.4), 3.0)

	# Soporte: objetivo ligero junto a una estructura pesada.
	_add_box_static("SupportWall", Vector3(22.0, 4.0, 14.0), Vector3(1.2, 8.0, 8.0), Color(0.16, 0.15, 0.14, 1.0))
	_add_target_to_world("SupportedSmall", "Masa ligera bloqueada por soporte", "SMALL_OBJECT", Vector3(20.6, 1.5, 14.0), Vector3(0.9, 0.9, 0.9), 2.4)

	# Pads a varias alturas para ensayar caída + nuevo Steel sin edificio urbano.
	for i in range(5):
		var h := 4.0 + i * 4.0
		_add_box_static("AirPad_%02d" % i, Vector3(48.0 + i * 3.0, h, -8.0), Vector3(10.0, 0.5, 10.0), Color(0.10, 0.095, 0.09, 1.0))

	_add_playground_label("DIRECCIÓN / STEEL", Vector3(0, 3.3, -15.0))
	_add_playground_label("IRON · ALTURA", Vector3(0, 30.8, -22.0))
	_add_playground_label("MASA + SOPORTE", Vector3(-4.0, 4.1, 14.0))
	_add_playground_label("STEEL COIN INTERACTION · ESPACIO ABIERTO", Vector3(0, 0.6, 48.0))

func _add_playground_label(text: String, position: Vector3) -> void:
	var label := Label3D.new()
	label.name = "LabLabel_" + text.replace(" ", "_")
	label.text = text
	label.position = position
	label.font_size = 24
	label.modulate = Color(0.62, 0.64, 0.67, 0.92)
	label.outline_size = 5
	label.outline_modulate = Color(0.02, 0.02, 0.02, 0.95)
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	add_child(label)

func _add_playground_lamp(node_name: String, ground_pos: Vector3, height: float) -> MistbornTargetable:
	var root := Node3D.new()
	root.name = node_name
	root.position = ground_pos
	add_child(root)
	_add_cylinder_visual(root, Vector3(0, height * 0.5, 0), 0.11, height, Color(0.070, 0.075, 0.080, 1.0))
	_add_box_visual(root, Vector3(0, height - 0.25, 0), Vector3(0.95, 0.28, 0.95), Color(0.11, 0.115, 0.12, 1.0))
	var tip_root := Node3D.new()
	tip_root.name = "AllomanticTip"
	tip_root.position = Vector3(0, height + 0.03, 0)
	root.add_child(tip_root)
	var tip := MeshInstance3D.new()
	var shape := CylinderMesh.new()
	shape.top_radius = 0.18
	shape.bottom_radius = 0.22
	shape.height = 0.34
	shape.radial_segments = 20
	tip.mesh = shape
	tip.material_override = _make_material(Color(0.46, 0.48, 0.51, 1.0), 0.85)
	tip_root.add_child(tip)
	var body := StaticBody3D.new()
	body.name = "PhysicalLampStructure"
	body.collision_layer = 1
	body.collision_mask = 0
	var pole_collision := CollisionShape3D.new()
	var pole_shape := CylinderShape3D.new()
	pole_shape.radius = 0.13
	pole_shape.height = height
	pole_collision.shape = pole_shape
	pole_collision.position = Vector3(0, height * 0.5, 0)
	body.add_child(pole_collision)
	var head_collision := CollisionShape3D.new()
	var head_shape := BoxShape3D.new()
	head_shape.size = Vector3(0.95, 0.28, 0.95)
	head_collision.shape = head_shape
	head_collision.position = Vector3(0, height - 0.25, 0)
	body.add_child(head_collision)
	root.add_child(body)
	var target := _add_target_to_parent(tip_root, node_name + "_tip", "Punta metálica del farol", "ANCHOR", Vector3.ZERO, Vector3(0.50, 0.34, 0.50), 3.2, false)
	target.set_meta("allomantic_physical_body", body)
	target.set_physical_body(body)
	target.standable_on = true
	return target


func _build_environment_lighting() -> void:
	var world_environment := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color(0.105, 0.034, 0.033, 1.0) if playground_mode else Color(0.038, 0.034, 0.031, 1.0)
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.44, 0.36, 0.36, 1.0) if playground_mode else Color(0.42, 0.39, 0.37, 1.0)
	environment.ambient_light_energy = 0.42
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.fog_enabled = true
	environment.fog_light_color = Color(0.205, 0.105, 0.105, 1.0) if playground_mode else Color(0.16, 0.145, 0.14, 1.0)
	environment.fog_light_energy = 0.34
	environment.fog_density = 0.009 if playground_mode else 0.007
	environment.fog_height = 2.0
	environment.fog_height_density = 0.025
	world_environment.environment = environment
	add_child(world_environment)

	var red_sun := DirectionalLight3D.new()
	red_sun.name = "RedSun"
	red_sun.rotation_degrees = Vector3(-8.0, -28.0, 0.0)
	red_sun.light_color = Color(0.82, 0.26, 0.16, 1.0)
	red_sun.light_energy = 0.22 if playground_mode else 0.16
	# El sol rojo es una contribución ambiental muy tenue en la escena nocturna.
	# Sus sombras dinámicas no aportan lectura suficiente para justificar su coste
	# en GPUs integradas.
	red_sun.shadow_enabled = false
	red_sun.directional_shadow_max_distance = 0.0
	add_child(red_sun)

	var moonlight := DirectionalLight3D.new()
	moonlight.name = "Moonlight"
	moonlight.rotation_degrees = Vector3(-52.0, 24.0, -6.0)
	moonlight.light_color = Color(0.62, 0.69, 0.82, 1.0)
	moonlight.light_energy = 0.68
	moonlight.shadow_enabled = not playground_mode
	moonlight.directional_shadow_max_distance = 70.0 if not playground_mode else 0.0
	add_child(moonlight)

	var haze_light := OmniLight3D.new()
	haze_light.name = "AshHaze"
	haze_light.position = Vector3(0, 4, 20)
	haze_light.light_color = Color(0.37, 0.31, 0.29, 1.0)
	haze_light.light_energy = 0.55
	haze_light.omni_range = 24.0
	add_child(haze_light)

func _build_neighborhood() -> void:
	# Luthadel: barrio compacto, ennegrecido por ceniza, construido alrededor de
	# una calle principal que cruza el Channerel. La escala favorece la densidad
	# de tres alturas, callejones estrechos y claros puntuales junto a edificios nobles.
	_add_box_static("Ground", Vector3(0, -0.45, 0), Vector3(120, 0.9, 300), Color(0.075, 0.072, 0.070, 1.0))
	_add_box_static("KentonStreet", Vector3(0, 0.01, 0), Vector3(10.5, 0.12, 262), Color(0.105, 0.097, 0.091, 1.0))
	_add_box_static("RiberaWest", Vector3(-17.0, 0.02, 0), Vector3(5.0, 0.12, 260), Color(0.085, 0.082, 0.080, 1.0))
	_add_box_static("RiberaEast", Vector3(17.0, 0.02, 0), Vector3(5.0, 0.12, 260), Color(0.085, 0.082, 0.080, 1.0))

	# Channerel atraviesa el barrio. Las riberas son de piedra y el puente principal
	# mantiene la lectura de ciudad en vez de convertir el río en una barrera de juego.
	_add_waterway(Vector3(0, -0.02, 22.0), Vector2(54.0, 8.5))
	_add_bridge("Southbridge", Vector3(0, 0.22, 22.0), 13.0)

	# Bloques densos e irregulares. La mayoría son tres alturas; algunos tenements
	# ascienden más, mientras que las propiedades nobles dejan claros alrededor.
	var blocks := [
		{"x": -11.8, "z": 92.0, "w": 18.5, "d": 28.0, "h": 9.2, "roof": 0},
		{"x": 11.8, "z": 92.0, "w": 18.5, "d": 28.0, "h": 10.0, "roof": 0},
		{"x": -12.8, "z": 58.0, "w": 19.5, "d": 26.0, "h": 11.0, "roof": 0},
		{"x": 12.8, "z": 58.0, "w": 19.5, "d": 26.0, "h": 13.0, "roof": 1},
		{"x": -12.0, "z": -2.0, "w": 20.0, "d": 36.0, "h": 14.0, "roof": 0},
		{"x": 12.0, "z": -5.0, "w": 20.0, "d": 30.0, "h": 10.0, "roof": 1},
		{"x": -12.5, "z": -44.0, "w": 21.0, "d": 30.0, "h": 12.0, "roof": 0},
		{"x": 12.5, "z": -45.0, "w": 20.0, "d": 31.0, "h": 15.0, "roof": 1},
		{"x": -12.8, "z": -84.0, "w": 20.0, "d": 30.0, "h": 10.0, "roof": 0},
		{"x": 12.6, "z": -84.0, "w": 20.0, "d": 28.0, "h": 11.5, "roof": 0},
		{"x": -13.0, "z": -120.0, "w": 19.0, "d": 25.0, "h": 9.5, "roof": 0},
		{"x": 13.0, "z": -120.0, "w": 19.0, "d": 25.0, "h": 10.5, "roof": 0}
	]
	# Las viviendas actuales usan el generador urbano procedural integrado en el proyecto.
	# Las librerías de assets son opcionales y no forman parte de este build.
	for i in range(blocks.size()):
		var b = blocks[i]
		_add_luthadel_building("LuthadelBlock_%02d" % i, Vector3(b.x, b.h * 0.5, b.z), Vector3(b.w, b.h, b.d), b.roof == 1, i)

	# Claustrofóbicos pasos laterales: callejas que se pierden entre edificios.
	for i in range(8):
		var z := 104.0 - i * 30.0
		_add_box_static("Alley_%02d" % i, Vector3(0, 0.02, z), Vector3(6.0, 0.12, 3.8), Color(0.075, 0.071, 0.069, 1.0))

	# Comercio y vida de barrio en los frentes; sin paneles de instrucción.
	for i in range(8):
		var z := 98.0 - i * 28.5
		_add_market_stall("MarketStall_W_%02d" % i, Vector3(-6.4, 0.7, z), i % 2 == 0)
		_add_market_stall("MarketStall_E_%02d" % i, Vector3(6.4, 0.7, z + 7.0), i % 3 == 0)

	# Iluminación pública de época: linternas metálicas sencillas, no una red de
	# farolas modernas. Se colocan de forma irregular junto a puertas, talleres y
	# cruces para evitar una repetición de pista de pruebas.
	var lamp_positions := [
		Vector3(-4.9,0,-102), Vector3(5.0,0,-73), Vector3(-5.1,0,-45),
		Vector3(5.0,0,-14), Vector3(-4.8,0,14), Vector3(4.9,0,47),
		Vector3(-5.0,0,79), Vector3(5.0,0,108)
	]
	for i in range(lamp_positions.size()):
		_add_street_lamp("LuthadelLamp_%02d" % i, lamp_positions[i])

	# Bajantes, alcantarillas, barandillas y pequeños metales: el barrio debe ofrecer
	# oportunidades de Allomancy que no sean exclusivamente traversal.
	for i in range(8):
		var z := 100.0 - i * 29.0
		_add_metal_cylinder_static("Downpipe_%02d" % i, "Bajante de hierro", Vector3(-8.9, 2.65, z), 0.065, 5.2, 1.5)
		_add_metal_cylinder_static("DownpipeE_%02d" % i, "Bajante de hierro", Vector3(8.9, 2.65, z + 8.0), 0.065, 5.2, 1.5)
	# Red de alcantarillado: las tapas siguen el trazado de las calles y los cruces,
	# con separación irregular y algunos pares cercanos a intersecciones/puentes.
	var manholes := [
		Vector3(-2.45, 0.11, 103.0),
		Vector3(2.50, 0.11, 78.0),
		Vector3(-2.55, 0.11, 51.0),
		Vector3(2.30, 0.11, 21.0),
		Vector3(-2.40, 0.11, -8.0),
		Vector3(2.55, 0.11, -36.0),
		Vector3(-2.50, 0.11, -66.0),
		Vector3(2.40, 0.11, -97.0),
		Vector3(-2.55, 0.11, -126.0),
		Vector3(-7.35, 0.11, 58.0),
		Vector3(7.30, 0.11, -51.0),
		Vector3(-7.15, 0.11, -111.0)
	]
	for i in range(manholes.size()):
		_add_metal_cylinder_static("Manhole_%02d" % i, "Tapa de alcantarilla", manholes[i], 0.95, 0.08, 1.8)

	# Distrito industrial cercano al agua: hornos, refinerías y molinos explican el olor
	# y los sonidos que deberían acompañar Luthadel.
	_add_forge("ForgeHouse", Vector3(-24.0, 2.5, 22.0), Vector3(15.0, 5.0, 18.0))
	_add_mill("ChannerelMill", Vector3(24.0, 2.8, 30.0), Vector3(13.0, 5.6, 16.0))
	_add_box_static("RefineryNorth", Vector3(-25.0, 3.0, 39.0), Vector3(11.0, 6.0, 9.0), Color(0.105,0.10,0.095,1.0))
	_add_box_static("RefinerySouth", Vector3(23.0, 3.2, 6.0), Vector3(10.0, 6.4, 9.0), Color(0.10,0.095,0.09,1.0))

	# Un claro noble rompe la densidad: residencia de Gran Casa, piedra tallada y
	# agujas, intercalada en la ciudad como describen las referencias.
	_add_great_house_keep("GreatHouseKeep", Vector3(34.0, 5.0, -48.0), Vector3(25.0, 10.0, 28.0))

	# Presencia lejana del centro imperial: Kredik Shaw debe dominar el skyline sin
	# estar pegado al jugador. Sus espiras son irregulares y de anchura variable.
	_add_kredik_shaw_silhouette(Vector3(0.0, 0.0, -165.0))

	# Muralla al extremo del barrio y una puerta con nombre de metal para anclar escala.
	_add_city_wall(Vector3(0.0, 0.0, -141.0))
	_add_city_gate("SteelGate", Vector3(0.0, 0.0, -141.2), "PUERTA DE ACERO")

	# Vida cotidiana: obreros skaa, carretas, ceniza acumulada y ruido visual de trabajo.
	for i in range(9):
		var x := -4.2 if i % 2 == 0 else 4.0
		var z := 106.0 - i * 24.0 + float((i % 3) * 1.7)
		_add_skaa_worker("SkaaWorker_%02d" % i, Vector3(x, 0.0, z), i % 2 == 0)
		_add_ash_pile("AshPile_%02d" % i, Vector3(x * 0.55, 0.13, z + 2.5), 0.75 + float(i % 3) * 0.18)
	_add_cart(Vector3(-3.4, 0.0, 48.0))
	_add_cart(Vector3(3.6, 0.0, -72.0))

	# Objetivos alománticos pequeños y variados, ahora integrados al barrio.
	_add_target_box("MetalProp_Bucket", "Cubo metálico", "SMALL_OBJECT", Vector3(-3.2, 0.38, 78.0), Vector3(0.65, 0.55, 0.65), 1.1)
	_add_target_box("MetalProp_Toolbox", "Caja de herramientas", "SMALL_OBJECT", Vector3(3.1, 0.40, 81.5), Vector3(0.85, 0.60, 0.55), 1.1)
	_add_target_box("MetalProp_Lantern", "Farol metálico", "SMALL_OBJECT", Vector3(-4.2, 1.0, 63.0), Vector3(0.42, 0.85, 0.42), 1.0)
	_add_target_box("MetalProp_Sign", "Placa metálica", "SMALL_OBJECT", Vector3(4.3, 1.35, 63.0), Vector3(0.90, 0.10, 0.52), 1.0)

	_add_metal_cylinder_static("RoofAnchor_E", "Anclaje de hierro en azotea", Vector3(12.8, 13.9, 58.0), 0.11, 1.8, 3.6)
	_add_metal_cylinder_static("RoofAnchor_W", "Anclaje de hierro en azotea", Vector3(-12.0, 14.9, -2.0), 0.11, 1.8, 3.6)

	# Ceniza visible en movimiento. La acumulación estática sigue decorando calles y repisas.
	_build_ashfall()

func _add_luthadel_building(building_name: String, center: Vector3, size: Vector3, tiled_roof: bool, variant: int) -> StaticBody3D:
	var color := Color(0.22 + float(variant % 3) * 0.012, 0.205 + float(variant % 2) * 0.010, 0.20 + float(variant % 4) * 0.008, 1.0)
	var body := _add_box_static(building_name, center, size, color)
	var floors := maxi(2, int(round(size.y / 3.0)))
	var columns := clampi(int(size.x / 2.9), 4, 7)
	for floor_i in range(floors):
		var y := 1.65 + floor_i * 2.75
		if y > size.y - 0.85:
			break
		for col in range(columns):
			var x := -size.x * 0.5 + 1.55 + col * ((size.x - 3.1) / maxf(columns - 1, 1))
			var win_color := Color(0.055, 0.052, 0.050, 1.0)
			_add_box_visual(body, Vector3(x, y - center.y, size.z * 0.5 + 0.08), Vector3(0.82, 1.15, 0.09), win_color)
			if col % 2 == (variant % 2):
				_add_box_visual(body, Vector3(x, y - center.y, -size.z * 0.5 - 0.08), Vector3(0.82, 1.15, 0.09), win_color)
	if tiled_roof:
		_add_sloped_roof(body, center.y, size, 0.42, Color(0.14, 0.135, 0.13, 1.0))
	else:
		_add_sloped_roof(body, center.y, size, 0.58, Color(0.105, 0.092, 0.086, 1.0))
	# Chimeneas, canalones y pequeños salientes hacen que los cubos de piedra parezcan casas.
	var chimney_x := -size.x * 0.28
	_add_box_visual(body, Vector3(chimney_x, size.y * 0.5 + 0.8 - center.y, 0), Vector3(0.45, 1.35, 0.45), Color(0.12,0.105,0.10,1.0))
	# El hollín se concentra en las partes altas y baja por las fachadas de forma irregular.
	var grime_color := Color(0.055, 0.052, 0.050, 1.0)
	for strip_i in range(2 + variant % 2):
		var strip_x := -size.x * 0.32 + strip_i * size.x * 0.28
		var strip_h := size.y * (0.34 + 0.06 * float((variant + strip_i) % 3))
		var strip_y := size.y * 0.50 - strip_h * 0.5 - center.y + 0.08
		_add_box_visual(body, Vector3(strip_x, strip_y, size.z * 0.5 + 0.11), Vector3(0.55 + 0.18 * strip_i, strip_h, 0.04), grime_color)
	return body

func _add_sloped_roof(parent: Node3D, center_y: float, size: Vector3, angle: float, color: Color) -> void:
	var panel_size := Vector3(size.x * 0.58, 0.16, size.z + 0.22)
	var left := _add_box_visual(parent, Vector3(-size.x * 0.23, size.y * 0.5 + 0.10 - center_y, 0), panel_size, color)
	left.rotation.z = angle
	var right := _add_box_visual(parent, Vector3(size.x * 0.23, size.y * 0.5 + 0.10 - center_y, 0), panel_size, color)
	right.rotation.z = -angle

func _add_waterway(center: Vector3, span: Vector2) -> void:
	var water := MeshInstance3D.new()
	water.name = "Channerel"
	water.position = center
	var mesh := BoxMesh.new()
	mesh.size = Vector3(span.x, 0.22, span.y)
	water.mesh = mesh
	water.material_override = _make_material(Color(0.025, 0.032, 0.036, 1.0), 0.15)
	add_child(water)
	_add_box_static("RiverBankWest", Vector3(0, 0.04, center.z - span.y * 0.5 - 0.7), Vector3(span.x, 0.28, 1.4), Color(0.17,0.16,0.15,1.0))
	_add_box_static("RiverBankEast", Vector3(0, 0.04, center.z + span.y * 0.5 + 0.7), Vector3(span.x, 0.28, 1.4), Color(0.17,0.16,0.15,1.0))

func _add_bridge(node_name: String, center: Vector3, width: float) -> void:
	var body := _add_box_static(node_name, center, Vector3(width, 0.55, 10.5), Color(0.24,0.23,0.22,1.0))
	_add_box_visual(body, Vector3(0,0.32,0), Vector3(width,0.14,10.5), Color(0.13,0.125,0.12,1.0))
	for x in PackedFloat32Array([-width*0.45, width*0.45]):
		_add_box_visual(body, Vector3(x,1.05,0), Vector3(0.10,1.15,10.3), Color(0.10,0.10,0.105,1.0))

func _add_market_stall(node_name: String, center: Vector3, cloth_tattered: bool) -> void:
	var root := Node3D.new(); root.name=node_name; root.position=center; add_child(root)
	_add_box_visual(root, Vector3(0,0,0), Vector3(3.4,0.18,2.2), Color(0.14,0.125,0.115,1.0))
	for x in PackedFloat32Array([-1.35,1.35]):
		_add_cylinder_visual(root, Vector3(x,1.2,0), 0.035, 2.4, Color(0.18,0.16,0.145,1.0))
	var cloth := Color(0.22,0.20,0.18,1.0) if cloth_tattered else Color(0.17,0.18,0.18,1.0)
	_add_box_visual(root, Vector3(0,2.12,0), Vector3(3.8,0.12,2.45), cloth)

func _add_forge(node_name: String, center: Vector3, size: Vector3) -> void:
	var root := _add_box_static(node_name, center, size, Color(0.12,0.115,0.11,1.0))
	_add_box_visual(root, Vector3(0, -size.y*0.15, size.z*0.5+0.1), Vector3(size.x*0.38, size.y*0.55, 0.12), Color(0.045,0.035,0.025,1.0))
	_add_box_visual(root, Vector3(-size.x*0.3, size.y*0.58, 0), Vector3(1.0, 3.2, 1.0), Color(0.075,0.065,0.06,1.0))
	var glow := OmniLight3D.new(); glow.position=Vector3(-size.x*0.3,0.2,size.z*0.5+0.25); glow.light_color=Color(1.0,0.38,0.08,1.0); glow.light_energy=2.0; glow.omni_range=7.0; root.add_child(glow)

func _add_mill(node_name: String, center: Vector3, size: Vector3) -> void:
	var root := _add_box_static(node_name, center, size, Color(0.19,0.16,0.135,1.0))
	_add_box_visual(root, Vector3(0, size.y*0.35, 0), Vector3(size.x+0.4,0.20,size.z+0.4), Color(0.11,0.095,0.082,1.0))
	var wheel := MeshInstance3D.new(); wheel.name="MillWheel"; wheel.position=Vector3(0,0, size.z*0.5+0.55)
	var cyl:=CylinderMesh.new(); cyl.top_radius=1.65; cyl.bottom_radius=1.65; cyl.height=0.22; cyl.radial_segments=20; wheel.mesh=cyl; wheel.rotation_degrees=Vector3(90,0,0); wheel.material_override=_make_material(Color(0.13,0.105,0.08,1.0)); root.add_child(wheel)

func _add_great_house_keep(node_name: String, center: Vector3, size: Vector3) -> void:
	var root := _add_box_static(node_name, center, size, Color(0.16,0.15,0.15,1.0))
	# Claro/courtyard visible around the keep: noble architecture is separated from tenements.
	_add_box_visual(root, Vector3(0,size.y*0.5+0.18,0), Vector3(size.x+0.8,0.22,size.z+0.8), Color(0.10,0.095,0.095,1.0))
	for x in PackedFloat32Array([-size.x*0.34,0,size.x*0.34]):
		for z in PackedFloat32Array([-size.z*0.40, size.z*0.40]):
			_add_spire(root, Vector3(x, size.y*0.5+1.2, z), 0.26 + absf(x) * 0.008, 4.2 + absf(z)*0.05)
	for side in [-1,1]:
		_add_box_visual(root, Vector3(side*size.x*0.49, 1.2, 0), Vector3(0.35,2.4,size.z*0.70), Color(0.095,0.09,0.09,1.0))

func _add_spire(parent: Node3D, local_pos: Vector3, radius: float, height: float) -> void:
	var mesh:=MeshInstance3D.new(); mesh.position=local_pos
	var cone:=CylinderMesh.new(); cone.top_radius=0.0; cone.bottom_radius=radius; cone.height=height; cone.radial_segments=8; mesh.mesh=cone; mesh.material_override=_make_material(Color(0.075,0.07,0.07,1.0),0.20); parent.add_child(mesh)

func _add_kredik_shaw_silhouette(center: Vector3) -> void:
	var root:=Node3D.new(); root.name="KredikShawSilhouette"; root.position=center; add_child(root)
	_add_box_visual(root, Vector3(0,10,0), Vector3(20,20,16), Color(0.045,0.042,0.043,1.0))
	var spires := [
		Vector3(-8,19,0),Vector3(-5,24,1),Vector3(-2,29,-1),Vector3(2,26,0),Vector3(5,32,1),Vector3(8,21,-1),Vector3(0,36,0),
		Vector3(-11,16,2),Vector3(11,17,-2)
	]
	for p in spires:
		_add_spire(root, p, 0.25 + absf(p.y)*0.006, p.y*0.95)

func _add_city_wall(center: Vector3) -> void:
	_add_box_static("CityWall", Vector3(center.x, 6.0, center.z), Vector3(86, 12, 1.6), Color(0.13,0.125,0.12,1.0))
	for x in range(-40, 41, 8):
		_add_box_visual(get_node("CityWall"), Vector3(float(x),6.5,0), Vector3(0.16,8.0,1.85), Color(0.09,0.085,0.08,1.0))

func _add_city_gate(node_name: String, center: Vector3, label: String) -> void:
	var root:=Node3D.new(); root.name=node_name; root.position=center; add_child(root)
	_add_box_visual(root, Vector3(-8,5.2,0), Vector3(8,10.4,2.2), Color(0.10,0.095,0.09,1.0))
	_add_box_visual(root, Vector3(8,5.2,0), Vector3(8,10.4,2.2), Color(0.10,0.095,0.09,1.0))
	_add_box_visual(root, Vector3(0,9.3,0), Vector3(24,2.2,2.2), Color(0.10,0.095,0.09,1.0))
	var gate:=Label3D.new(); gate.text=label; gate.position=Vector3(0,7.2,1.2); gate.font_size=28; gate.modulate=Color(0.55,0.50,0.44,0.90); gate.outline_size=5; gate.outline_modulate=Color(0.02,0.02,0.02,0.95); gate.billboard=BaseMaterial3D.BILLBOARD_ENABLED; add_child(gate)

func _add_skaa_worker(node_name: String, center: Vector3, pushing: bool) -> void:
	var root:=Node3D.new(); root.name=node_name; root.position=center; add_child(root)
	var body:=MeshInstance3D.new(); var box:=BoxMesh.new(); box.size=Vector3(0.42,1.0,0.30); body.mesh=box; body.position=Vector3(0,0.65,0); body.material_override=_make_material(Color(0.12,0.105,0.095,1.0)); root.add_child(body)
	var head:=MeshInstance3D.new(); var sphere:=SphereMesh.new(); sphere.radius=0.19; sphere.height=0.38; head.mesh=sphere; head.position=Vector3(0,1.35,0); head.material_override=_make_material(Color(0.20,0.18,0.16,1.0)); root.add_child(head)
	if pushing:
		body.rotation_degrees.z=-12.0

func _add_ash_pile(node_name: String, center: Vector3, radius: float) -> void:
	var mesh:=MeshInstance3D.new(); mesh.name=node_name; mesh.position=center
	var sphere:=SphereMesh.new(); sphere.radius=radius; sphere.height=radius*1.2; mesh.mesh=sphere; mesh.scale=Vector3(1.8,0.55,1.2); mesh.material_override=_make_material(Color(0.11,0.105,0.10,1.0)); add_child(mesh)

func _build_ashfall() -> void:
	var material:=_make_material(Color(0.48,0.46,0.44,0.52),0.0)
	var rng:=RandomNumberGenerator.new(); rng.seed=20261003
	_ash_flakes.clear()
	_ash_fall_speeds.clear()
	_ash_drifts.clear()
	_ash_mesh = SphereMesh.new()
	_ash_mesh.radius = 0.028
	_ash_mesh.height = 0.056
	for i in range(85):
		var flake:=MeshInstance3D.new(); flake.name="AshFlake_%03d"%i
		flake.mesh=_ash_mesh; flake.material_override=material
		flake.position=Vector3(rng.randf_range(-42,42),rng.randf_range(2,18),rng.randf_range(-132,112))
		add_child(flake); _ash_flakes.append(flake)
		_ash_fall_speeds.append(rng.randf_range(1.1,2.5))
		_ash_drifts.append(rng.randf_range(-0.18,0.18))

func _add_box_visual(parent: Node3D, local_position: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
	var mesh := MeshInstance3D.new()
	mesh.position = local_position
	var box := BoxMesh.new()
	box.size = size
	mesh.mesh = box
	mesh.material_override = _make_material(color)
	parent.add_child(mesh)
	return mesh

func _add_cylinder_visual(parent: Node3D, local_position: Vector3, radius: float, height: float, color: Color) -> MeshInstance3D:
	var mesh := MeshInstance3D.new()
	mesh.position = local_position
	var cylinder := CylinderMesh.new()
	cylinder.top_radius = radius
	cylinder.bottom_radius = radius
	cylinder.height = height
	mesh.mesh = cylinder
	mesh.material_override = _make_material(color, 0.55)
	parent.add_child(mesh)
	return mesh

func _add_cart(center: Vector3) -> void:
	var root := Node3D.new()
	root.name = "OldCart"
	root.position = center
	add_child(root)
	_add_box_visual(root, Vector3(0, 0.45, 0), Vector3(2.6, 0.22, 1.2), Color(0.25, 0.18, 0.12, 1.0))
	_add_box_visual(root, Vector3(0, 1.05, 0), Vector3(2.2, 0.9, 1.0), Color(0.29, 0.21, 0.15, 1.0))
	for x in PackedFloat32Array([-1.05, 1.05]):
		_add_cylinder_visual(root, Vector3(x, 0.38, 0), 0.42, 0.18, Color(0.075, 0.075, 0.08, 1.0)).rotation_degrees = Vector3(90, 0, 0)

func _add_street_lamp(node_name: String, ground_pos: Vector3) -> MistbornTargetable:
	var root := Node3D.new()
	root.name = node_name
	root.position = ground_pos
	add_child(root)
	# Tall traversal-friendly pole. The pole and lamp housing are world geometry only;
	# they are NOT themselves Allomantic targets. Only the top tip below is targetable.
	_add_cylinder_visual(root, Vector3(0, 3.8, 0), 0.095, 7.6, Color(0.075, 0.08, 0.085, 1.0))
	_add_box_visual(root, Vector3(0, 7.55, 0), Vector3(0.78, 0.24, 0.78), Color(0.12, 0.125, 0.13, 1.0))
	var tip_root := Node3D.new()
	tip_root.name = "AllomanticTip"
	tip_root.position = Vector3(0, 7.78, 0)
	root.add_child(tip_root)
	var tip_mesh := MeshInstance3D.new()
	var tip_shape := CylinderMesh.new()
	tip_shape.top_radius = 0.17
	tip_shape.bottom_radius = 0.22
	tip_shape.height = 0.30
	tip_shape.radial_segments = 20
	tip_mesh.mesh = tip_shape
	tip_mesh.material_override = _make_material(Color(0.45, 0.47, 0.50, 1.0), 0.82)
	tip_root.add_child(tip_mesh)

	var physical_body := _add_street_lamp_collision(root)
	var light := OmniLight3D.new()
	light.position = Vector3(0, 7.15, 0)
	light.omni_range = 8.5
	light.light_energy = 1.0
	root.add_child(light)

	# Only this tip owns an Allomantic Targetable. Its parent contains only the tip mesh,
	# so Allomantic Sight highlights exactly the metal tip instead of the whole lamp.
	var target := _add_target_to_parent(tip_root, node_name + "_tip", "Punta metálica del farol", "ANCHOR", Vector3.ZERO, Vector3(0.48, 0.34, 0.48), 3.0, false)
	if physical_body != null:
		target.set_meta("allomantic_physical_body", physical_body)
		target.set_physical_body(physical_body)
		target.standable_on = true
	target.mountable_on_arrival = true
	target.set_meta("mountable_on_arrival", true)
	return target

func _add_street_lamp_collision(parent: Node3D) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = "PhysicalLampStructure"
	body.collision_layer = 1
	body.collision_mask = 0
	var pole_collision := CollisionShape3D.new()
	var pole_shape := CylinderShape3D.new()
	pole_shape.radius = 0.12
	pole_shape.height = 7.6
	pole_collision.shape = pole_shape
	pole_collision.position = Vector3(0, 3.8, 0)
	body.add_child(pole_collision)
	var head_collision := CollisionShape3D.new()
	var head_shape := BoxShape3D.new()
	head_shape.size = Vector3(0.78, 0.24, 0.78)
	head_collision.shape = head_shape
	head_collision.position = Vector3(0, 7.55, 0)
	body.add_child(head_collision)
	var cap_collision := CollisionShape3D.new()
	var cap_shape := BoxShape3D.new()
	cap_shape.size = Vector3(0.48, 0.30, 0.48)
	cap_collision.shape = cap_shape
	cap_collision.position = Vector3(0, 7.78, 0)
	body.add_child(cap_collision)

	# Gameplay-only perch surface. The visual lamp remains narrow, but the top has
	# enough physical area for the player's capsule to settle reliably instead of
	# sliding off the decorative tip.
	var perch_collision := CollisionShape3D.new()
	var perch_shape := CylinderShape3D.new()
	perch_shape.radius = 0.48
	perch_shape.height = 0.12
	perch_collision.shape = perch_shape
	perch_collision.position = Vector3(0, 7.93, 0)
	body.add_child(perch_collision)
	parent.add_child(body)
	return body


func _build_neighborhood_targets() -> void:
	# El barrio no contiene monedas de prueba colocadas artificialmente.
	# Las monedas solo aparecen cuando el jugador las solicita (Steel Coin Interaction/proyectil).

	# Objetivos móviles/pequeños para variar el vector de maniobra sin cerrar la vía.
	for i in range(7):
		var z := -108.0 + i * 36.0
		_add_target_to_world("Rail_W_%02d" % i, "Barra metálica oeste", "METAL_OBJECT", Vector3(-10.8, 3.0, z), Vector3(0.22, 2.4, 0.22), 1.8)
		_add_target_to_world("Rail_E_%02d" % i, "Barra metálica este", "METAL_OBJECT", Vector3(10.8, 3.0, z), Vector3(0.22, 2.4, 0.22), 1.8)

	# Objetivos de prueba inmediatos para validar ambos sentidos desde el spawn.
	_add_target_to_world("RoofAnchor_Low", "Anclaje de hierro bajo", "ANCHOR", Vector3(-7.2, 0.65, 90.0), Vector3(0.95, 0.55, 0.95), 3.4)
	_add_target_to_world("RoofAnchor_High", "Anclaje de hierro alto", "ANCHOR", Vector3(7.2, 7.5, 90.0), Vector3(0.95, 0.55, 0.95), 3.4)
	# Steel hacia delante necesita un anclaje detrás del jugador. El targeting
	# permite este caso cuando W aporta intención hacia delante, usando la reacción
	# real del jugador en lugar de exigir que el metal esté delante de la cámara.
	_add_target_to_world("RoofAnchor_Back", "Anclaje Steel trasero", "ANCHOR", Vector3(0.0, 3.0, 126.0), Vector3(1.15, 0.70, 1.15), 3.8)
func _add_target_to_world(target_id: String, display_name: String, target_type: String, center: Vector3, size: Vector3, priority: float) -> MistbornTargetable:
	var target := _add_target_box(target_id, display_name, target_type, center, size, priority)
	return target

func _add_target_to_parent(parent: Node3D, target_id: String, display_name: String, target_type: String, local_position: Vector3, size: Vector3, priority: float, add_physical_collision: bool = true) -> MistbornTargetable:
	var target := MistbornTargetable.new()
	target.name = "Target_" + target_id
	target.target_id = target_id
	target.display_name = display_name
	target.target_type = target_type
	target.selection_priority = priority
	target.position = local_position
	target.target_size_priority = 0.90
	target.target_height_priority = 0.90
	target.target_accessibility = 0.86
	target.is_metallic = true
	target.steel_pushable = true
	target.iron_pullable = true
	target.allomantic_profile = "ANCHOR"
	target.show_in_allomantic_sight = true
	target.standable_on = true
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size * 1.15
	collision.shape = shape
	target.add_child(collision)
	if add_physical_collision:
		_add_physical_target_collision(target, shape.size)
	parent.add_child(target)
	return target

func _add_physical_target_collision(target: MistbornTargetable, size: Vector3) -> void:
	if target == null or target.target_type == "CHARACTER":
		return
	var body := StaticBody3D.new()
	body.name = "PhysicalMetalObject"
	body.collision_layer = 1
	body.collision_mask = 0
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	body.add_child(collision)
	target.add_child(body)
	target.set_physical_body(body)


func _add_target_box(target_id: String, display_name: String, target_type: String, center: Vector3, size: Vector3, priority: float) -> MistbornTargetable:
	var target := MistbornTargetable.new()
	target.name = "Target_" + target_id
	target.target_id = target_id
	target.display_name = display_name
	target.target_type = target_type
	target.selection_priority = priority
	target.position = center
	match target_type:
		"ANCHOR":
			target.target_size_priority = 0.92
			target.target_height_priority = 0.95
			target.target_accessibility = 0.82
		"COIN":
			target.target_size_priority = 0.90
			target.target_height_priority = 0.55
			target.target_accessibility = 0.98
		"METAL_OBJECT":
			target.target_size_priority = 0.72
			target.target_height_priority = 0.52
			target.target_accessibility = 0.90
		"CHARACTER":
			target.target_size_priority = 0.80
			target.target_height_priority = 0.66
			target.target_accessibility = 0.88
	var is_metal := target_type in ["ANCHOR", "COIN", "METAL_OBJECT", "SMALL_OBJECT", "CHARACTER"]
	target.is_metallic = is_metal
	match target_type:
		"ANCHOR": target.allomantic_visual_mass = 1000000.0
		"COIN": target.allomantic_visual_mass = 0.03
		"METAL_OBJECT": target.allomantic_visual_mass = 25.0
		"SMALL_OBJECT": target.allomantic_visual_mass = 8.0
		"CHARACTER": target.allomantic_visual_mass = 75.0
		_: target.allomantic_visual_mass = 150.0
	target.steel_pushable = is_metal
	target.iron_pullable = is_metal
	target.show_in_allomantic_sight = is_metal
	# A sufficiently broad physical metal object can serve as a landing surface,
	# not just as a force anchor. Narrow rails, coins and characters stay non-mountable.
	var has_stable_perch_footprint: bool = target_type not in ["COIN", "CHARACTER"] and size.x >= 0.80 and size.z >= 0.80
	target.standable_on = has_stable_perch_footprint
	target.mountable_on_arrival = has_stable_perch_footprint
	match target_type:
		"ANCHOR":
			target.allomantic_profile = "ANCHOR"
		"COIN":
			target.allomantic_profile = "PROJECTILE"
		"METAL_OBJECT", "SMALL_OBJECT":
			target.allomantic_profile = "SMALL_OBJECT"
		"CHARACTER":
			target.allomantic_profile = "CHARACTER"
		_:
			target.allomantic_profile = "DECORATIVE"

	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size * 1.18
	collision.shape = shape
	target.add_child(collision)
	_add_physical_target_collision(target, shape.size)

	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	mesh.mesh = box
	var visual_color := Color(0.40, 0.38, 0.36, 1.0) if not is_metal else Color(0.50, 0.52, 0.55, 1.0)
	mesh.material_override = _make_material(visual_color, 0.8 if is_metal else 0.0)
	target.add_child(mesh)
	add_child(target)
	return target

func _add_box_static(node_name: String, center: Vector3, size: Vector3, color: Color) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = node_name
	body.position = center

	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	body.add_child(collision)

	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	mesh.mesh = box
	mesh.material_override = _make_material(color)
	body.add_child(mesh)

	add_child(body)
	return body

func _add_metal_cylinder_static(node_name: String, display_name: String, center: Vector3, radius: float, height: float, priority: float) -> MistbornTargetable:
	var body := _add_cylinder_static(node_name, center, radius, height, Color(0.24, 0.25, 0.27, 1.0), true)
	var target := _add_target_to_parent(body, node_name + "_metal", display_name, "ANCHOR", Vector3.ZERO, Vector3(radius * 2.2, height * 1.25, radius * 2.2), priority, false)
	target.set_meta("allomantic_physical_body", body)
	target.set_physical_body(body)
	return target

func _add_cylinder_static(node_name: String, center: Vector3, radius: float, height: float, color: Color, allomantic_surface: bool = false) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = node_name
	body.position = center

	var collision := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = radius
	shape.height = height
	collision.shape = shape
	body.add_child(collision)

	var mesh := MeshInstance3D.new()
	var cylinder := CylinderMesh.new()
	cylinder.top_radius = radius
	cylinder.bottom_radius = radius
	cylinder.height = height
	mesh.mesh = cylinder
	mesh.material_override = _make_material(color, 0.78 if allomantic_surface else 0.0)
	body.add_child(mesh)
	if allomantic_surface:
		body.set_meta("allomantic_surface", true)

	add_child(body)
	return body

func _make_material(color: Color, metallic: float = 0.0) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = metallic
	material.roughness = 0.78
	return material

func _build_neighborhood_signs() -> void:
	# Solo señalización ambiental para dar identidad.
	_add_street_sign("DistrictSign", "DISTRITO DEL HOLLÍN", Vector3(-8.2, 3.15, -4.0), Vector3(0.0, 90.0, 0.0))
	_add_street_sign("AlleySign", "CALLEJÓN DEL HIERRO", Vector3(19.8, 2.8, 8.4), Vector3(0.0, 90.0, 0.0))

func _add_street_sign(node_name: String, text: String, world_position: Vector3, rotation_degrees: Vector3) -> void:
	var sign := Label3D.new()
	sign.name = node_name
	sign.text = text
	sign.position = world_position
	sign.rotation_degrees = rotation_degrees
	sign.font_size = 22
	sign.modulate = Color(0.67, 0.65, 0.58, 1.0)
	sign.outline_size = 4
	sign.outline_modulate = Color(0.03, 0.025, 0.02, 0.92)
	add_child(sign)
