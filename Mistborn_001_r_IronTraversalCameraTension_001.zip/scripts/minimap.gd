class_name MistbornMinimap
extends Control

const REFRESH_INTERVAL := 0.12
const MAP_WORLD_RADIUS := 31.0
const MAP_RADIUS_RATIO := 0.47

var _player: Node3D
var _player_visual: Node3D
var _refresh_left := 0.0
var _heading := 0.0
var _targetables_cache: Array[Node] = []

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_update_sources()
	queue_redraw()

func _process(delta: float) -> void:
	_heading = _get_player_heading()
	_refresh_left -= delta
	if _refresh_left <= 0.0:
		_refresh_left = REFRESH_INTERVAL
		_update_sources()
		queue_redraw()

func _update_sources() -> void:
	if _player == null or not is_instance_valid(_player):
		_player = get_tree().get_first_node_in_group("mistborn_player") as Node3D
	_player_visual = null
	_targetables_cache.clear()
	for node: Node in get_tree().get_nodes_in_group("mistborn_targetable"):
		if not is_instance_valid(node):
			continue
		_targetables_cache.append(node)

func _draw() -> void:
	var center := size * 0.5
	var radius := minf(size.x, size.y) * MAP_RADIUS_RATIO
	var inner_radius := radius - 3.0

	draw_circle(center + Vector2(0.0, 3.0), radius + 6.0, Color(0.0, 0.0, 0.0, 0.22), true)
	draw_circle(center, radius + 2.5, Color(0.025, 0.030, 0.034, 0.88), true)
	draw_circle(center, radius + 2.5, Color(0.72, 0.73, 0.72, 0.28), false, 1.1)
	draw_circle(center, inner_radius, Color(0.055, 0.065, 0.071, 0.42), true)
	draw_arc(center, inner_radius, 0.0, TAU, 80, Color(0.67, 0.69, 0.70, 0.13), 0.8, true)
	draw_arc(center, inner_radius * 0.54, 0.0, TAU, 64, Color(0.67, 0.69, 0.70, 0.09), 0.7, true)

	_draw_neighborhood_linework(center, inner_radius)
	if _player != null and is_instance_valid(_player):
		_draw_player_icon(center)
	_draw_heading_ticks(center, radius)

func _get_player_heading() -> float:
	if _player_visual == null or not is_instance_valid(_player_visual):
		if _player != null and is_instance_valid(_player):
			_player_visual = _player.get_node_or_null("Visual") as Node3D
	if _player_visual == null or not is_instance_valid(_player_visual):
		return 0.0
	var forward := -_player_visual.global_transform.basis.z
	forward.y = 0.0
	if forward.length_squared() < 0.001:
		return 0.0
	return atan2(forward.z, forward.x)

func _world_to_map(world_pos: Vector3, center: Vector2, radius: float) -> Vector2:
	if _player == null or not is_instance_valid(_player):
		return center
	var offset := world_pos - _player.global_position
	offset.y = 0.0
	var map_offset := Vector2(offset.x, offset.z)
	map_offset = map_offset.rotated(-PI * 0.5 - _heading)
	return center + map_offset * (radius / MAP_WORLD_RADIUS)

func _draw_neighborhood_linework(center: Vector2, radius: float) -> void:
	var scale := radius / MAP_WORLD_RADIUS
	# Red vial of street geometry: broad avenues first, then narrow side lanes.
	_draw_world_line(center, radius, Vector3(-17.0, 0.0, -MAP_WORLD_RADIUS), Vector3(-17.0, 0.0, MAP_WORLD_RADIUS), 5.2, Color(0.15, 0.17, 0.18, 0.76), scale)
	_draw_world_line(center, radius, Vector3(0.0, 0.0, -MAP_WORLD_RADIUS), Vector3(0.0, 0.0, MAP_WORLD_RADIUS), 7.2, Color(0.23, 0.22, 0.20, 0.84), scale)
	_draw_world_line(center, radius, Vector3(17.0, 0.0, -MAP_WORLD_RADIUS), Vector3(17.0, 0.0, MAP_WORLD_RADIUS), 5.2, Color(0.15, 0.17, 0.18, 0.76), scale)
	_draw_world_line(center, radius, Vector3(-MAP_WORLD_RADIUS, 0.0, 22.0), Vector3(MAP_WORLD_RADIUS, 0.0, 22.0), 5.8, Color(0.12, 0.15, 0.16, 0.72), scale)
	_draw_world_line(center, radius, Vector3(-MAP_WORLD_RADIUS, 0.0, -22.0), Vector3(MAP_WORLD_RADIUS, 0.0, -22.0), 2.6, Color(0.11, 0.13, 0.14, 0.60), scale)

	var blocks := [
		[Vector3(-11.8,0,92), Vector2(18.5,28)], [Vector3(11.8,0,92), Vector2(18.5,28)],
		[Vector3(-12.8,0,58), Vector2(19.5,26)], [Vector3(12.8,0,58), Vector2(19.5,26)],
		[Vector3(-12,0,-2), Vector2(20,36)], [Vector3(12,0,-5), Vector2(20,30)],
		[Vector3(-12.5,0,-44), Vector2(21,30)], [Vector3(12.5,0,-45), Vector2(20,31)],
		[Vector3(-12.8,0,-84), Vector2(20,30)], [Vector3(12.6,0,-84), Vector2(20,28)]
	]
	for block in blocks:
		var center_world: Vector3 = block[0]
		var size_world: Vector2 = block[1]
		_draw_world_block(center, radius, center_world, size_world, Color(0.28, 0.28, 0.28, 0.60), scale)

func _draw_world_line(center: Vector2, radius: float, a_world: Vector3, b_world: Vector3, width: float, color: Color, _map_scale: float) -> void:
	var a := _world_to_map(a_world, center, radius)
	var b := _world_to_map(b_world, center, radius)
	if a.distance_to(center) > radius + width and b.distance_to(center) > radius + width:
		return
	var a_inside := a.distance_to(center) <= radius
	var b_inside := b.distance_to(center) <= radius
	if not a_inside and not b_inside:
		return
	_draw_clipped_segment(a, b, center, radius, color, width)

func _draw_world_block(center: Vector2, radius: float, world_center: Vector3, size_world: Vector2, color: Color, _map_scale: float) -> void:
	var half := Vector3(size_world.x * 0.5, 0.0, size_world.y * 0.5)
	var points := [
		_world_to_map(world_center + Vector3(-half.x, 0.0, -half.z), center, radius),
		_world_to_map(world_center + Vector3(half.x, 0.0, -half.z), center, radius),
		_world_to_map(world_center + Vector3(half.x, 0.0, half.z), center, radius),
		_world_to_map(world_center + Vector3(-half.x, 0.0, half.z), center, radius)
	]
	for i in range(4):
		var a: Vector2 = points[i]
		var b: Vector2 = points[(i + 1) % 4]
		_draw_clipped_segment(a, b, center, radius, color, 1.0)

func _draw_clipped_segment(a: Vector2, b: Vector2, center: Vector2, radius: float, color: Color, width: float) -> void:
	var points := _clip_segment_to_circle(a, b, center, radius)
	for i in range(0, points.size(), 2):
		if i + 1 < points.size():
			draw_line(points[i], points[i + 1], color, width, true)

func _clip_segment_to_circle(a: Vector2, b: Vector2, center: Vector2, radius: float) -> PackedVector2Array:
	var p0: Vector2 = a - center
	var p1: Vector2 = b - center
	var d: Vector2 = p1 - p0
	var a_coef: float = d.dot(d)
	if a_coef <= 0.000001:
		return PackedVector2Array([a, b]) if p0.length_squared() <= radius * radius else PackedVector2Array()
	var inside_a: bool = p0.length_squared() <= radius * radius
	var inside_b: bool = p1.length_squared() <= radius * radius
	if inside_a and inside_b:
		return PackedVector2Array([a, b])

	var b_coef: float = 2.0 * p0.dot(d)
	var c_coef: float = p0.dot(p0) - radius * radius
	var discriminant: float = b_coef * b_coef - 4.0 * a_coef * c_coef
	if discriminant < 0.0:
		return PackedVector2Array()

	var root: float = sqrt(maxf(discriminant, 0.0))
	var t0: float = (-b_coef - root) / (2.0 * a_coef)
	var t1: float = (-b_coef + root) / (2.0 * a_coef)
	var entry: float = clampf(minf(t0, t1), 0.0, 1.0)
	var exit: float = clampf(maxf(t0, t1), 0.0, 1.0)

	if inside_a:
		return PackedVector2Array([a, b.lerp(a, 1.0 - exit)])
	if inside_b:
		return PackedVector2Array([a.lerp(b, entry), b])
	if entry > exit or (exit - entry) <= 0.000001:
		return PackedVector2Array()
	return PackedVector2Array([a.lerp(b, entry), a.lerp(b, exit)])

func _draw_player_icon(center: Vector2) -> void:
	_draw_triangle(center, Vector2.UP, 8.8, Color(0.93, 0.95, 0.94, 1.0))
	draw_circle(center, 2.0, Color(0.04, 0.05, 0.055, 0.70), true)

func _draw_heading_ticks(center: Vector2, radius: float) -> void:
	for i in range(8):
		var a := -PI * 0.5 + float(i) * TAU / 8.0
		var inner := center + Vector2(cos(a), sin(a)) * (radius - 8.0)
		var outer := center + Vector2(cos(a), sin(a)) * (radius - 4.0)
		draw_line(inner, outer, Color(0.80, 0.81, 0.78, 0.20), 0.8, true)

func _draw_triangle(center: Vector2, direction: Vector2, radius: float, color: Color) -> void:
	var dir := direction.normalized() if direction.length_squared() > 0.001 else Vector2.UP
	var side := Vector2(-dir.y, dir.x)
	var points := PackedVector2Array([
		center + dir * radius,
		center - dir * radius * 0.70 + side * radius * 0.60,
		center - dir * radius * 0.70 - side * radius * 0.60
	])
	draw_colored_polygon(points, color)
