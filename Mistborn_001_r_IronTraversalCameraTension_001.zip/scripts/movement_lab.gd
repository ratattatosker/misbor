extends "res://scripts/main.gd"

# Dedicated movement lab. Geometry uses simple materials and primitive meshes to stay
# light on Intel integrated graphics; each course zone tests one specific movement decision.

const FLOOR_DARK := Color(0.052, 0.056, 0.061, 1.0)
const INK := Color(0.085, 0.091, 0.098, 1.0)
const METAL := Color(0.35, 0.39, 0.43, 1.0)
const IRON_ACCENT := Color(0.20, 0.42, 0.47, 1.0)
const STEEL_ACCENT := Color(0.53, 0.21, 0.16, 1.0)
const JUMP_ACCENT := Color(0.68, 0.55, 0.25, 1.0)
const COIN_ACCENT := Color(0.64, 0.48, 0.18, 1.0)

func _build_experiment_playground() -> void:
	# Large, unobstructed base: no urban clutter, no hidden traversal blockers.
	_add_box_static("MovementLabGround", Vector3(0.0, -0.45, 0.0), Vector3(132.0, 0.9, 132.0), FLOOR_DARK)
	_add_box_static("MovementLabNorthBoundary", Vector3(0.0, 2.0, -66.0), Vector3(132.0, 4.0, 0.8), INK)
	_add_box_static("MovementLabSouthBoundary", Vector3(0.0, 2.0, 66.0), Vector3(132.0, 4.0, 0.8), INK)
	_add_box_static("MovementLabEastBoundary", Vector3(66.0, 2.0, 0.0), Vector3(0.8, 4.0, 132.0), INK)
	_add_box_static("MovementLabWestBoundary", Vector3(-66.0, 2.0, 0.0), Vector3(0.8, 4.0, 132.0), INK)

	_build_spawn_pad()
	_build_jump_course()
	_build_iron_flow_course()
	_build_steel_burst_course()
	_build_coin_jump_station()
	_build_drop_recovery_station()
	_build_movable_mass_station()
	_build_range_markers()

func _build_spawn_pad() -> void:
	# A ground-only visual compass, so the player can always return to a clear reference.
	_add_box_visual(self, Vector3(0.0, 0.018, 0.0), Vector3(7.6, 0.025, 7.6), Color(0.105, 0.115, 0.125, 1.0))
	_add_box_visual(self, Vector3(0.0, 0.037, -3.6), Vector3(7.2, 0.018, 0.06), IRON_ACCENT)
	_add_box_visual(self, Vector3(0.0, 0.037, 3.6), Vector3(7.2, 0.018, 0.06), STEEL_ACCENT)
	_add_box_visual(self, Vector3(-3.6, 0.037, 0.0), Vector3(0.06, 0.018, 7.2), STEEL_ACCENT)
	_add_box_visual(self, Vector3(3.6, 0.037, 0.0), Vector3(0.06, 0.018, 7.2), IRON_ACCENT)
	_add_lab_label("INICIO · R REINICIA", Vector3(0.0, 2.8, 4.2), Color(0.84, 0.86, 0.89, 1.0), 28)

func _build_jump_course() -> void:
	_add_box_visual(self, Vector3(0.0, 0.018, -16.0), Vector3(5.6, 0.02, 32.0), Color(0.10, 0.105, 0.105, 1.0))
	_add_lab_label("SALTO · CAÍDA · ATERRIZAJE", Vector3(0.0, 4.1, -12.0), JUMP_ACCENT, 26)
	var tops: Array[float] = [0.42, 0.75, 1.08, 1.41]
	var zs: Array[float] = [-6.0, -11.8, -17.6, -23.4]
	var xs: Array[float] = [0.0, 1.0, -0.9, 0.55]
	for i in range(tops.size()):
		var top: float = tops[i]
		var x: float = xs[i]
		var z: float = zs[i]
		var height: float = top
		var block := _add_box_static("JumpStep_%02d" % (i + 1), Vector3(x, height * 0.5, z), Vector3(3.2, height, 3.0), Color(0.17 + float(i) * 0.012, 0.15 + float(i) * 0.008, 0.12 + float(i) * 0.006, 1.0))
		_add_box_visual(block, Vector3(0.0, height * 0.5 + 0.022, 0.0), Vector3(3.0, 0.035, 2.8), JUMP_ACCENT)
		_add_lab_label("SALTO %02d" % (i + 1), Vector3(x, top + 0.55, z), JUMP_ACCENT, 18)
	# A low wall is a clean test of jump timing without requiring Allomancy.
	_add_box_static("JumpTimingBarrier", Vector3(0.0, 0.32, -29.6), Vector3(3.6, 0.64, 0.45), Color(0.23, 0.18, 0.13, 1.0))
	_add_box_visual(self, Vector3(0.0, 0.655, -29.6), Vector3(3.4, 0.025, 0.48), JUMP_ACCENT)
	_add_lab_label("BARRERA BAJA", Vector3(0.0, 1.8, -29.6), JUMP_ACCENT, 18)

func _build_iron_flow_course() -> void:
	_add_box_visual(self, Vector3(14.0, 0.018, -22.0), Vector3(2.8, 0.02, 45.0), Color(0.07, 0.105, 0.11, 1.0))
	_add_lab_label("IRON · ATRAE / ARQUEA / SUELTA", Vector3(14.0, 11.5, -14.0), IRON_ACCENT, 25)
	var anchors: Array[Vector3] = [
		Vector3(9.0, 4.15, -6.0),
		Vector3(14.0, 6.15, -13.5),
		Vector3(18.0, 8.15, -21.5),
		Vector3(14.0, 6.15, -29.5),
		Vector3(8.5, 4.15, -37.0)
	]
	for i in range(anchors.size()):
		_add_lab_pylon_anchor("IronAnchor_%02d" % (i + 1), "IRON %02d · ANCLA" % (i + 1), anchors[i], IRON_ACCENT)
		if i < anchors.size() - 1:
			_add_lane_segment(anchors[i], anchors[i + 1], 0.12, IRON_ACCENT)
	_add_lab_label("E + WASD EN AIRE\nSUELTA ANTES DEL ANCLA", Vector3(18.0, 3.0, -5.0), IRON_ACCENT, 16)

func _build_steel_burst_course() -> void:
	_add_box_visual(self, Vector3(-18.0, 0.018, -25.0), Vector3(4.2, 0.02, 49.0), Color(0.105, 0.072, 0.066, 1.0))
	_add_lab_label("STEEL · IMPULSO / DIRECCIÓN", Vector3(-18.0, 7.2, -17.0), STEEL_ACCENT, 25)
	var station_zs: Array[float] = [-7.0, -19.0, -31.0, -43.0]
	for i in range(station_zs.size()):
		var z: float = station_zs[i]
		var pad := _add_box_static("SteelLaunchPad_%02d" % (i + 1), Vector3(-18.0, 0.14, z), Vector3(4.8, 0.28, 4.8), Color(0.15, 0.11, 0.10, 1.0))
		_add_box_visual(pad, Vector3(0.0, 0.155, 0.0), Vector3(4.45, 0.03, 4.45), STEEL_ACCENT)
		# Target is behind the pad for a forward reaction along -Z. The controller still
		# decides whether it is valid; this geometry merely makes that relationship legible.
		var target_z := z + 5.5
		_add_lab_pylon_anchor("SteelAnchor_%02d" % (i + 1), "STEEL %02d · ANCLA TRASERA" % (i + 1), Vector3(-18.0, 2.15, target_z), STEEL_ACCENT)
		_add_box_visual(self, Vector3(-18.0, 0.035, z - 1.65), Vector3(0.09, 0.02, 1.1), Color(0.85, 0.36, 0.22, 1.0))
		_add_lab_label("S + Q  /  SOLTAR", Vector3(-22.3, 1.65, z), STEEL_ACCENT, 15)
	_add_lab_label("EL EMPUJE DEL METAL\nVA EN SENTIDO OPUESTO", Vector3(-18.0, 3.8, -2.0), STEEL_ACCENT, 17)

func _build_coin_jump_station() -> void:
	_add_box_visual(self, Vector3(18.5, 0.018, 15.5), Vector3(13.0, 0.02, 13.0), Color(0.105, 0.087, 0.052, 1.0))
	_add_box_visual(self, Vector3(18.5, 0.038, 15.5), Vector3(7.5, 0.018, 7.5), COIN_ACCENT)
	_add_box_visual(self, Vector3(18.5, 0.051, 15.5), Vector3(6.8, 0.018, 6.8), Color(0.06, 0.058, 0.052, 1.0))
	_add_lab_label("COIN JUMP", Vector3(18.5, 4.0, 13.0), COIN_ACCENT, 27)
	_add_lab_label("SPACE · SALTO\nSPACE OTRA VEZ · STEELPUSH AL SUELO", Vector3(18.5, 2.1, 18.0), COIN_ACCENT, 17)

func _build_drop_recovery_station() -> void:
	_add_lab_label("ALTURA · RECUPERACIÓN", Vector3(28.0, 10.0, -15.0), IRON_ACCENT, 22)
	_add_box_static("RecoveryTowerDeck", Vector3(28.0, 4.0, -17.0), Vector3(8.0, 0.5, 8.0), Color(0.13, 0.14, 0.15, 1.0))
	_add_box_visual(self, Vector3(28.0, 4.27, -17.0), Vector3(7.6, 0.04, 7.6), IRON_ACCENT)
	_add_lab_pylon_anchor("RecoveryAnchor", "IRON · RECUPERACIÓN", Vector3(28.0, 6.55, -17.0), IRON_ACCENT, true)
	# Cheap access steps let the player reach the deck normally, then test drop/landing.
	for i in range(3):
		var step_height := 0.9 + float(i) * 1.05
		var step_z := -11.2 - float(i) * 1.7
		_add_box_static("RecoveryStair_%02d" % i, Vector3(28.0, step_height * 0.5, step_z), Vector3(3.2, step_height, 1.7), Color(0.12, 0.125, 0.13, 1.0))

func _build_movable_mass_station() -> void:
	_add_box_visual(self, Vector3(27.0, 0.018, 15.0), Vector3(10.0, 0.02, 10.0), Color(0.075, 0.09, 0.095, 1.0))
	_add_lab_label("MASA · OBJETOS MÓVILES", Vector3(27.0, 5.0, 11.0), Color(0.66, 0.76, 0.80, 1.0), 21)
	_add_rigid_metal_lab_target("MassTest_8kg", "CHATARRA · 8 kg", Vector3(24.0, 0.85, 15.0), Vector3(1.3, 1.7, 1.3), 8.0, Color(0.40, 0.43, 0.44, 1.0))
	_add_rigid_metal_lab_target("MassTest_25kg", "PLACA · 25 kg", Vector3(29.0, 0.70, 15.0), Vector3(1.4, 1.4, 1.4), 25.0, Color(0.37, 0.40, 0.42, 1.0))
	_add_box_static("MassTestHeavyBlock", Vector3(34.0, 1.2, 15.0), Vector3(2.5, 2.4, 2.5), Color(0.18, 0.19, 0.20, 1.0))
	_add_lab_label("Q / E SOBRE OBJETOS\nMIRA LA RESPUESTA DE MASA", Vector3(28.0, 3.1, 20.0), Color(0.66, 0.76, 0.80, 1.0), 15)

func _build_range_markers() -> void:
	# One outer 35 m ring, with fewer cheap mesh markers than the previous playground.
	for i in range(24):
		var angle := TAU * float(i) / 24.0
		var radius := 35.0
		var marker_position := Vector3(cos(angle) * radius, 0.035, sin(angle) * radius)
		var marker := _add_box_visual(self, marker_position, Vector3(1.25, 0.025, 0.12), Color(0.16, 0.29, 0.34, 0.72))
		marker.rotation.y = -angle
	_add_lab_label("RADIO ALLOMÁNTICO · 35 m", Vector3(0.0, 0.42, -35.5), Color(0.44, 0.62, 0.67, 1.0), 18)

func _add_lab_pylon_anchor(target_id: String, display_name: String, target_position: Vector3, accent: Color, allow_landing: bool = false) -> MistbornTargetable:
	var target_y := target_position.y
	var pole_height := maxf(target_y - 0.35, 1.2)
	var base_y := 0.22
	_add_box_static(target_id + "_Base", Vector3(target_position.x, base_y, target_position.z), Vector3(1.55, 0.44, 1.55), Color(0.11, 0.115, 0.12, 1.0))
	_add_cylinder_static(target_id + "_Pylon", Vector3(target_position.x, pole_height * 0.5, target_position.z), 0.16, pole_height, METAL, true)
	_add_cylinder_visual(self, Vector3(target_position.x, target_y - 0.37, target_position.z), 0.58, 0.12, accent)
	var target := _add_target_to_world(target_id, display_name, "ANCHOR", target_position, Vector3(1.25, 0.60, 1.25), 3.6)
	target.standable_on = allow_landing
	target.mountable_on_arrival = allow_landing
	target.set_meta("mountable_on_arrival", allow_landing)
	return target

func _add_rigid_metal_lab_target(target_id: String, display_name: String, center: Vector3, size: Vector3, mass_kg: float, color: Color) -> MistbornTargetable:
	var body := RigidBody3D.new()
	body.name = target_id + "_Body"
	body.position = center
	body.mass = mass_kg
	body.collision_layer = 1
	body.collision_mask = 1
	body.linear_damp = 0.15
	body.angular_damp = 0.35
	body.continuous_cd = true
	var physical_collision := CollisionShape3D.new()
	var physical_shape := BoxShape3D.new()
	physical_shape.size = size
	physical_collision.shape = physical_shape
	body.add_child(physical_collision)
	_add_box_visual(body, Vector3.ZERO, size, color)
	add_child(body)

	var target := MistbornTargetable.new()
	target.name = "Target_" + target_id
	target.target_id = target_id
	target.display_name = display_name
	target.target_type = "SMALL_OBJECT"
	target.position = Vector3.ZERO
	target.selection_priority = 2.5
	target.target_size_priority = 0.72
	target.target_height_priority = 0.52
	target.target_accessibility = 0.9
	target.is_metallic = true
	target.steel_pushable = true
	target.iron_pullable = true
	target.show_in_allomantic_sight = true
	target.allomantic_profile = "SMALL_OBJECT"
	target.allomantic_visual_mass = mass_kg
	var target_collision := CollisionShape3D.new()
	var target_shape := BoxShape3D.new()
	target_shape.size = size * 1.35
	target_collision.shape = target_shape
	target.add_child(target_collision)
	body.add_child(target)
	target.set_physical_body(body)
	return target

func _add_lane_segment(a: Vector3, b: Vector3, width: float, color: Color) -> void:
	var midpoint := (a + b) * 0.5
	var direction := b - a
	var length := Vector2(direction.x, direction.z).length()
	var mesh := _add_box_visual(self, Vector3(midpoint.x, 0.026, midpoint.z), Vector3(width, 0.02, length), color)
	mesh.rotation.y = atan2(direction.x, direction.z)

func _add_lab_label(text: String, world_position: Vector3, color: Color, font_size: int = 22) -> void:
	var label := Label3D.new()
	label.name = "LabSign_" + str(get_child_count())
	label.text = text
	label.position = world_position
	label.font_size = font_size
	label.modulate = color
	label.outline_size = 5
	label.outline_modulate = Color(0.015, 0.018, 0.022, 0.96)
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = false
	add_child(label)
