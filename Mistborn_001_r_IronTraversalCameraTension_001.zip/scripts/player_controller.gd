class_name MistbornPlayerController
extends CharacterBody3D

const FORCE_MODEL = preload("res://scripts/allomantic_force_model.gd")

signal movement_state_changed(state: String)
@export_category("Ground Movement")
@export var walk_speed: float = 4.6
@export var sprint_speed: float = 7.4
@export var crouch_speed: float = 2.5
@export var ground_acceleration: float = 18.0
@export var ground_deceleration: float = 23.0
@export var sprint_acceleration: float = 15.0
@export var air_acceleration: float = 8.0
@export var air_coasting_deceleration: float = 0.75
@export var air_direction_change: float = 12.0
@export var turn_speed: float = 14.0
@export var facing_velocity_threshold: float = 0.35

@export_category("Jump / Gravity")
@export var jump_velocity: float = 5.75
@export var gravity: float = 14.0
@export var gameplay_mass: float = 75.0
@export var allomantic_air_turn_rate: float = 7.0
@export var coyote_time: float = 0.16
@export var jump_buffer_time: float = 0.16
@export var steel_coin_double_tap_window: float = 0.42
@export_category("Iron Air Feel")
@export_range(0.40, 1.00, 0.01) var iron_anchor_gravity_scale: float = 0.72
@export_range(4.0, 28.0, 0.5) var iron_anchor_max_fall_speed: float = 18.0

@export_category("Crouch")
@export var crouch_toggle: bool = false
@export var standing_height: float = 1.86
@export var crouching_height: float = 1.1
@export var capsule_radius: float = 0.31

var _camera_rig: Node3D
var _targeting: MistbornTargetingController
var _steel: MistbornSteelController
var _iron: MistbornIronController
var _traversal: MistbornTraversalController
var _collision_shape: CollisionShape3D
var _visual: Node3D

var _allomantic_action_active := false

var _jump_buffer_left: float = 0.0
var _jump_buffer_just_set_this_tick: bool = false
var _steel_coin_followup_window_left: float = 0.0
var _coyote_left: float = 0.0
var _is_crouching: bool = false
var _was_on_floor: bool = false
var _last_horizontal_speed: float = 0.0
var _last_move_input: Vector2 = Vector2.ZERO
var _iron_momentum_release_left: float = 0.0
var _iron_release_horizontal_velocity: Vector3 = Vector3.ZERO
var _allomancy_input_owner: StringName = &""

func _ready() -> void:
	add_to_group("mistborn_player")
	_camera_rig = $CameraRig
	_targeting = get_node_or_null("Targeting") as MistbornTargetingController
	_steel = get_node_or_null("Steel") as MistbornSteelController
	_iron = get_node_or_null("Iron") as MistbornIronController
	_traversal = get_node_or_null("Traversal") as MistbornTraversalController
	_collision_shape = $CollisionShape3D
	_visual = $Visual

	up_direction = Vector3.UP
	floor_max_angle = deg_to_rad(50.0)
	floor_snap_length = 0.35
	floor_stop_on_slope = true

	_setup_visual_material()
	_set_crouching(false, true)
	_connect_visual_animation()

func _physics_process(delta: float) -> void:
	_jump_buffer_just_set_this_tick = false
	_update_timers(delta)
	_update_ground_state(delta)
	_update_crouch()

	_update_jump()
	_update_allomancy_input_owner()
	_allomantic_action_active = false
	_update_horizontal_movement(delta)
	_update_rotation(delta)

	# Allomancy is evaluated after base movement intent. This keeps the player core
	# responsible for ordinary locomotion while allowing traversal to layer on top.
	if _traversal != null:
		_traversal.physics_step(delta)
	if _steel != null:
		_steel.physics_step(delta)
	if _iron != null:
		_iron.physics_step(delta)

	_apply_vertical_gravity(delta)
	move_and_slide()
	_consume_landing_buffered_jump()
	# Decrement after move_and_slide() rather than before it. If this tick makes
	# floor contact, the still-valid buffer is consumed before its time can expire.
	# A buffer created by this tick's input starts at its full configured duration.
	if _jump_buffer_left > 0.0 and not _jump_buffer_just_set_this_tick:
		_jump_buffer_left = maxf(_jump_buffer_left - delta, 0.0)
	_update_post_move_state()

func _update_timers(delta: float) -> void:
	_coyote_left = maxf(_coyote_left - delta, 0.0)
	_steel_coin_followup_window_left = maxf(_steel_coin_followup_window_left - delta, 0.0)
	_iron_momentum_release_left = maxf(_iron_momentum_release_left - delta, 0.0)

func _consume_landing_buffered_jump() -> void:
	# Run after move_and_slide(): this is the first reliable point at which the
	# controller knows that this physics step actually made floor contact.
	if not is_on_floor() or _jump_buffer_left <= 0.0:
		return
	if _is_crouching:
		_set_crouching(false)
	velocity.y = jump_velocity
	_jump_buffer_left = 0.0
	_coyote_left = 0.0

func _update_ground_state(_delta: float) -> void:
	var on_floor_now := is_on_floor()
	if on_floor_now:
		_coyote_left = coyote_time
		# A tiny downward contact bias keeps the capsule planted without changing
		# the perceived jump height.
		if velocity.y < 0.0:
			velocity.y = -0.5
	else:
		if _was_on_floor:
			_coyote_left = coyote_time

func _apply_vertical_gravity(delta: float) -> void:
	if is_on_floor():
		return
	if _iron != null and _iron.should_assist_airborne_traversal_gravity():
		# Iron has a localized traversal gravity profile. Steel does not change
		# gravity to fake a catch: its real allomantic force must counter the fall.
		velocity.y -= gravity * iron_anchor_gravity_scale * delta
		if velocity.y < -iron_anchor_max_fall_speed:
			velocity.y = -iron_anchor_max_fall_speed
		return
	velocity.y -= gravity * delta

func _update_allomancy_input_owner() -> void:
	# The most recently pressed primary action owns the allomancy controls for this
	# hold. This lets Steel take over from Iron or vice versa without requiring both
	# buttons to be released, while preventing the older held input from reactivating
	# silently after the new action ends.
	if Input.is_action_just_pressed("steel_push"):
		_allomancy_input_owner = &"steel"
	elif Input.is_action_just_pressed("iron_pull"):
		_allomancy_input_owner = &"iron"

	if _allomancy_input_owner == &"steel" and not Input.is_action_pressed("steel_push"):
		_allomancy_input_owner = StringName("")
	elif _allomancy_input_owner == &"iron" and not Input.is_action_pressed("iron_pull"):
		_allomancy_input_owner = StringName("")

func owns_allomancy_input(action_name: StringName) -> bool:
	return _allomancy_input_owner == action_name

func get_allomancy_input_owner() -> StringName:
	return _allomancy_input_owner

func get_gameplay_mass() -> float:
	return maxf(gameplay_mass, 0.001)

func begin_iron_momentum_release(lock_time: float) -> void:
	# Snapshot momentum at release. No velocity is created, removed, or redirected here.
	# The short lock only protects the carried vector from the ordinary air-control pass.
	_iron_release_horizontal_velocity = Vector3(velocity.x, 0.0, velocity.z)
	_iron_momentum_release_left = maxf(lock_time, 0.0)

func is_iron_momentum_release_active() -> bool:
	return _iron_momentum_release_left > 0.0

func cancel_iron_momentum_release() -> void:
	_iron_momentum_release_left = 0.0
	_iron_release_horizontal_velocity = Vector3.ZERO

func apply_allomantic_force(direction: Vector3, force_newtons: float, delta: float) -> bool:
	if delta <= 0.0 or force_newtons <= 0.0:
		return false
	var dir := direction
	if dir.length_squared() <= 0.000001:
		return false
	dir = dir.normalized()
	var acceleration := (force_newtons / maxf(gameplay_mass, 1.0))
	# No automatic trajectory stabilization: the new allomantic force is layered
	# directly onto the velocity that the player already has. Existing momentum is
	# preserved; only the requested Steel/Iron force changes the trajectory.
	velocity += dir * acceleration * delta
	_allomantic_action_active = true
	# Soft traversal ceiling: it only prevents runaway numeric energy. It does not
	# prescribe a direction or a destination, so the player still owns the vector.
	var speed := velocity.length()
	if speed > FORCE_MODEL.MAX_TRAVERSAL_SPEED:
		velocity = velocity.normalized() * FORCE_MODEL.MAX_TRAVERSAL_SPEED
	return true

func _is_running_with_sprint() -> bool:
	return Input.is_action_pressed("sprint") and _last_move_input.length_squared() > 0.01 and not _is_crouching

func get_last_move_input() -> Vector2:
	return _last_move_input

func is_sprinting() -> bool:
	return _is_running_with_sprint()

func is_steel_coin_followup_window_active() -> bool:
	return _steel_coin_followup_window_left > 0.0

func _update_jump() -> void:
	if Input.is_action_just_pressed("jump"):
		# Space + Space is a special Steel interaction. The first press performs the
		# ordinary jump; the second press during the follow-up window asks Steel to
		# create a coin and immediately Steelpush it straight down. It is a one-shot
		# interaction, not a separate movement mode and never requires Q.
		if _steel_coin_followup_window_left > 0.0:
			_steel_coin_followup_window_left = 0.0
			if _steel != null and _steel.try_special_coin_interaction():
				_jump_buffer_left = 0.0
			return

		_steel_coin_followup_window_left = steel_coin_double_tap_window
		_jump_buffer_left = jump_buffer_time
		_jump_buffer_just_set_this_tick = true

	# Forgiving input: a jump pressed just before landing is consumed on the
	# first grounded frame, without increasing jump height or changing gravity.
	if _jump_buffer_left > 0.0 and _coyote_left > 0.0:
		_perform_normal_jump()

func _perform_normal_jump() -> void:
	if _coyote_left <= 0.0:
		return
	if _is_crouching:
		_set_crouching(false)
	velocity.y = jump_velocity
	_jump_buffer_left = 0.0
	_coyote_left = 0.0


func _update_horizontal_movement(delta: float) -> void:
	var input_vec := Input.get_vector("move_left", "move_right", "move_forward", "move_backward")
	_last_move_input = input_vec

	var speed := walk_speed
	var sprinting := Input.is_action_pressed("sprint") and input_vec.length_squared() > 0.01 and not _is_crouching
	if _is_crouching:
		speed = crouch_speed
	elif sprinting:
		speed = sprint_speed

	var local_dir := Vector3(input_vec.x, 0.0, input_vec.y)
	var yaw := _camera_rig.rotation.y if _camera_rig != null else rotation.y
	var world_dir := Basis(Vector3.UP, yaw) * local_dir
	if world_dir.length_squared() > 1.0:
		world_dir = world_dir.normalized()

	var has_ground_intent := world_dir.length_squared() > 0.0001
	if has_ground_intent:
		world_dir = world_dir.normalized()

	var target_speed := speed * minf(input_vec.length(), 1.0)
	var target := world_dir * target_speed
	var horizontal := Vector3(velocity.x, 0.0, velocity.z)
	var on_floor := is_on_floor()
	var allomantic_traversal: bool = is_allomancy_input_active()
	var iron_propulsion_active := _iron != null and _iron.is_traversal_active()
	var iron_propulsion_input := Input.is_action_pressed("iron_pull") and owns_allomancy_input(&"iron") and _player_is_allomancy_input_active_for_movement()

	if iron_propulsion_active or iron_propulsion_input:
		# IronController owns the small, input-driven tangent-plane correction while
		# pulling. Keeping this branch free of velocity reorientation preserves the
		# momentum produced by the shared radial pull and lets the player trace an arc.
		# Gravity is still applied later in _apply_vertical_gravity().
		_last_horizontal_speed = horizontal.length()
		return

	if not on_floor and _iron_momentum_release_left > 0.0:
		# Iron release inertia: preserve the exact horizontal momentum produced at the
		# moment the pull was released. Gravity still owns Y; this only prevents ordinary
		# air-control/coasting from immediately changing the carried travel direction.
		horizontal = _iron_release_horizontal_velocity
		velocity.x = horizontal.x
		velocity.z = horizontal.z
		_last_horizontal_speed = horizontal.length()
		return

	if on_floor:
		if has_ground_intent:
			var accel := sprint_acceleration if sprinting else ground_acceleration
			horizontal = horizontal.move_toward(target, accel * delta)
		else:
			horizontal = horizontal.move_toward(Vector3.ZERO, ground_deceleration * delta)
	else:
		if allomantic_traversal and has_ground_intent and horizontal.length_squared() > 0.04:
			# Allomancy owns the large-scale impulse. WASD only expresses desired
			# direction so the player can steer an existing trajectory without adding
			# an invisible propulsion source.
			var current_dir := horizontal.normalized()
			var desired_dir := world_dir.normalized()
			var steer := clampf(air_direction_change * delta, 0.0, 1.0)
			var steered_dir := current_dir.lerp(desired_dir, steer)
			if steered_dir.length_squared() > 0.0001:
				horizontal = steered_dir.normalized() * horizontal.length()
		elif has_ground_intent:
			# Ordinary air control is deliberately gentle. It changes direction, not
			# the fantasy of being carried by the previous jump/Allomancy action.
			# Allomantic traversal uses the faster air_direction_change steering above,
			# preserving speed while making Iron/Steel arcs easier to shape.
			horizontal = horizontal.move_toward(target, air_acceleration * delta)
		else:
			horizontal = horizontal.move_toward(Vector3.ZERO, air_coasting_deceleration * delta)

	velocity.x = horizontal.x
	velocity.z = horizontal.z
	_last_horizontal_speed = horizontal.length()

func _update_rotation(delta: float) -> void:
	var horizontal := Vector3(velocity.x, 0.0, velocity.z)
	if horizontal.length_squared() < facing_velocity_threshold * facing_velocity_threshold:
		return
	var desired_yaw := atan2(-horizontal.x, -horizontal.z)
	if _visual != null:
		_visual.rotation.y = lerp_angle(_visual.rotation.y, desired_yaw, minf(turn_speed * delta, 1.0))

func _update_crouch() -> void:
	var want_crouch := Input.is_action_pressed("crouch")
	if crouch_toggle:
		if Input.is_action_just_pressed("crouch"):
			_set_crouching(not _is_crouching)
		return
	_set_crouching(want_crouch)

func _set_crouching(value: bool, force: bool = false) -> void:
	if value == _is_crouching and not force:
		return
	if not value and _is_crouching and not force:
		if test_move(global_transform, Vector3.UP * (standing_height - crouching_height)):
			return

	_is_crouching = value
	var target_height := crouching_height if value else standing_height
	var capsule := _collision_shape.shape as CapsuleShape3D
	if capsule == null:
		capsule = CapsuleShape3D.new()
		_collision_shape.shape = capsule
	capsule.radius = capsule_radius
	capsule.height = target_height
	_collision_shape.position.y = target_height * 0.5
	_visual.position.y = 0.0
	_visual.scale = Vector3.ONE
	if _visual.has_method("set_crouched"):
		_visual.call("set_crouched", value)

func set_allomantic_action_active() -> void:
	_allomantic_action_active = true

func _update_post_move_state() -> void:
	_last_horizontal_speed = Vector3(velocity.x, 0.0, velocity.z).length()
	var just_landed := is_on_floor() and not _was_on_floor
	var state := "IDLE"
	if _is_crouching:
		state = "CROUCH"
	elif just_landed:
		state = "LAND"
	elif not is_on_floor():
		state = "AIR"
	elif Input.is_action_pressed("sprint") and _last_move_input.length_squared() > 0.01:
		state = "SPRINT"
	elif _last_horizontal_speed > 0.15:
		state = "RUN"
	movement_state_changed.emit(state)
	if _visual != null and _visual.has_method("set_movement_state"):
		_visual.call("set_movement_state", state, _last_horizontal_speed, velocity.y, is_on_floor())
	_was_on_floor = is_on_floor()

func _connect_visual_animation() -> void:
	return

func _setup_visual_material() -> void:
	if _visual != null and _visual.has_method("set_fade_alpha"):
		_visual.call("set_fade_alpha", 1.0)

func set_camera_occlusion_fade(alpha: float) -> void:
	if _visual == null:
		return
	var clamped_alpha: float = clampf(alpha, 0.2, 1.0)
	if _visual.has_method("set_fade_alpha"):
		_visual.call("set_fade_alpha", clamped_alpha)

func is_crouching() -> bool:
	return _is_crouching

func is_allomancy_input_active() -> bool:
	# Coin Jump is a Steel mode owned by Space, so it participates in the same
	# air-control contract even though it does not use Q as its activation gesture.
	if _steel != null and _steel.is_coin_jump_active():
		return true
	if _allomancy_input_owner == &"steel":
		return Input.is_action_pressed("steel_push")
	if _allomancy_input_owner == &"iron":
		return Input.is_action_pressed("iron_pull")
	# Heavy-object yank is a distinct secondary Iron intent and does not enter the
	# primary Steel/Iron hand-off state.
	return Input.is_action_pressed("iron_yank") and not Input.is_action_pressed("steel_push") and not Input.is_action_pressed("iron_pull")
func _player_is_allomancy_input_active_for_movement() -> bool:
	# Pure input gate used before child controllers update their active flags.
	return is_allomancy_input_active()

func get_allomantic_origin() -> Vector3:
	if _visual != null and _visual.has_method("get_target_socket"):
		var socket: Node3D = _visual.call("get_target_socket") as Node3D
		if socket != null and is_instance_valid(socket):
			return socket.global_position
	return global_position + Vector3.UP * 0.95

func get_allomantic_line_origin() -> Vector3:
	# Visual-only canon socket at the chest. Gameplay forces continue using
	# get_allomantic_origin() so changing the line position cannot alter physics.
	if _visual != null and _visual.has_method("get_allomantic_line_socket"):
		var socket: Node3D = _visual.call("get_allomantic_line_socket") as Node3D
		if socket != null and is_instance_valid(socket):
			return socket.global_position
	return global_position + Vector3.UP * 1.34

func apply_allomantic_anchor_response(action_name: StringName, point: Vector3, delta: float) -> bool:
	if point == Vector3.ZERO or delta <= 0.0:
		return false
	var origin := get_allomantic_origin()
	var direction := origin - point if action_name == &"steel" else point - origin
	if direction.length_squared() <= 0.0001:
		return false
	# Compatibility hook for older targets. The new targetable system owns the
	# normal path; this fallback still behaves as a force, never as a speed set.
	return apply_allomantic_force(direction, FORCE_MODEL.BASE_FORCE_NEWTONS * FORCE_MODEL.HERO_STRENGTH, delta)

func get_debug_state() -> Dictionary:
	var targeting_state: Dictionary = _targeting.get_debug_state() if _targeting != null else {}
	var steel_state: Dictionary = _steel.get_debug_state() if _steel != null else {}
	var iron_state: Dictionary = _iron.get_debug_state() if _iron != null else {}
	var traversal_state: Dictionary = _traversal.get_debug_state() if _traversal != null else {}
	return {
		"position": global_position,
		"velocity": velocity,
		"horizontal_speed": _last_horizontal_speed,
		"grounded": is_on_floor(),
		"sprinting": Input.is_action_pressed("sprint") and _last_move_input.length_squared() > 0.01 and not _is_crouching,
		"crouching": _is_crouching,
		"move_input": _last_move_input,
		"coyote_left": _coyote_left,
		"jump_buffer_left": _jump_buffer_left,
		"allomantic_motion": _allomantic_action_active,
		"target_name": targeting_state.get("target_name", "NINGUNO"),
		"target_locked": targeting_state.get("locked", false),
		"target_candidates": targeting_state.get("candidate_count", 0),
		"steel_active": steel_state.get("active", false),
		"steel_target": steel_state.get("target_name", "NINGUNO"),
		"steel_blocked": steel_state.get("blocked_reason", ""),
		"iron_active": iron_state.get("active", false),
		"iron_target": iron_state.get("target_name", "NINGUNO"),
		"iron_blocked": iron_state.get("blocked_reason", ""),
		"iron_momentum_release": is_iron_momentum_release_active(),
		"traversal_state": traversal_state.get("state", "UNKNOWN"),
		"coin_count": traversal_state.get("coin_count", 0),
		"allomancy_input_owner": str(_allomancy_input_owner),
		"steel_counterfall_uses_force": true,
		"chain_grace": traversal_state.get("chain_grace", 0.0)
	}
