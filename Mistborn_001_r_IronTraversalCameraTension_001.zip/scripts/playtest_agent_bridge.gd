extends Node

## Local runtime control bridge for external AI/test agents.
## This node is ONLY used by scenes/agent_runtime.tscn and never runs in the normal game.
## UDP protocol: JSON packets, one object per packet.
##
## Commands:
##   {"cmd":"input","move":[x,y],"sprint":false,"crouch":false,"jump":false}
##   {"cmd":"jump"}
##   {"cmd":"look","yaw_deg":0,"pitch_deg":-12}
##   {"cmd":"reset","position":[0,0,108]}
##   {"cmd":"snapshot"}
##   {"cmd":"screenshot"}
##   {"cmd":"release"}
##   {"cmd":"quit"}

@export var listen_port: int = 39123
@export var snapshot_interval_ms: int = 100

var _udp := PacketPeerUDP.new()
var _player: MistbornPlayerController
var _camera: MistbornCameraRig
var _last_snapshot_ms: int = 0
var _jump_release_pending := false
var _remote_ip := "127.0.0.1"
var _remote_port := 39124
var _held_actions: Dictionary = {}
var _last_input_move := Vector2.ZERO

func _ready() -> void:
	_player = get_node_or_null("MistbornMain/Player") as MistbornPlayerController
	if _player != null:
		_camera = _player.get_node_or_null("CameraRig") as MistbornCameraRig
	_udp.listen(listen_port, "127.0.0.1")
	print("Mistborn Agent Bridge listening on UDP %d" % listen_port)

func _process(_delta: float) -> void:
	while _udp.get_available_packet_count() > 0:
		var packet := _udp.get_packet()
		var text := packet.get_string_from_utf8()
		_remote_ip = _udp.get_packet_ip()
		_remote_port = _udp.get_packet_port()
		_handle_packet(text)
	if _jump_release_pending:
		Input.action_release("jump")
		_jump_release_pending = false

	var now := Time.get_ticks_msec()
	if now - _last_snapshot_ms >= snapshot_interval_ms:
		_last_snapshot_ms = now
		_send_snapshot()

func _handle_packet(raw: String) -> void:
	var parsed = JSON.parse_string(raw)
	if not parsed is Dictionary:
		_send({"ok": false, "error": "invalid_json_object"})
		return
	var command: Dictionary = parsed
	var cmd := String(command.get("cmd", ""))
	match cmd:
		"input":
			_apply_input(command)
			_send({"ok": true, "ack": "input"})
		"jump":
			Input.action_press("jump")
			_jump_release_pending = true
			_send({"ok": true, "ack": "jump"})
		"look":
			if _camera != null and _camera.has_method("set_playtest_look"):
				_camera.call("set_playtest_look", float(command.get("yaw_deg", 0.0)), float(command.get("pitch_deg", -12.0)))
			_send({"ok": true, "ack": "look"})
		"reset":
			_reset_player(command.get("position", [0.0, 0.0, 108.0]))
			_send({"ok": true, "ack": "reset"})
		"snapshot":
			_send_snapshot()
		"screenshot":
			_send_screenshot()
		"release":
			_release_all_inputs()
			_send({"ok": true, "ack": "release"})
		"quit":
			_send({"ok": true, "ack": "quit"})
			get_tree().quit(0)
		_:
			_send({"ok": false, "error": "unknown_command", "cmd": cmd})

func _apply_input(command: Dictionary) -> void:
	var move_variant = command.get("move", [0.0, 0.0])
	var move := Vector2(float(move_variant[0]), float(move_variant[1])) if move_variant is Array and move_variant.size() >= 2 else Vector2.ZERO
	_set_action("move_left", move.x < -0.1)
	_set_action("move_right", move.x > 0.1)
	_set_action("move_forward", move.y < -0.1)
	_set_action("move_backward", move.y > 0.1)
	_set_action("sprint", bool(command.get("sprint", false)))
	_set_action("crouch", bool(command.get("crouch", false)))
	_set_action("jump", bool(command.get("jump", false)))
	_last_input_move = move
	if bool(command.get("steel", false)):
		_set_action("steel_push", true)
	else:
		_set_action("steel_push", false)
	if bool(command.get("iron", false)):
		_set_action("iron_pull", true)
	else:
		_set_action("iron_pull", false)
	# Separate heavy-object yank input; the agent can request it as "iron_yank".
	_set_action("iron_yank", bool(command.get("iron_yank", false)))

func _set_action(action: StringName, pressed: bool) -> void:
	var current := bool(_held_actions.get(action, false))
	if current == pressed:
		return
	if pressed:
		Input.action_press(action)
	else:
		Input.action_release(action)
	_held_actions[action] = pressed

func _release_all_inputs() -> void:
	for action in [
		"move_forward", "move_backward", "move_left", "move_right",
		"sprint", "crouch", "steel_push", "iron_pull", "iron_yank", "jump"
	]:
		Input.action_release(action)
		_held_actions[action] = false
	_jump_release_pending = false

func _reset_player(position_variant: Variant) -> void:
	if _player == null:
		return
	_release_all_inputs()
	var position := Vector3(0.0, 0.0, 108.0)
	if position_variant is Array and position_variant.size() >= 3:
		position = Vector3(float(position_variant[0]), float(position_variant[1]), float(position_variant[2]))
	_player.velocity = Vector3.ZERO
	_player.global_position = position
	_player.rotation = Vector3.ZERO
	_last_input_move = Vector2.ZERO
	if _camera != null and _camera.has_method("reset_for_playtest"):
		_camera.call("reset_for_playtest", 0.0, -12.0)

func _send_snapshot() -> void:
	_send(_snapshot())

func _snapshot() -> Dictionary:
	if _player == null:
		return {"ok": false, "error": "player_not_ready"}
	var state: Dictionary = _player.get_debug_state()
	var camera_state: Dictionary = _camera.get_debug_state() if _camera != null else {}
	return {
		"ok": true,
		"type": "snapshot",
		"time_ms": Time.get_ticks_msec(),
		"position": _vec3(state.get("position", Vector3.ZERO)),
		"velocity": _vec3(state.get("velocity", Vector3.ZERO)),
		"horizontal_speed": float(state.get("horizontal_speed", 0.0)),
		"grounded": bool(state.get("grounded", false)),
		"sprinting": bool(state.get("sprinting", false)),
		"crouching": bool(state.get("crouching", false)),
		"coyote_left": float(state.get("coyote_left", 0.0)),
		"jump_buffer_left": float(state.get("jump_buffer_left", 0.0)),
		"traversal_state": String(state.get("traversal_state", "UNKNOWN")),
		"camera": {
			"yaw_deg": float(camera_state.get("yaw_deg", 0.0)),
			"pitch_deg": float(camera_state.get("pitch_deg", 0.0)),
			"distance": float(camera_state.get("distance", 0.0)),
			"fov": _get_camera_fov()
		},
		"input_move_active": _last_input_move.length() > 0.1,
		"input_move": {"x": _last_input_move.x, "y": _last_input_move.y}
	}

func _get_camera_fov() -> float:
	if _camera == null:
		return 0.0
	var camera_node := _camera.get_node_or_null("Camera3D") as Camera3D
	return camera_node.fov if camera_node != null else 0.0


func _vec3(value: Variant) -> Dictionary:
	if value is Vector3:
		var vector: Vector3 = value
		return {"x": vector.x, "y": vector.y, "z": vector.z}
	return {"x": 0.0, "y": 0.0, "z": 0.0}

func _send_screenshot() -> void:
	var viewport: Viewport = get_viewport()
	if viewport == null:
		_send({"ok": false, "error": "viewport_unavailable"})
		return
	var image: Image = viewport.get_texture().get_image()
	if image == null:
		_send({"ok": false, "error": "image_unavailable"})
		return
	var stamp := str(Time.get_ticks_msec())
	var path := "user://mistborn_playtests/agent_capture_%s.png" % stamp
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("user://mistborn_playtests"))
	var err := image.save_png(path)
	_send({"ok": err == OK, "type": "screenshot", "path": path, "error": "save_failed" if err != OK else ""})

func _send(payload: Dictionary) -> void:
	if _remote_port <= 0:
		return
	_udp.set_dest_address(_remote_ip, _remote_port)
	_udp.put_packet(JSON.stringify(payload).to_utf8_buffer())
