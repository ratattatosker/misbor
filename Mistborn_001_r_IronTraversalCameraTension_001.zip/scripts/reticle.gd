class_name MistbornReticle
extends Control

@export var size_px: float = 28.0
@export var arm_length: float = 5.0
@export var gap: float = 3.5
@export var line_width: float = 1.5
@export var dot_radius: float = 1.2
@export var opacity: float = 0.72

func _ready() -> void:
	custom_minimum_size = Vector2(size_px, size_px)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	queue_redraw()

func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		queue_redraw()

func _draw() -> void:
	var center := size * 0.5
	var half_gap := gap * 0.5
	var half_arm := arm_length * 0.5
	var inner := half_gap
	var outer := half_gap + arm_length
	var c := Color(0.94, 0.96, 1.0, opacity)

	# Cuatro pequeños brackets, dejando el centro despejado para no tapar objetivos.
	draw_line(center + Vector2(-outer, -inner), center + Vector2(-outer + half_arm, -inner), c, line_width, true)
	draw_line(center + Vector2(-inner, -outer), center + Vector2(-inner, -outer + half_arm), c, line_width, true)

	draw_line(center + Vector2(outer, -inner), center + Vector2(outer - half_arm, -inner), c, line_width, true)
	draw_line(center + Vector2(inner, -outer), center + Vector2(inner, -outer + half_arm), c, line_width, true)

	draw_line(center + Vector2(-outer, inner), center + Vector2(-outer + half_arm, inner), c, line_width, true)
	draw_line(center + Vector2(-inner, outer), center + Vector2(-inner, outer - half_arm), c, line_width, true)

	draw_line(center + Vector2(outer, inner), center + Vector2(outer - half_arm, inner), c, line_width, true)
	draw_line(center + Vector2(inner, outer), center + Vector2(inner, outer - half_arm), c, line_width, true)

	draw_circle(center, dot_radius, c)
