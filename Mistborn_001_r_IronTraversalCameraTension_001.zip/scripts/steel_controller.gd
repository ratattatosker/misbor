class_name MistbornSteelController
extends Node

signal steel_target_used(target: MistbornTargetable)

const FORCE_MODEL = preload("res://scripts/allomantic_force_model.gd")

@export_category("Steel Traversal")
@export var web_origin_height: float = 0.95

@export_category("Steel Vertical Gameplay Assist")
@export_range(10.0, 85.0, 1.0) var vertical_assist_cone_half_angle_degrees: float = 45.0
@export_range(0.0, 1.0, 0.01) var vertical_assist_strength: float = 1.0
@export_range(0.0, 0.50, 0.01) var vertical_assist_upward_priority: float = 0.18
@export_range(0.0, 0.35, 0.01) var forward_assist_strength: float = 0.18

@export_category("Steel Counter-Fall Force")
@export_range(0.10, 0.90, 0.02) var counterfall_desired_stop_time: float = 0.42
@export_range(1.0, 10.0, 0.1) var counterfall_max_strength_scale: float = 8.0
@export_range(0.35, 0.85, 0.05) var counterfall_minimum_upward_component: float = 0.45

var _player: MistbornPlayerController
var _targeting: MistbornTargetingController
var _active: bool = false
var _last_target: MistbornTargetable
var _last_block_reason: String = ""
var _impulse_count: int = 0
var _special_coin_interaction_count: int = 0
var _special_coin_force_tick_count: int = 0
var _special_coin_ground_force_tick_count: int = 0
var _special_coin_interactions: Array[Dictionary] = []
var _button_was_down: bool = false
var _last_player_response_prediction: bool = false
var _last_effective_strength: float = FORCE_MODEL.HERO_STRENGTH
var _last_counterfall_strength_scale: float = 1.0
var _last_counterfall_net_acceleration: float = 0.0
var _counterfall_strength_scale_latched: float = 1.0

func _ready() -> void:
	_player = get_parent() as MistbornPlayerController
	_targeting = _player.get_node_or_null("Targeting") as MistbornTargetingController if _player != null else null

func physics_step(delta: float) -> void:
	if _player == null:
		_stop()
		return

	# Coin Jump is a Steel mode, not another movement system. Its active coin uses
	# the same targeting authority, action line and force resolver as a normal Push.
	_process_special_coin_interactions(delta)
	if not _special_coin_interactions.is_empty():
		# Do not apply a second regular Steel interaction while Coin Jump owns the
		# Steel action. If Q is held during Coin Jump, require a fresh press afterwards.
		if _active:
			_stop()
		_button_was_down = Input.is_action_pressed("steel_push")
		return

	if _targeting == null:
		_stop()
		return

	var physical_button_down: bool = Input.is_action_pressed("steel_push")
	var owns_input: bool = _player.owns_allomancy_input(&"steel")
	if Input.is_action_just_pressed("steel_push") and owns_input:
		# A newly pressed action may take over from Iron even if the internal latch
		# was set while the two inputs overlapped.
		_button_was_down = false
	var button_down: bool = physical_button_down and owns_input
	if not button_down:
		_stop()
		_button_was_down = physical_button_down
		return
	if not _player.is_allomancy_input_active():
		_stop()
		_button_was_down = physical_button_down
		return

	# Q is a sustained Steel action. Its first owned press fixes the target;
	# holding Q keeps applying the same interaction and cannot silently retarget.
	if not _active:
		if _button_was_down:
			return
		_button_was_down = true
		var initial_target: MistbornTargetable = _get_target()
		if not _is_valid_target(initial_target):
			_stop()
			_button_was_down = true
			return
		if not _targeting.is_steel_action_active():
			_targeting.begin_action_target(initial_target, &"steel")
		_set_active(true)
		_last_target = initial_target
		_last_block_reason = ""
		_last_player_response_prediction = false
		_last_effective_strength = FORCE_MODEL.HERO_STRENGTH
		_last_counterfall_strength_scale = 1.0
		_last_counterfall_net_acceleration = 0.0
		_counterfall_strength_scale_latched = 1.0
		steel_target_used.emit(initial_target)

	var target: MistbornTargetable = _last_target
	if not _is_valid_target(target):
		_last_block_reason = "OBJETIVO_INVALIDO"
		_stop()
		return

	var reaction_direction := _get_mechanical_steel_reaction_direction(target)
	var result := _apply_shared_steel_interaction(target, delta, reaction_direction, true, true)
	if not bool(result.get("acted", false)):
		_last_block_reason = "BLOQUEADO"
	else:
		_impulse_count += 1
		_last_player_response_prediction = bool(result.get("player_receives_response", false))
		_last_effective_strength = float(result.get("effective_strength", FORCE_MODEL.HERO_STRENGTH))
		_last_counterfall_strength_scale = float(result.get("strength_scale", 1.0))
		_last_counterfall_net_acceleration = float(result.get("counterfall_net_acceleration", 0.0))

func _apply_shared_steel_interaction(
	target: MistbornTargetable,
	delta: float,
	player_reaction_direction: Vector3,
	include_support_mass: bool,
	move_target: bool
) -> Dictionary:
	# Both ordinary Steel and Coin Jump call this same path. The only difference is
	# how the target/reaction direction was chosen; force, mass, support and range
	# remain owned by MistbornTargetable + MistbornAllomanticForceModel.
	if target == null or not is_instance_valid(target) or _player == null:
		return {"acted": false, "player_receives_response": false, "effective_strength": FORCE_MODEL.HERO_STRENGTH, "strength_scale": 1.0}
	var predicted_player_response := target.predicts_player_receives_allomantic_response(
		&"steel", _player, player_reaction_direction, include_support_mass
	)
	var effective_strength := FORCE_MODEL.HERO_STRENGTH
	var force_scale := 1.0
	var net_counterfall_acceleration := 0.0
	if predicted_player_response:
		var target_point: Vector3 = target.get_allomantic_action_point(&"steel", _player.global_position, _player.is_on_floor())
		var origin: Vector3 = _player.get_allomantic_origin()
		var distance := origin.distance_to(target_point)
		var player_mass := _player.get_gameplay_mass()
		var candidate_strength := FORCE_MODEL.HERO_STRENGTH
		var upward_component := player_reaction_direction.normalized().y if player_reaction_direction.length_squared() > 0.0001 else -1.0
		var actively_falling := not _player.is_on_floor() and _player.velocity.y < -0.05
		if actively_falling and upward_component >= counterfall_minimum_upward_component:
			candidate_strength = FORCE_MODEL.calculate_steel_counterfall_strength(
				FORCE_MODEL.HERO_STRENGTH,
				distance,
				player_mass,
				_player.gravity,
				_player.velocity.y,
				player_reaction_direction,
				true,
				counterfall_desired_stop_time,
				counterfall_max_strength_scale,
				counterfall_minimum_upward_component
			)
		# Once a supported upward Steel action has required extra force to catch a fall,
		# keep that force level for the remainder of the held action. Otherwise the boost
		# would vanish the instant velocity reaches zero, gravity would win again, and the
		# player could jitter between falling and catching. Releasing/changing recipient resets it.
		var candidate_scale := candidate_strength / maxf(FORCE_MODEL.HERO_STRENGTH, 0.001)
		if actively_falling and upward_component >= counterfall_minimum_upward_component:
			_counterfall_strength_scale_latched = maxf(_counterfall_strength_scale_latched, candidate_scale)
		force_scale = clampf(maxf(_counterfall_strength_scale_latched, candidate_scale), 1.0, counterfall_max_strength_scale)
		effective_strength = FORCE_MODEL.HERO_STRENGTH * force_scale
		var reaction_y := maxf(upward_component, 0.0)
		var actual_force := FORCE_MODEL.force_magnitude(distance, effective_strength)
		net_counterfall_acceleration = (actual_force / maxf(player_mass, 1.0)) * reaction_y - _player.gravity
	else:
		_counterfall_strength_scale_latched = 1.0
	var acted: bool = target.apply_allomantic_interaction(
		&"steel", _player, delta, effective_strength, move_target,
		player_reaction_direction, include_support_mass
	)
	var player_received := bool(target.get_meta("allomantic_player_receives_response", predicted_player_response))
	return {
		"acted": acted,
		"player_receives_response": player_received,
		"effective_strength": effective_strength,
		"strength_scale": force_scale,
		"counterfall_net_acceleration": net_counterfall_acceleration
	}

func _get_mechanical_steel_reaction_direction(target: MistbornTargetable) -> Vector3:
	if target == null or not is_instance_valid(target) or _player == null:
		return Vector3.ZERO

	var natural := target.get_allomantic_player_reaction_direction(&"steel", _player)
	if natural.length_squared() <= 0.0001:
		return Vector3.ZERO
	natural = natural.normalized()

	# This is a traversal-feel mechanic, so grounded Steel keeps the exact natural
	# reaction. Only airborne Steel receives the gameplay assist.
	if _player.is_on_floor():
		return natural

	var camera := _player.get_node_or_null("CameraRig/Camera3D") as Camera3D
	if camera == null:
		return natural

	var forward := -camera.global_transform.basis.z
	forward.y = 0.0
	if forward.length_squared() <= 0.0001:
		return natural
	forward = forward.normalized()

	# Steel itself must not act like a free directional steering stick. WASD belongs
	# to CharacterController; Steel gets only a small forward assist when the player
	# explicitly holds W and the physical reaction already points toward camera-forward.
	# A/D/S do not bend the Steel force. The target and the shared mass/force resolver
	# remain authoritative, so a sideways/backward physical reaction remains possible
	# if the selected metal really lies in that position.
	var move_intent: Vector2 = _player.get_last_move_input()
	var forward_only := move_intent.y < -0.20 and absf(move_intent.x) < 0.30
	if not forward_only:
		return natural

	var natural_flat := Vector3(natural.x, 0.0, natural.z)
	if natural_flat.length_squared() <= 0.0001:
		return natural
	var horizontal_reaction := natural_flat.normalized()
	var dot := clampf(forward.dot(horizontal_reaction), -1.0, 1.0)
	var limit := cos(deg_to_rad(vertical_assist_cone_half_angle_degrees))
	if dot < limit:
		return natural

	# Smooth fade at the edge. The assist is deliberately subtle and points forward,
	# with only a small upward component; lateral/backward steering remains ordinary WASD air control.
	var cone_strength := clampf((dot - limit) / maxf(1.0 - limit, 0.001), 0.0, 1.0)
	cone_strength = cone_strength * cone_strength * (3.0 - 2.0 * cone_strength)
	cone_strength *= clampf(vertical_assist_strength, 0.0, 1.0)
	var up_weight := clampf(vertical_assist_upward_priority, 0.0, 0.50)
	var forward_preferred := (forward * (1.0 - up_weight) + Vector3.UP * up_weight).normalized()
	var blend := clampf(cone_strength * forward_assist_strength, 0.0, 0.35)
	if blend <= 0.001:
		return natural
	return natural.lerp(forward_preferred, blend).normalized()

func try_special_coin_interaction() -> bool:
	if _player == null or _targeting == null:
		return false
	var traversal := _player.get_node_or_null("Traversal") as MistbornTraversalController
	if traversal == null:
		return false

	# Coin Jump may take over an existing regular Steel action, but never stacks two
	# simultaneous Steel forces. It acquires the spawned coin as a fixed Steel target.
	if _active:
		_stop()
	_counterfall_strength_scale_latched = 1.0
	var coin := traversal.spawn_steel_coin_interaction_coin()
	if coin == null:
		return false
	var target := coin.get_targetable()
	if target == null or not is_instance_valid(target):
		coin.finish_steel_special_interaction()
		return false
	if not _targeting.begin_action_target(target, &"steel"):
		coin.finish_steel_special_interaction()
		return false
	target.set_meta("allomantic_steel_interaction_mode", "COIN_JUMP")
	_special_coin_interactions.append({
		"coin": coin,
		"response_counted": false,
		"input_held": true,
	})
	return true

func _finish_special_coin(coin: MistbornCoin) -> void:
	if coin == null or not is_instance_valid(coin):
		return
	var target := coin.get_targetable()
	if target != null and is_instance_valid(target):
		if target.has_meta("allomantic_steel_interaction_mode"):
			target.remove_meta("allomantic_steel_interaction_mode")
		if _targeting != null and _targeting.get_action_target() == target and _targeting.is_steel_action_active():
			_targeting.end_action_target(&"steel")
	coin.finish_steel_special_interaction()

func _process_special_coin_interactions(delta: float) -> void:
	if delta <= 0.0 or _player == null:
		return
	for index in range(_special_coin_interactions.size() - 1, -1, -1):
		var state: Dictionary = _special_coin_interactions[index]
		var coin := state.get("coin") as MistbornCoin
		if coin == null or not is_instance_valid(coin) or not coin.is_inside_tree():
			_special_coin_interactions.remove_at(index)
			continue
		if not coin.is_steel_special_response_pending():
			_finish_special_coin(coin)
			_special_coin_interactions.remove_at(index)
			continue
		# Coin Jump belongs to Steel. A fresh Q or E press transfers ownership to the
		# newly chosen primary power; do not let the contextual coin action run in parallel.
		var q_takes_over := Input.is_action_just_pressed("steel_push") and _player.owns_allomancy_input(&"steel")
		var e_takes_over := Input.is_action_just_pressed("iron_pull") and _player.owns_allomancy_input(&"iron")
		var iron_yank_takes_over := Input.is_action_just_pressed("iron_yank") and not Input.is_action_pressed("steel_push") and not Input.is_action_pressed("iron_pull")
		if q_takes_over or e_takes_over or iron_yank_takes_over:
			_finish_special_coin(coin)
			_special_coin_interactions.remove_at(index)
			continue
		if not Input.is_action_pressed("jump"):
			# Release ends the action but leaves the physical coin in the world.
			_finish_special_coin(coin)
			_special_coin_interactions.remove_at(index)
			continue
		var target := coin.get_targetable()
		if target == null or not is_instance_valid(target):
			_finish_special_coin(coin)
			_special_coin_interactions.remove_at(index)
			continue

		# Coin Jump uses the same fixed action target and same 35 m authority as Q Steel.
		# It ends on input release, a fresh Q/E handoff, target/range loss or coin cancellation.
		var actor_origin: Vector3 = _player.get_allomantic_origin()
		var target_point: Vector3 = target.get_allomantic_action_point(&"steel", _player.global_position, _player.is_on_floor())
		if actor_origin.distance_to(target_point) > FORCE_MODEL.SHARED_RANGE:
			_finish_special_coin(coin)
			_special_coin_interactions.remove_at(index)
			continue

		if not coin.has_ground_contact():
			# Before ground contact, the coin receives the ordinary Steelpush downward.
			# No player velocity is edited, and no support/counter-fall multiplier applies.
			var descent_result := _apply_shared_steel_interaction(target, delta, Vector3.UP, false, true)
			if bool(descent_result.get("acted", false)) and not bool(descent_result.get("player_receives_response", false)):
				_special_coin_force_tick_count += 1
				coin.record_steel_special_force_tick(false)
			continue

		# The very first tick after physical floor contact uses that contact as Steel's
		# support: the same resolver now sends the reaction to the player. The dynamic
		# counter-fall multiplier acts through the actual force, not a velocity brake.
		var ground_result := _apply_shared_steel_interaction(target, delta, Vector3.UP, true, false)
		var player_received := bool(ground_result.get("player_receives_response", false))
		if bool(ground_result.get("acted", false)) and player_received:
			_special_coin_ground_force_tick_count += 1
			coin.record_steel_special_force_tick(true)
			if not bool(state.get("response_counted", false)):
				_special_coin_interaction_count += 1
				state["response_counted"] = true
			_last_effective_strength = float(ground_result.get("effective_strength", FORCE_MODEL.HERO_STRENGTH))
			_last_counterfall_strength_scale = float(ground_result.get("strength_scale", 1.0))
			_last_counterfall_net_acceleration = float(ground_result.get("counterfall_net_acceleration", 0.0))
		_special_coin_interactions[index] = state

func is_active() -> bool:
	if _active:
		return true
	for state: Dictionary in _special_coin_interactions:
		var coin := state.get("coin") as MistbornCoin
		if coin != null and is_instance_valid(coin) and coin.is_steel_special_response_pending():
			return true
	return false

func is_coin_jump_active() -> bool:
	return not _special_coin_interactions.is_empty()

func _get_target() -> MistbornTargetable:
	if _targeting == null:
		return null
	return _targeting.acquire_action_target(&"steel")

func _is_valid_target(target: MistbornTargetable) -> bool:
	if target == null or not is_instance_valid(target):
		return false
	if not target.selectable or not target.is_metallic or not target.steel_pushable:
		return false
	return _player.global_position.distance_to(target.get_allomantic_visual_point()) <= FORCE_MODEL.SHARED_RANGE

func _get_web_origin() -> Vector3:
	if _player == null:
		return Vector3.ZERO
	var origin: Vector3 = _player.global_position + Vector3.UP * web_origin_height
	var visual: Node = _player.get_node_or_null("Visual")
	if visual != null and visual.has_method("get_target_socket"):
		var socket: Node3D = visual.call("get_target_socket") as Node3D
		if socket != null and is_instance_valid(socket):
			origin = socket.global_position
	return origin

func _stop() -> void:
	_counterfall_strength_scale_latched = 1.0
	# End only the regular target this controller owns. Coin Jump can own a separate
	# Steel target at the same time, and must not lose its line on the next idle-Q tick.
	if _targeting != null and _last_target != null and is_instance_valid(_last_target):
		if _targeting.get_action_target() == _last_target and _targeting.is_steel_action_active():
			_targeting.end_action_target(&"steel")
	_last_target = null
	_last_block_reason = ""
	_set_active(false)

func reset_for_playground() -> void:
	_stop()
	_button_was_down = false
	for index in range(_special_coin_interactions.size() - 1, -1, -1):
		var state: Dictionary = _special_coin_interactions[index]
		var coin := state.get("coin") as MistbornCoin
		if coin != null and is_instance_valid(coin):
			_finish_special_coin(coin)
	_special_coin_interactions.clear()
	_impulse_count = 0
	_special_coin_interaction_count = 0
	_special_coin_force_tick_count = 0
	_special_coin_ground_force_tick_count = 0
	_last_effective_strength = FORCE_MODEL.HERO_STRENGTH
	_last_counterfall_strength_scale = 1.0
	_last_counterfall_net_acceleration = 0.0
	_counterfall_strength_scale_latched = 1.0

func _set_active(value: bool) -> void:
	_active = value

func get_debug_state() -> Dictionary:
	var debug_target := _last_target if _last_target != null and is_instance_valid(_last_target) else null
	var interaction_mode := "STEEL_PUSH"
	if debug_target == null and not _special_coin_interactions.is_empty():
		var state: Dictionary = _special_coin_interactions.back()
		var coin := state.get("coin") as MistbornCoin
		debug_target = coin.get_targetable() if coin != null and is_instance_valid(coin) else null
		interaction_mode = "COIN_JUMP"
	return {
		"active": is_active(),
		"standard_steel_active": _active,
		"interaction_mode": interaction_mode if is_active() else "NONE",
		"target_name": debug_target.display_name if debug_target != null and is_instance_valid(debug_target) else "NINGUNO",
		"blocked_reason": _last_block_reason,
		"range": FORCE_MODEL.SHARED_RANGE,
		"force_model": "shared_radial_force_and_counterfall_force_scaling",
		"vertical_assist_cone_half_angle_degrees": vertical_assist_cone_half_angle_degrees,
		"vertical_assist_strength": vertical_assist_strength,
		"vertical_assist_upward_priority": vertical_assist_upward_priority,
		"forward_assist_strength": forward_assist_strength,
		"predicted_player_receives_response": _last_player_response_prediction,
		"effective_steel_strength": _last_effective_strength,
		"counterfall_strength_scale": _last_counterfall_strength_scale,
		"counterfall_desired_stop_time": counterfall_desired_stop_time,
		"counterfall_max_strength_scale": counterfall_max_strength_scale,
		"counterfall_strength_scale_latched": _counterfall_strength_scale_latched,
		"counterfall_net_acceleration_estimate": _last_counterfall_net_acceleration,
		"input_latched": _button_was_down,
		"impulse_count": _impulse_count,
		"special_coin_interaction_count": _special_coin_interaction_count,
		"special_coin_force_tick_count": _special_coin_force_tick_count,
		"special_coin_ground_force_tick_count": _special_coin_ground_force_tick_count,
		"active_special_coin_interactions": _special_coin_interactions.size(),
		"coin_jump_same_steel_action": not _special_coin_interactions.is_empty(),
		"coin_jump_requires_second_space_hold": true,
	}
