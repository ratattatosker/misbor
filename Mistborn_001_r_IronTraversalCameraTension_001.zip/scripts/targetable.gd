class_name MistbornTargetable
extends Area3D

const SIGHT_HIGHLIGHT_SHADER: Shader = preload("res://scripts/allomantic_sight.gdshader")
const FORCE_MODEL = preload("res://scripts/allomantic_force_model.gd")

@export_category("Identity")
@export var target_id: String = "target"
@export var display_name: String = "Objetivo"
@export var target_type: String = "GENERIC"

@export_category("Targeting")
@export_range(0.0, 10.0, 0.1) var selection_priority: float = 1.0
@export_range(0.0, 1.0, 0.01) var target_size_priority: float = 0.5
@export_range(0.0, 1.0, 0.01) var target_height_priority: float = 0.5
@export_range(0.0, 1.0, 0.01) var target_accessibility: float = 0.5
@export_range(0.0, 200.0, 0.1) var max_range_override: float = 0.0
@export var selectable: bool = true
@export var requires_line_of_sight: bool = true
@export var show_in_allomantic_sight: bool = true
@export var is_metallic: bool = false
@export var standable_on: bool = false
@export var mountable_on_arrival: bool = false
@export var steel_pushable: bool = false
@export var iron_pullable: bool = false

@export_category("Allomantic Response")
@export_enum("ANCHOR", "SMALL_OBJECT", "CHARACTER", "PROJECTILE", "DECORATIVE") var allomantic_profile: String = "SMALL_OBJECT"
@export var allomantic_object_collision_mask: int = 1
@export var allomantic_visual_mass: float = 0.0

var _marker: Label3D
var _name_label: Label3D
var _selected := false
var _preview := false
var _physical_body: PhysicsBody3D
var _allomantic_sight_active := false
var _sight_highlight_layers: Array[MeshInstance3D] = []
var _sight_source_nodes: Array[MeshInstance3D] = []

func _ready() -> void:
	add_to_group("mistborn_targetable")
	collision_layer = 2
	collision_mask = 0
	monitoring = false
	monitorable = true
	_build_marker()
	_build_sight_highlight()
	_set_visual_state()

func _build_marker() -> void:
	_marker = Label3D.new()
	_marker.name = "TargetMarker"
	_marker.text = "·"
	_marker.font_size = 64
	_marker.outline_size = 8
	_marker.outline_modulate = Color(0.015, 0.02, 0.03, 0.95)
	_marker.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_marker.no_depth_test = true
	_marker.position = Vector3(0.0, 0.9, 0.0)
	add_child(_marker)

	_name_label = Label3D.new()
	_name_label.name = "TargetName"
	_name_label.text = display_name
	_name_label.font_size = 24
	_name_label.outline_size = 5
	_name_label.outline_modulate = Color(0.015, 0.02, 0.03, 0.95)
	_name_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_name_label.no_depth_test = true
	_name_label.position = Vector3(0.0, 1.45, 0.0)
	add_child(_name_label)

func _build_sight_highlight() -> void:
	for layer in _sight_highlight_layers:
		if layer != null and is_instance_valid(layer):
			layer.queue_free()
	_sight_highlight_layers.clear()
	_sight_source_nodes.clear()

	var source_meshes: Array[MeshInstance3D] = []
	_collect_highlight_meshes(self, source_meshes, self)

	# Some targets are metadata children of a larger visual object (e.g. a street
	# lamp). In that case the metal geometry lives on the target's parent. Search
	# only that immediate visual owner, while never stealing meshes belonging to a
	# different Targetable.
	if source_meshes.is_empty():
		var owner := get_parent()
		if owner != null:
			_collect_highlight_meshes(owner, source_meshes, self)

	# Last fallback: build an aura from this target's own collision geometry.
	if source_meshes.is_empty():
		var fallback_mesh := _build_fallback_highlight_mesh()
		if fallback_mesh != null:
			var fallback_instance := MeshInstance3D.new()
			fallback_instance.mesh = fallback_mesh
			fallback_instance.transform = Transform3D.IDENTITY
			source_meshes.append(fallback_instance)

	if source_meshes.is_empty():
		return

	# Fewer layers when an object has many pieces keeps the effect chunky and cheap.
	var layers := [
		{"alpha": 0.48, "glow": 5.2, "pulse": 2.4},
		{"alpha": 0.16, "glow": 2.4, "pulse": 1.65}
	]
	for source in source_meshes:
		if source == null or not is_instance_valid(source) or source.mesh == null:
			continue
		for i in range(layers.size()):
			var layer_def: Dictionary = layers[i]
			var layer := MeshInstance3D.new()
			layer.name = "AllomanticSightChakra_%d_%d" % [_sight_highlight_layers.size(), i]
			layer.mesh = source.mesh
			layer.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			layer.gi_mode = GeometryInstance3D.GI_MODE_DISABLED

			var material := ShaderMaterial.new()
			material.shader = SIGHT_HIGHLIGHT_SHADER
			material.set_shader_parameter("sight_color", Color(0.045, 0.68, 1.0, float(layer_def["alpha"])))
			material.set_shader_parameter("pulse_speed", float(layer_def["pulse"]))
			material.set_shader_parameter("glow_strength", float(layer_def["glow"]))
			layer.material_override = material
			layer.visible = false
			var owner := source.get_parent()
			if owner != null and source.is_inside_tree():
				owner.add_child(layer)
				layer.global_transform = source.global_transform
			else:
				add_child(layer)
				layer.transform = Transform3D.IDENTITY
			_sight_highlight_layers.append(layer)
			if source.is_inside_tree():
				_sight_source_nodes.append(source)

	set_process(not _sight_source_nodes.is_empty())

func _collect_highlight_meshes(root: Node, out: Array[MeshInstance3D], owner_target: MistbornTargetable) -> void:
	if root == null or not is_instance_valid(root):
		return
	if root is MeshInstance3D and root != owner_target:
		var mesh := root as MeshInstance3D
		if mesh.mesh != null and not root.name.begins_with("AllomanticSightChakra_"):
			var ancestor := mesh.get_parent()
			var belongs_to_other_target := false
			while ancestor != null and ancestor != owner_target:
				if ancestor is MistbornTargetable and ancestor != owner_target:
					belongs_to_other_target = true
					break
				ancestor = ancestor.get_parent()
			if not belongs_to_other_target:
				out.append(mesh)
			return
	for child in root.get_children():
		_collect_highlight_meshes(child, out, owner_target)

func _build_fallback_highlight_mesh() -> Mesh:
	for candidate_parent in [self, _physical_body]:
		if candidate_parent == null or not is_instance_valid(candidate_parent):
			continue
		for child in candidate_parent.get_children():
			if not child is CollisionShape3D:
				continue
			var collision := child as CollisionShape3D
			if collision.shape == null:
				continue
			if collision.shape is BoxShape3D:
				var box_shape := collision.shape as BoxShape3D
				var box := BoxMesh.new()
				box.size = box_shape.size
				return box
			if collision.shape is CylinderShape3D:
				var cylinder_shape := collision.shape as CylinderShape3D
				var cylinder := CylinderMesh.new()
				cylinder.top_radius = cylinder_shape.radius
				cylinder.bottom_radius = cylinder_shape.radius
				cylinder.height = cylinder_shape.height
				cylinder.radial_segments = 32
				return cylinder
	return null

func _process(_delta: float) -> void:
	if _sight_source_nodes.is_empty():
		return
	for i in range(mini(_sight_source_nodes.size(), _sight_highlight_layers.size())):
		var source := _sight_source_nodes[i]
		var layer := _sight_highlight_layers[i]
		if source == null or not is_instance_valid(source) or layer == null or not is_instance_valid(layer):
			continue
		if not source.is_inside_tree() or not layer.is_inside_tree():
			continue
		layer.global_transform = source.global_transform
		layer.scale = source.global_transform.basis.get_scale() * _get_chakra_layer_scale(layer)

func _get_chakra_layer_scale(_layer: MeshInstance3D) -> Vector3:
	# The Allomantic Sight aura is a surface phenomenon: never expand the mesh
	# outside the object's actual silhouette. Contour intensity comes from the
	# shader's rim term, while the interior layer remains coplanar with the source.
	return Vector3.ONE

func set_allomantic_sight_active(value: bool) -> void:
	_allomantic_sight_active = value
	_set_visual_state()

func set_selected(value: bool) -> void:
	_selected = value
	_set_visual_state()

func set_preview(value: bool) -> void:
	_preview = value
	_set_visual_state()

func _set_visual_state() -> void:
	if _marker == null or _name_label == null:
		return
	_marker.visible = _selected or (_preview and show_in_allomantic_sight)
	_name_label.visible = _selected
	var show_chakra := _allomantic_sight_active and show_in_allomantic_sight and (_selected or _preview)
	for layer in _sight_highlight_layers:
		if layer != null and is_instance_valid(layer):
			layer.visible = show_chakra

	if _selected:
		_marker.text = "◎"
		_marker.font_size = 74
		_marker.modulate = Color(0.86, 0.94, 1.0, 1.0)
		_name_label.modulate = Color(0.86, 0.94, 1.0, 1.0)
	elif _preview:
		_marker.text = "·"
		var preview_size := 46
		var preview_alpha := 0.56
		match allomantic_profile:
			"ANCHOR":
				preview_size = 68
				preview_alpha = 0.82
			"CHARACTER":
				preview_size = 58
				preview_alpha = 0.72
			"PROJECTILE":
				preview_size = 50
				preview_alpha = 0.66
		_marker.font_size = preview_size
		_marker.modulate = Color(0.45, 0.64, 0.92, preview_alpha)
		_name_label.modulate = Color(0.72, 0.80, 0.92, 0.92)

func get_allomantic_profile() -> String:
	return allomantic_profile

func get_allomantic_visual_point() -> Vector3:
	return global_position

func get_allomantic_action_point(_action_name: StringName, _actor_position: Vector3, _actor_grounded: bool) -> Vector3:
	# The active line always terminates at the exact metal point. Gameplay may use a
	# separate stand surface, but it never changes the visible Allomantic anchor.
	return get_allomantic_visual_point()

func get_allomantic_stand_point() -> Vector3:
	if not standable_on:
		return get_allomantic_visual_point()
	var body: PhysicsBody3D = _physical_body
	if body == null or not is_instance_valid(body):
		return get_allomantic_visual_point()
	var highest_y: float = -INF
	for child in body.get_children():
		if not child is CollisionShape3D:
			continue
		var collision := child as CollisionShape3D
		if collision.shape == null or not collision.disabled:
			var top_y: float = _collision_top_y(collision)
			if top_y > highest_y:
				highest_y = top_y
	if is_inf(highest_y):
		return get_allomantic_visual_point()
	var point := get_allomantic_visual_point()
	point.y = highest_y
	return point

func is_mountable_on_arrival() -> bool:
	return mountable_on_arrival and standable_on

func get_mount_stand_point() -> Vector3:
	return get_allomantic_stand_point()

func _collision_top_y(collision: CollisionShape3D) -> float:
	var basis := collision.global_transform.basis
	if collision.shape is BoxShape3D:
		var box := collision.shape as BoxShape3D
		var half := box.size * 0.5
		var y_offset := absf(basis.y.x) * half.x + absf(basis.y.y) * half.y + absf(basis.y.z) * half.z
		return collision.global_position.y + y_offset
	if collision.shape is CylinderShape3D:
		var cylinder := collision.shape as CylinderShape3D
		var radial_y := sqrt(basis.y.x * basis.y.x + basis.y.z * basis.y.z)
		var y_offset := absf(basis.y.y) * (cylinder.height * 0.5) + radial_y * cylinder.radius
		return collision.global_position.y + y_offset
	return collision.global_position.y

func is_actor_on_stand_surface(actor: CharacterBody3D) -> bool:
	if not standable_on or actor == null or not is_instance_valid(actor):
		return false
	var body: PhysicsBody3D = _physical_body
	if body == null or not is_instance_valid(body):
		return false
	var world := get_world_3d()
	if world == null:
		return false
	var from := actor.global_position + Vector3.UP * 0.08
	var to := actor.global_position + Vector3.DOWN * 0.38
	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.collision_mask = 1
	query.collide_with_bodies = true
	query.collide_with_areas = false
	query.exclude = [actor.get_rid()]
	var hit := world.direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return false
	var collider: Variant = hit.get("collider")
	if collider == body:
		return true
	return collider is Node and body.is_ancestor_of(collider)

func get_allomantic_player_reaction_direction(action_name: StringName, actor: CharacterBody3D) -> Vector3:
	if actor == null or not is_instance_valid(actor):
		return Vector3.ZERO
	if action_name != &"steel" and action_name != &"iron":
		return Vector3.ZERO

	var actor_position: Vector3 = actor.global_position
	var actor_origin: Vector3 = actor_position + Vector3.UP * 0.95
	if actor.has_method("get_allomantic_origin"):
		actor_origin = actor.call("get_allomantic_origin") as Vector3
	var target_point: Vector3 = get_allomantic_action_point(action_name, actor_position, actor.is_on_floor())
	var toward := target_point - actor_origin
	if toward.length_squared() <= 0.0001:
		return Vector3.ZERO

	var toward_target := toward.normalized()
	# Iron: the Mistborn reacts toward the metal.
	# Steel: the Mistborn reacts exactly opposite to Iron.
	var reaction := toward_target if action_name == &"iron" else -toward_target

	if action_name == &"iron" and actor.is_on_floor():
		var flat := Vector3(reaction.x, 0.0, reaction.z)
		if flat.length_squared() > 0.0001:
			# Preserve the strong horizontal reaction on the ground while adding a
			# small climb bias only when the target is meaningfully above the player.
			var lift := clampf((target_point.y - actor_position.y - 0.85) / 3.5, 0.0, 0.24)
			reaction = (flat.normalized() + Vector3.UP * lift).normalized()

	return reaction

func apply_allomantic_interaction(action_name: StringName, actor: CharacterBody3D, delta: float, strength: float = 1.0, move_target: bool = true, reaction_direction_override: Vector3 = Vector3.ZERO, include_support_mass: bool = true) -> bool:
	if actor == null or not is_instance_valid(actor) or delta <= 0.0:
		return false
	if not selectable or not is_metallic:
		return false
	if action_name == &"steel" and not steel_pushable:
		return false
	if action_name == &"iron" and not iron_pullable:
		return false

	var actor_position: Vector3 = actor.global_position
	var actor_origin: Vector3 = actor_position + Vector3.UP * 0.95
	if actor.has_method("get_allomantic_origin"):
		actor_origin = actor.call("get_allomantic_origin") as Vector3
	var target_point: Vector3 = get_allomantic_action_point(action_name, actor_position, actor.is_on_floor())
	var toward: Vector3 = target_point - actor_origin
	var distance: float = toward.length()
	if distance <= 0.0001 or distance > FORCE_MODEL.SHARED_RANGE:
		return false

	var player_reaction_direction := reaction_direction_override if reaction_direction_override.length_squared() > 0.0001 else get_allomantic_player_reaction_direction(action_name, actor)
	if player_reaction_direction.length_squared() <= 0.0001:
		return false
	player_reaction_direction = player_reaction_direction.normalized()
	var target_force_direction: Vector3 = -player_reaction_direction
	var force: float = FORCE_MODEL.force_magnitude(distance, strength)
	if force <= 0.0:
		return false

	var target_mass: float = get_allomantic_mass()
	# A coin on firm street ground is treated as fully anchored for Steel, regardless of
	# whether the line-of-force is mostly horizontal or vertical. Airborne coins remain
	# lightweight; the transition is detected from actual near-contact with the ground.
	var grounded_coin_support_mass: float = _get_grounded_coin_steel_support_mass(action_name) if include_support_mass else 0.0
	var support_mass: float = grounded_coin_support_mass if grounded_coin_support_mass > 0.0 else (_get_blocking_support_mass(target_force_direction, actor) if include_support_mass else 0.0)
	var effective_interaction_mass: float = FORCE_MODEL.effective_interaction_mass(target_mass, support_mass)
	var player_mass: float = FORCE_MODEL.PLAYER_MASS
	if actor.has_method("get_gameplay_mass"):
		player_mass = maxf(float(actor.call("get_gameplay_mass")), 0.001)
	var player_receives: bool = FORCE_MODEL.player_receives_response(player_mass, effective_interaction_mass)
	var target_receives: bool = not player_receives

	if player_receives:
		if actor.has_method("apply_allomantic_force"):
			actor.call("apply_allomantic_force", player_reaction_direction, force, delta)
	else:
		var body := _physical_body
		if move_target and target_receives and body != null and is_instance_valid(body) and body is RigidBody3D:
			var rigid := body as RigidBody3D
			if not rigid.freeze:
				rigid.sleeping = false
				var target_force: float = FORCE_MODEL.target_force_for_mass(force, target_mass)
				rigid.apply_central_force(target_force_direction * target_force)

	set_meta("allomantic_blocked_by_support", support_mass > 0.0)
	set_meta("allomantic_support_mass", support_mass)
	if grounded_coin_support_mass > 0.0:
		set_meta("allomantic_blocker_name", "Suelo firme (moneda anclada para Steel)")
		set_meta("allomantic_blocker_mass", grounded_coin_support_mass)
		set_meta("allomantic_blocker_chain_masses", [grounded_coin_support_mass])
		set_meta("allomantic_blocker_chain_depth", 1)
	set_meta("allomantic_effective_interaction_mass", effective_interaction_mass)
	set_meta("allomantic_player_receives_response", player_receives)
	set_meta("allomantic_target_receives_response", target_receives)

	return player_receives or target_receives

func predicts_player_receives_allomantic_response(
	action_name: StringName,
	actor: CharacterBody3D,
	reaction_direction_override: Vector3 = Vector3.ZERO,
	include_support_mass: bool = true
) -> bool:
	# Predict the recipient with the exact same mass/support rule used by
	# apply_allomantic_interaction(). This lets traversal choose recovery behavior
	# without applying a second force model or causing an interaction as a side effect.
	if actor == null or not is_instance_valid(actor):
		return false
	if not selectable or not is_metallic:
		return false
	if action_name == &"steel" and not steel_pushable:
		return false
	if action_name == &"iron" and not iron_pullable:
		return false
	if action_name != &"steel" and action_name != &"iron":
		return false

	var player_reaction_direction := reaction_direction_override
	if player_reaction_direction.length_squared() <= 0.0001:
		player_reaction_direction = get_allomantic_player_reaction_direction(action_name, actor)
	if player_reaction_direction.length_squared() <= 0.0001:
		return false
	var target_force_direction := -player_reaction_direction.normalized()
	var grounded_coin_support_mass: float = _get_grounded_coin_steel_support_mass(action_name) if include_support_mass else 0.0
	var support_mass: float = grounded_coin_support_mass if grounded_coin_support_mass > 0.0 else (_get_blocking_support_mass(target_force_direction, actor) if include_support_mass else 0.0)
	var effective_mass := FORCE_MODEL.effective_interaction_mass(get_allomantic_mass(), support_mass)
	var player_mass := FORCE_MODEL.PLAYER_MASS
	if actor.has_method("get_gameplay_mass"):
		player_mass = maxf(float(actor.call("get_gameplay_mass")), 0.001)
	return FORCE_MODEL.player_receives_response(player_mass, effective_mass)

func _get_grounded_coin_steel_support_mass(action_name: StringName) -> float:
	if action_name != &"steel" or target_type.to_upper() != "COIN":
		return 0.0
	var coin := _physical_body as MistbornCoin
	if coin == null or not is_instance_valid(coin):
		return 0.0
	return FORCE_MODEL.grounded_coin_anchor_mass(action_name, target_type, coin.has_firm_ground_anchor_for_steel())

func _get_blocking_support_mass(target_force_direction: Vector3, actor: CharacterBody3D) -> float:
	# General binary mass pass: support is based on DIRECTIONAL BLOCKING, not mere contact.
	# Grounded coins are an explicit Steel-only world-design exception resolved before
	# this helper: street cobbles/compacted earth treat them as fully anchored regardless
	# of lateral push angle. Other objects still need directional blocking here.
	# Once a body is blocked in the requested direction, its support chain is accumulated.
	if _physical_body == null or not is_instance_valid(_physical_body):
		return 0.0
	var world := get_world_3d()
	if world == null:
		return 0.0
	var direction := target_force_direction.normalized()
	if direction.length_squared() <= 0.0001:
		return 0.0

	var total_support_mass := 0.0
	var current_start := get_allomantic_visual_point() - direction * 0.03
	var excluded_rids: Array[RID] = [_physical_body.get_rid()]
	if actor != null and is_instance_valid(actor):
		excluded_rids.append(actor.get_rid())

	var chain_names: Array[String] = []
	var chain_masses: Array[float] = []
	var chain_depth := 0

	while chain_depth < FORCE_MODEL.MAX_BLOCKING_CHAIN_DEPTH:
		var query := PhysicsRayQueryParameters3D.create(
			current_start,
			current_start + direction * FORCE_MODEL.BLOCKING_CHAIN_PROBE_DISTANCE
		)
		query.collision_mask = allomantic_object_collision_mask
		query.collide_with_bodies = true
		query.collide_with_areas = false
		query.exclude = excluded_rids

		var hit := world.direct_space_state.intersect_ray(query)
		if hit.is_empty():
			break

		var collider: Variant = hit.get("collider")
		if collider == null or not collider is PhysicsBody3D:
			break
		var blocker := collider as PhysicsBody3D
		if blocker == null or not is_instance_valid(blocker):
			break
		if excluded_rids.has(blocker.get_rid()):
			break

		var hit_normal_variant: Variant = hit.get("normal", Vector3.ZERO)
		var hit_normal: Vector3 = hit_normal_variant as Vector3 if hit_normal_variant is Vector3 else Vector3.ZERO
		if hit_normal.length_squared() <= 0.0001:
			break

		# A blocker counts only when its contact normal opposes the requested motion.
		# A surface touched from the side/back without blocking this direction does not
		# contribute mass, even though the bodies may be in contact.
		var into_support: float = direction.dot(hit_normal.normalized())
		if into_support >= -0.12:
			break

		var support_mass := _get_body_effective_mass(blocker)
		if support_mass <= 0.0:
			break

		total_support_mass += support_mass
		chain_masses.append(support_mass)
		var blocker_name := blocker.name
		var targetable_ancestor: Node = blocker
		while targetable_ancestor != null:
			if targetable_ancestor is MistbornTargetable and targetable_ancestor != self:
				blocker_name = (targetable_ancestor as MistbornTargetable).display_name
				break
			targetable_ancestor = targetable_ancestor.get_parent()
		chain_names.append(blocker_name)

		excluded_rids.append(blocker.get_rid())
		chain_depth += 1

		# Static world geometry is already treated as effectively massive. There is
		# no gameplay value in traversing beyond it, and stopping prevents unrelated
		# geometry behind the world surface from entering the chain.
		if blocker is StaticBody3D:
			break

		var hit_position_variant: Variant = hit.get("position", current_start)
		if not hit_position_variant is Vector3:
			break
		var hit_position: Vector3 = hit_position_variant
		current_start = hit_position + direction * 0.03

	set_meta("allomantic_blocker_name", ", ".join(chain_names) if not chain_names.is_empty() else "NONE")
	set_meta("allomantic_blocker_mass", chain_masses.back() if not chain_masses.is_empty() else 0.0)
	set_meta("allomantic_blocker_chain_masses", chain_masses)
	set_meta("allomantic_blocker_chain_depth", chain_depth)
	return maxf(total_support_mass, 0.0)

func _get_body_effective_mass(body: PhysicsBody3D) -> float:
	if body == null or not is_instance_valid(body):
		return 0.0
	var ancestor: Node = body
	while ancestor != null:
		if ancestor is MistbornTargetable and ancestor != self:
			return (ancestor as MistbornTargetable).get_allomantic_mass()
		ancestor = ancestor.get_parent()
	if body is StaticBody3D:
		return FORCE_MODEL.STATIC_EFFECTIVE_MASS
	if body is RigidBody3D:
		var rigid := body as RigidBody3D
		return maxf(rigid.mass, 0.001)
	if body is CharacterBody3D:
		return FORCE_MODEL.PLAYER_MASS
	return 150.0

func get_allomantic_mass() -> float:
	if _physical_body != null and is_instance_valid(_physical_body):
		if _physical_body is RigidBody3D:
			var rigid := _physical_body as RigidBody3D
			if rigid.mass > 0.0:
				return rigid.mass
		if _physical_body is StaticBody3D:
			return FORCE_MODEL.STATIC_EFFECTIVE_MASS
	return FORCE_MODEL.effective_mass_from_profile(StringName(allomantic_profile), allomantic_visual_mass)

func get_allomantic_reaction_shares(actor: CharacterBody3D) -> Dictionary:
	var player_mass := FORCE_MODEL.PLAYER_MASS
	if actor != null and is_instance_valid(actor) and actor.has_method("get_gameplay_mass"):
		player_mass = maxf(float(actor.call("get_gameplay_mass")), 0.001)
	var target_mass := get_allomantic_mass()
	var player_receives := FORCE_MODEL.player_receives_response(player_mass, target_mass)
	return {
		"player_mass": player_mass,
		"target_mass": target_mass,
		"effective_target_mass": target_mass,
		"player_share": 1.0 if player_receives else 0.0,
		"target_share": 0.0 if player_receives else 1.0
	}

func execute_allomantic_action(action_name: StringName, actor: CharacterBody3D, delta: float) -> bool:
	return apply_allomantic_interaction(action_name, actor, delta)

func set_physical_body(body: PhysicsBody3D) -> void:
	_physical_body = body
	set_meta("allomantic_physical_body", body)
	if is_inside_tree():
		_build_sight_highlight()
		_set_visual_state()

func get_physical_body() -> PhysicsBody3D:
	return _physical_body if _physical_body != null and is_instance_valid(_physical_body) else null

func get_target_point() -> Vector3:
	return global_position

func get_debug_state() -> Dictionary:
	return {
		"id": target_id,
		"name": display_name,
		"type": target_type,
		"priority": selection_priority,
		"size_priority": target_size_priority,
		"height_priority": target_height_priority,
		"accessibility": target_accessibility,
		"selectable": selectable,
		"selected": _selected,
		"preview": _preview,
		"position": global_position,
		"is_metallic": is_metallic,
		"steel_pushable": steel_pushable,
		"iron_pullable": iron_pullable,
		"allomantic_profile": allomantic_profile,
		"allomantic_mass": get_allomantic_mass(),
		"blocked_by_support": bool(get_meta("allomantic_blocked_by_support", false)),
		"support_mass": float(get_meta("allomantic_support_mass", 0.0)),
		"effective_interaction_mass": float(get_meta("allomantic_effective_interaction_mass", get_allomantic_mass())),
		"blocker_name": str(get_meta("allomantic_blocker_name", "NONE")),
		"blocker_mass": float(get_meta("allomantic_blocker_mass", 0.0))
	}
