class_name MistbornTargetingController
extends Node

const FORCE_MODEL = preload("res://scripts/allomantic_force_model.gd")

const SIGHT_LINES_SHADER: Shader = preload("res://scripts/allomantic_sight_lines.gdshader")

signal target_lock_changed(locked: bool)

enum TargetingMode {
	EXPLORATION,
	TRAVERSAL
}

@export_category("Acquisition")
@export var max_target_distance: float = FORCE_MODEL.SHARED_RANGE
@export_range(0.10, 0.80, 0.01) var auto_screen_radius: float = 0.42
@export_range(10.0, 80.0, 1.0) var allomantic_use_cone_half_angle_degrees: float = 45.0
@export_range(30.0, 120.0, 1.0) var directional_acquisition_half_angle_degrees: float = 80.0
@export_range(0.30, 1.30, 0.01) var sight_screen_soft_limit: float = 1.05
@export var screen_weight: float = 10.0
@export var distance_weight: float = 0.42
@export var priority_weight: float = 0.58
@export var sticky_target_bonus: float = 1.80
@export var target_change_hysteresis: float = 0.52
@export var keep_current_target: bool = true
@export var action_target_lost_grace: float = 0.20
@export var focus_refresh_interval: float = 0.08
@export var line_refresh_interval: float = 0.08
@export_range(4.0, 40.0, 0.5) var line_origin_follow_sharpness: float = 24.0
@export_range(4.0, 40.0, 0.5) var line_target_follow_sharpness: float = 18.0
@export var lock_validation_interval: float = 0.08

@export_category("Context")
@export var targeting_mode: TargetingMode = TargetingMode.EXPLORATION
@export_range(0.0, 1.0, 0.01) var traversal_accessibility_weight: float = 0.24
@export_range(0.0, 8.0, 0.05) var grounded_action_direction_weight: float = 2.8

@export_category("Soft Lock")
@export var lock_uses_hold: bool = true
@export var lock_keeps_target_outside_reticle: bool = true

@export_category("Allomantic Sight")
@export var sight_uses_hold: bool = false
@export var sight_max_distance: float = FORCE_MODEL.SHARED_RANGE
@export_range(1, 4, 1) var sight_max_lines: int = 4
@export_range(0.06, 0.20, 0.01) var selected_line_width: float = 0.095
@export_range(1.0, 12.0, 0.1) var selected_line_glow: float = 8.5

var _player: CharacterBody3D
var _camera: Camera3D
var _current_target: MistbornTargetable
var _focus_target: MistbornTargetable
var _locked := false
var _sight_active := false
var _action_target: MistbornTargetable
var _action_active := false
var _allomantic_action_name: StringName = StringName("")
var _manual_cycle_suppression := 0.0
var _action_target_lost_left := 0.0
var _last_completed_action_target: MistbornTargetable
var _last_completed_action_name: StringName = StringName("")
var _last_candidate_count := 0
var _last_sight_count := 0
var _last_best_score: float = INF
var _focus_refresh_left := 0.0
var _line_refresh_left := 0.0
var _lock_validation_left := 0.0
var _target_cache_refresh_left := 0.0
const TARGET_CACHE_REFRESH_INTERVAL: float = 0.20
var _targetables_cache: Array = []
var _reticle_center_target: MistbornTargetable

var _sight_groups: Dictionary = {}
var _sight_line_targets_cache: Array[MistbornTargetable] = []
var _smoothed_line_origin: Vector3 = Vector3.ZERO
var _smoothed_line_origin_initialized: bool = false
var _smoothed_line_targets: Dictionary = {}
var _smoothed_line_sides: Dictionary = {}

func _ready() -> void:
	_player = get_parent() as CharacterBody3D
	_camera = _player.get_node_or_null("CameraRig/Camera3D") as Camera3D if _player != null else null
	_build_sight_line_groups()
	set_process(true)

func _process(delta: float) -> void:
	if _player == null or _camera == null:
		return
	_sanitize_target_references()
	_focus_refresh_left = maxf(_focus_refresh_left - delta, 0.0)
	_line_refresh_left = maxf(_line_refresh_left - delta, 0.0)
	_lock_validation_left = maxf(_lock_validation_left - delta, 0.0)
	_manual_cycle_suppression = maxf(_manual_cycle_suppression - delta, 0.0)
	_target_cache_refresh_left -= delta
	if _target_cache_refresh_left <= 0.0:
		_refresh_targetables_cache()
		_target_cache_refresh_left = TARGET_CACHE_REFRESH_INTERVAL

	if sight_uses_hold:
		_set_sight_active(Input.is_action_pressed("target_sight"))

	if Input.is_action_just_pressed("target_clear"):
		_clear_target()
		_set_locked(false)
		_manual_cycle_suppression = 0.45

	if Input.is_action_just_pressed("target_lock"):
		if _current_target == null:
			_refresh_focus(false)
		if _current_target != null:
			_set_locked(true)
		_manual_cycle_suppression = 0.30

	if lock_uses_hold and Input.is_action_just_released("target_lock"):
		_set_locked(false)

	if Input.is_action_just_pressed("target_sight") and not sight_uses_hold:
		_set_sight_active(not _sight_active)

	if Input.is_action_just_pressed("target_cycle_next"):
		_cycle_target(1)
	if Input.is_action_just_pressed("target_cycle_previous"):
		_cycle_target(-1)

	if _focus_refresh_left <= 0.0:
		_refresh_focus(_sight_active or _locked)
		_focus_refresh_left = focus_refresh_interval

	# Active Steel/Iron actions are fixed-target by contract. Input/camera changes
	# may shape the player's steering, but they never reacquire or replace the target
	# until the button is released.

	if _action_active:
		if _action_target != null and is_instance_valid(_action_target) and _is_fixed_action_target_valid(_action_target):
			_action_target_lost_left = action_target_lost_grace
			_set_target(_action_target)
		else:
			_action_target_lost_left = maxf(_action_target_lost_left - delta, 0.0)
			if _action_target_lost_left <= 0.0:
				end_all_action_targets()

	if not _locked and not _action_active and _manual_cycle_suppression <= 0.0:
		if _focus_target != null:
			_set_target(_focus_target)
		elif not _sight_active:
			_clear_target()

	if _locked and _lock_validation_left <= 0.0:
		var lock_valid := _is_locked_target_valid(_current_target) if lock_keeps_target_outside_reticle else _is_target_valid(_current_target, false)
		_lock_validation_left = lock_validation_interval
		if not lock_valid:
			_set_locked(false)
			_refresh_focus(_sight_active)
			_set_target(_focus_target)

	_update_preview_state()
	_update_sight_lines()

func _sanitize_target_references() -> void:
	# queue_free() invalidates Object references before our cache refresh interval.
	# Clear every long-lived target handle before any code can call a method on it.
	if _current_target != null and not is_instance_valid(_current_target):
		_current_target = null
		_locked = false
	if _focus_target != null and not is_instance_valid(_focus_target):
		_focus_target = null
	if _reticle_center_target != null and not is_instance_valid(_reticle_center_target):
		_reticle_center_target = null
	if _action_target != null and not is_instance_valid(_action_target):
		_action_target = null
		_action_active = false
	if _last_completed_action_target != null and not is_instance_valid(_last_completed_action_target):
		_last_completed_action_target = null
		_last_completed_action_name = StringName("")

func _refresh_focus(allow_sight_range: bool) -> void:
	var candidates := _collect_candidates(allow_sight_range)
	_last_candidate_count = candidates.size()
	_reticle_center_target = _find_reticle_center_target(candidates)
	var best_target := _best_from(candidates)
	_focus_target = _apply_target_hysteresis(best_target, candidates)
	_last_best_score = _score_target(_focus_target) if _focus_target != null else INF
	if _sight_active or _locked:
		_last_sight_count = _collect_sight_line_targets().size()

func _refresh_targetables_cache() -> void:
	_targetables_cache.clear()
	for node in get_tree().get_nodes_in_group("mistborn_targetable"):
		# A node can disappear between group enumeration and use. Never cast a
		# potentially freed object; validate the raw Variant first.
		if not is_instance_valid(node):
			continue
		if node is MistbornTargetable:
			_targetables_cache.append(node)

func _get_targetables() -> Array[MistbornTargetable]:
	var valid_targets: Array[MistbornTargetable] = []
	for candidate in _targetables_cache:
		# queue_free() leaves the reference in an ordinary Array until the next
		# cache refresh. Validate before attempting the typed cast.
		if not is_instance_valid(candidate):
			continue
		var target := candidate as MistbornTargetable
		if target == null or not is_instance_valid(target):
			continue
		valid_targets.append(target)

	# If stale entries were found, keep the cache clean so future calls do not
	# repeatedly encounter the same dead references.
	_targetables_cache = valid_targets
	if valid_targets.is_empty():
		_refresh_targetables_cache()
		_target_cache_refresh_left = TARGET_CACHE_REFRESH_INTERVAL
		for candidate in _targetables_cache:
			if not is_instance_valid(candidate):
				continue
			var target := candidate as MistbornTargetable
			if target != null and is_instance_valid(target):
				valid_targets.append(target)
		_targetables_cache = valid_targets
	return valid_targets

func _collect_candidates(allow_sight_range: bool) -> Array[MistbornTargetable]:
	var ranked: Array[MistbornTargetable] = []
	var context := _get_effective_targeting_mode()
	var acquisition_action := _get_current_allomantic_input_action()
	var use_cone_active := not _action_active and (acquisition_action == &"steel" or acquisition_action == &"iron") and (Input.is_action_pressed("steel_push") or Input.is_action_pressed("iron_pull") or Input.is_action_pressed("iron_yank"))
	for target: MistbornTargetable in _get_targetables():
		if target == null or not is_instance_valid(target):
			continue
		if not _is_target_valid(target, allow_sight_range, true, acquisition_action):
			continue
		if use_cone_active and not _is_allomantic_use_cone_valid(target, acquisition_action):
			continue
		if context == TargetingMode.TRAVERSAL and not _is_traversal_candidate_accessible(target):
			continue
		# On the ground, movement input is steering intent, not a hard gate.
		# Air traversal may use the stricter accessibility filter. This keeps
		# Iron/Steel reliable even when the player is simply looking at a target.
		if not _player.is_on_floor() and not _is_current_allomantic_input_directionally_compatible(target):
			continue
		ranked.append(target)
	ranked.sort_custom(_target_sort)
	var limit := sight_max_lines if allow_sight_range else 12
	if ranked.size() > limit:
		ranked.resize(limit)
	return ranked

func _collect_sight_candidates() -> Array[MistbornTargetable]:
	var result: Array[MistbornTargetable] = []
	for target: MistbornTargetable in _get_targetables():
		if target == null or not is_instance_valid(target):
			continue
		if _is_sight_valid(target):
			result.append(target)
	result.sort_custom(_target_sort)
	if result.size() > sight_max_lines:
		result.resize(sight_max_lines)
	return result

func _collect_sight_line_targets() -> Array[MistbornTargetable]:
	# Sight has a hard four-line budget. The active target may be visually
	# promoted, but it must occupy one of those slots instead of creating a
	# fifth line. This keeps the roadmap's 4-line cap true at runtime.
	var result := _collect_sight_candidates()
	if _current_target == null or not is_instance_valid(_current_target):
		return result

	var current_valid := _is_sight_valid(_current_target)
	if not current_valid and _action_active:
		current_valid = _is_action_target_valid(_current_target) and _current_target.show_in_allomantic_sight and _current_target.is_metallic
	if not current_valid:
		return result

	if result.has(_current_target):
		return result

	if result.size() >= sight_max_lines:
		result.resize(maxi(sight_max_lines - 1, 0))
	result.append(_current_target)
	return result

func _target_sort(a: MistbornTargetable, b: MistbornTargetable) -> bool:
	return _score_target(a) < _score_target(b)

func _screen_metrics(point: Vector3) -> Dictionary:
	var viewport_size := _camera.get_viewport().get_visible_rect().size
	if viewport_size.x <= 1.0 or viewport_size.y <= 1.0:
		return {"valid": false}
	var center := viewport_size * 0.5
	var screen_position := _camera.unproject_position(point)
	var normalized := center.distance_to(screen_position) / minf(viewport_size.x, viewport_size.y)
	return {"valid": true, "normalized": normalized, "position": screen_position, "center": center}

func _is_target_valid(target: MistbornTargetable, allow_sight_range: bool, check_line_of_sight: bool = true, requested_action_name: StringName = StringName("")) -> bool:
	if target == null or not is_instance_valid(target) or not target.selectable or not target.is_metallic:
		return false
	var point := target.get_target_point()
	var distance := _player.global_position.distance_to(point)
	var allowed_range := max_target_distance
	if target.max_range_override > 0.0:
		allowed_range = target.max_range_override if allowed_range <= 0.0 else minf(allowed_range, target.max_range_override)
	if allowed_range > 0.0 and distance > allowed_range:
		return false
	var action_name := requested_action_name if requested_action_name == &"steel" or requested_action_name == &"iron" else _get_current_allomantic_input_action()
	var directional_traversal := _is_directional_traversal_acquisition(action_name)
	# Directional traversal is intentionally not camera-frustum limited. A target may
	# be behind or outside the viewport when its allomantic reaction matches the
	# player's desired horizontal travel direction. The camera remains a tie-breaker
	# in the traversal ranking, not a hard eligibility gate.
	if not directional_traversal and _camera.is_position_behind(point):
		return false
	if not directional_traversal:
		var metrics := _screen_metrics(point)
		if not metrics.get("valid", false):
			return false
		var normalized: float = metrics["normalized"]
		if allow_sight_range:
			if normalized > sight_screen_soft_limit:
				return false
		else:
			if normalized > auto_screen_radius:
				return false
	if check_line_of_sight and target.requires_line_of_sight and not _has_line_of_sight(target, point):
		return false
	return true

func _is_allomantic_use_cone_valid(target: MistbornTargetable, action_name: StringName = StringName("")) -> bool:
	if _player == null or _camera == null or target == null or not is_instance_valid(target):
		return false
	var action := action_name
	if action != &"steel" and action != &"iron":
		action = _get_current_allomantic_input_action()
	if action != &"steel" and action != &"iron":
		return false

	# During directional traversal, the acquisition cone is built entirely in the
	# horizontal plane from PLAYER INPUT -> PLAYER REACTION. It does not use camera
	# pitch, target height, or vertical velocity. This is what allows a target behind
	# the player to be selected when pushing/pulling it still advances the desired
	# horizontal travel direction.
	if _has_directional_input():
		var desired := _get_desired_travel_direction()
		var reaction := target.get_allomantic_player_reaction_direction(action, _player)
		var desired_flat := Vector3(desired.x, 0.0, desired.z)
		var reaction_flat := Vector3(reaction.x, 0.0, reaction.z)
		if desired_flat.length_squared() <= 0.0001 or reaction_flat.length_squared() <= 0.0001:
			return true
		var dot := clampf(desired_flat.normalized().dot(reaction_flat.normalized()), -1.0, 1.0)
		var limit := cos(deg_to_rad(directional_acquisition_half_angle_degrees))
		return dot + 0.0001 >= limit

	# Without explicit travel input, preserve look-led acquisition. The normal camera
	# cone remains a deliberate usability filter for grounded/free-look selection.
	var point: Vector3 = target.get_allomantic_action_point(action, _player.global_position, _player.is_on_floor())
	var cone_direction := point - _camera.global_position
	if cone_direction.length_squared() <= 0.0001:
		return true
	var forward := -_camera.global_transform.basis.z
	forward.y = 0.0
	if forward.length_squared() <= 0.0001:
		return false
	var dot := clampf(forward.normalized().dot(Vector3(cone_direction.x, 0.0, cone_direction.z).normalized()), -1.0, 1.0)
	var limit := cos(deg_to_rad(allomantic_use_cone_half_angle_degrees))
	return dot + 0.0001 >= limit

static func _is_direction_within_cone(forward: Vector3, to_target: Vector3, half_angle_degrees: float) -> bool:
	if forward.length_squared() <= 0.0001 or to_target.length_squared() <= 0.0001:
		return false
	var dot := clampf(forward.normalized().dot(to_target.normalized()), -1.0, 1.0)
	return dot + 0.0001 >= cos(deg_to_rad(half_angle_degrees))

func _is_sight_valid(target: MistbornTargetable) -> bool:
	if target == null or not is_instance_valid(target) or not target.show_in_allomantic_sight:
		return false
	if target.get_allomantic_profile() == "DECORATIVE":
		return false
	# Sight only reveals metal that the player could actually use right now.
	# That means the same range, screen, orientation and occlusion rules used by
	# the live action targeter. A metal buried behind a building therefore stays
	# invisible instead of becoming a useless wall-penetrating marker.
	if not target.selectable or not target.is_metallic:
		return false
	if not target.steel_pushable and not target.iron_pullable:
		return false
	return _is_target_valid(target, true, true)

func _is_action_target_valid(target: MistbornTargetable, requested_action_name: StringName = StringName("")) -> bool:
	if target == null or not is_instance_valid(target) or not target.selectable or not target.is_metallic:
		return false
	var action_name := requested_action_name if requested_action_name == &"steel" or requested_action_name == &"iron" else _get_current_allomantic_input_action()
	if action_name == &"steel" and not target.steel_pushable:
		return false
	if action_name == &"iron" and not target.iron_pullable:
		return false
	if _player != null and not _player.is_on_floor() and not _is_current_allomantic_input_directionally_compatible(target):
		return false
	var point := target.get_target_point()
	var distance := _camera.global_position.distance_to(point)
	var allowed_range := max_target_distance
	if target.max_range_override > 0.0:
		allowed_range = target.max_range_override if allowed_range <= 0.0 else minf(allowed_range, target.max_range_override)
	if allowed_range > 0.0 and distance > allowed_range:
		return false
	var steel_forward_traversal := action_name == &"steel" and _has_directional_input()
	if not steel_forward_traversal and _camera.is_position_behind(point):
		return false
	return not target.requires_line_of_sight or _has_line_of_sight(target, point)

func _is_locked_target_valid(target: MistbornTargetable) -> bool:
	return _is_action_target_valid(target)

func _has_line_of_sight(target: MistbornTargetable, point: Vector3) -> bool:
	if _player == null:
		return false
	var world_3d: World3D = _player.get_world_3d()
	if world_3d == null:
		return false
	var query := PhysicsRayQueryParameters3D.create(_camera.global_position, point)
	query.collision_mask = 1 | 2
	query.collide_with_bodies = true
	query.collide_with_areas = true
	query.exclude = [_player.get_rid()]
	var hit := world_3d.direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return true
	var collider: Variant = hit.get("collider")
	if collider == target:
		return true
	if collider is Node and target.has_meta("allomantic_physical_body"):
		return collider == target.get_meta("allomantic_physical_body")
	if collider is Node and target.is_ancestor_of(collider):
		return true
	return false

func _find_reticle_center_target(candidates: Array[MistbornTargetable]) -> MistbornTargetable:
	var best: MistbornTargetable = null
	var best_distance: float = INF
	for target: MistbornTargetable in candidates:
		if target == null or not is_instance_valid(target):
			continue
		var metrics := _screen_metrics(target.get_target_point())
		if not metrics.get("valid", false):
			continue
		var normalized: float = metrics["normalized"]
		if normalized > 0.06:
			continue
		if normalized < best_distance:
			best_distance = normalized
			best = target
	return best

func _get_reticle_center_target() -> MistbornTargetable:
	return _reticle_center_target if _reticle_center_target != null and is_instance_valid(_reticle_center_target) else null

func _score_target(target: MistbornTargetable) -> float:
	if target == null or not is_instance_valid(target) or _camera == null:
		return INF
	var metrics := _screen_metrics(target.get_target_point())
	if not metrics.get("valid", false):
		return INF
	var context := _get_effective_targeting_mode()
	var normalized: float = metrics["normalized"]
	var distance := _camera.global_position.distance_to(target.get_target_point())
	var distance_ratio := distance / maxf(max_target_distance, 0.001)
	var score := normalized * screen_weight + distance_ratio * distance_weight
	score -= target.selection_priority * priority_weight
	score -= target.target_accessibility * (traversal_accessibility_weight if context == TargetingMode.TRAVERSAL else 0.16)
	score -= target.target_size_priority * (0.20 if context == TargetingMode.TRAVERSAL else 0.10)
	score -= _get_context_priority(target, context) * 0.45
	if context == TargetingMode.TRAVERSAL:
		score -= _get_directional_accessibility(target) * 8.0
	elif _player != null and _player.is_on_floor() and (_get_current_allomantic_input_action() == &"steel" or _get_current_allomantic_input_action() == &"iron") and _has_directional_input():
		score -= _get_directional_accessibility(target) * grounded_action_direction_weight
	if target == _current_target:
		score -= sticky_target_bonus
	var reticle_target := _get_reticle_center_target()
	if target == reticle_target:
		score -= 2.25
	return score

func _get_context_priority(target: MistbornTargetable, context: TargetingMode = TargetingMode.EXPLORATION) -> float:
	match context:
		TargetingMode.EXPLORATION:
			match target.target_type:
				"ANCHOR": return 1.00
				"COIN": return 0.0
				"METAL_OBJECT": return 0.25
		TargetingMode.TRAVERSAL:
			match target.target_type:
				"ANCHOR": return 1.40
				"COIN": return 0.0
				"METAL_OBJECT": return 0.12
	return 0.0

func _get_effective_targeting_mode() -> TargetingMode:
	if _player == null:
		return targeting_mode
	if not _player.is_on_floor():
		return TargetingMode.TRAVERSAL
	return TargetingMode.EXPLORATION

func _get_desired_travel_direction() -> Vector3:
	if _player == null or _camera == null:
		return Vector3.ZERO
	var input_vec := Input.get_vector("move_left", "move_right", "move_forward", "move_backward")
	if input_vec.length_squared() > 0.01:
		var basis := _camera.global_transform.basis
		var direction := basis * Vector3(input_vec.x, 0.0, input_vec.y)
		direction.y = 0.0
		if direction.length_squared() > 0.001:
			return direction.normalized()
	var velocity := Vector3(_player.velocity.x, 0.0, _player.velocity.z)
	if velocity.length_squared() > 4.0:
		return velocity.normalized()
	var forward := -_camera.global_transform.basis.z
	forward.y = 0.0
	return forward.normalized() if forward.length_squared() > 0.001 else Vector3.FORWARD

func _is_directional_traversal_acquisition(action_name: StringName = StringName("")) -> bool:
	if _player == null or _player.is_on_floor() or not _has_directional_input():
		return false
	var action := action_name
	if action != &"steel" and action != &"iron":
		action = _get_current_allomantic_input_action()
	return action == &"steel" or action == &"iron"

func _has_directional_input() -> bool:
	return Input.get_vector("move_left", "move_right", "move_forward", "move_backward").length_squared() > 0.01

func _get_current_allomantic_input_action() -> StringName:
	var iron_down := Input.is_action_pressed("iron_pull") or Input.is_action_pressed("iron_yank")
	if Input.is_action_pressed("steel_push") and not iron_down:
		return &"steel"
	if iron_down and not Input.is_action_pressed("steel_push"):
		return &"iron"
	return _allomantic_action_name

func _is_current_allomantic_input_directionally_compatible(target: MistbornTargetable) -> bool:
	if target == null or not is_instance_valid(target):
		return false
	var action_name := _get_current_allomantic_input_action()
	if action_name != &"steel" and action_name != &"iron":
		return true
	if not _has_directional_input():
		return true
	var desired := _get_desired_travel_direction()
	if desired.length_squared() <= 0.001:
		return true
	var action_direction := _get_action_direction_for_target(target, action_name)
	if action_direction.length_squared() <= 0.001:
		return false
	return _is_reaction_forward_or_neutral(desired, action_direction)

static func _horizontal_alignment(desired: Vector3, reaction_direction: Vector3) -> float:
	var desired_flat := Vector3(desired.x, 0.0, desired.z)
	var reaction_flat := Vector3(reaction_direction.x, 0.0, reaction_direction.z)
	if desired_flat.length_squared() <= 0.001 or reaction_flat.length_squared() <= 0.001:
		return 0.0
	return clampf(desired_flat.normalized().dot(reaction_flat.normalized()), -1.0, 1.0)

static func _is_reaction_forward_or_neutral(desired: Vector3, reaction_direction: Vector3) -> bool:
	var reaction_flat := Vector3(reaction_direction.x, 0.0, reaction_direction.z)
	if reaction_flat.length_squared() <= 0.001:
		# A purely vertical reaction neither advances nor moves the player backwards.
		return true
	return _horizontal_alignment(desired, reaction_direction) >= 0.0

func _get_action_direction_for_target(target: MistbornTargetable, action_name: StringName) -> Vector3:
	if _player == null or target == null or not is_instance_valid(target):
		return Vector3.ZERO
	return target.get_allomantic_player_reaction_direction(action_name, _player)

func _get_traversal_intent_action_score(target: MistbornTargetable, desired: Vector3, action_name: StringName) -> Dictionary:
	var action_direction: Vector3 = _get_action_direction_for_target(target, action_name)
	if action_direction.length_squared() <= 0.001 or desired.length_squared() <= 0.001:
		return {"alignment": -1.0, "intent_alignment": -1.0, "screen": INF, "distance": INF, "hard_compatible": false, "score": INF}
	action_direction = action_direction.normalized()
	var hard_compatible: bool = _is_reaction_forward_or_neutral(desired, action_direction)
	# Target acquisition is purely horizontal for BOTH Steel and Iron. Vertical
	# gameplay assists happen only after target selection and never change which metal
	# wins the traversal ranking.
	var intent_alignment := _horizontal_alignment(desired, action_direction)
	var point: Vector3 = target.get_allomantic_action_point(action_name, _player.global_position, _player.is_on_floor())
	var metrics := _screen_metrics(point)
	var screen_score: float = float(metrics.get("normalized", 9.0)) if metrics.get("valid", false) else INF
	var distance: float = _player.global_position.distance_to(point)
	# Vertical movement is completely absent from target acquisition. The target's
	# height, vertical reaction, and player velocity.y cannot improve or worsen its
	# directional score. Any vertical gameplay assist occurs only after selection.
	var score: float = -intent_alignment * 8.0 + screen_score * 1.5 + distance * 0.035 - target.selection_priority * 0.40
	return {"alignment": intent_alignment, "intent_alignment": intent_alignment, "screen": screen_score, "distance": distance, "hard_compatible": hard_compatible, "score": score}

func _sort_traversal_ranked(a: Dictionary, b: Dictionary) -> bool:
	# Traversal target selection is hierarchical, but vertical motion is deliberately
	# NOT a ranking tier. The mechanical vertical assist operates only after the target
	# has already been chosen.
	# 1) hard-discard reactions that move backwards;
	# 2) maximize horizontal directional travel intent;
	# 3) screen readability (tie-break only; off-screen targets remain eligible);
	# 4) shorter distance;
	# 5) authored target priority/accessibility as tie-breakers.
	var aa := a.get("info", {}) as Dictionary
	var bb := b.get("info", {}) as Dictionary
	var a_alignment: float = float(aa.get("intent_alignment", aa.get("alignment", -1.0)))
	var b_alignment: float = float(bb.get("intent_alignment", bb.get("alignment", -1.0)))
	if not is_equal_approx(a_alignment, b_alignment):
		return a_alignment > b_alignment
	var a_screen: float = float(aa.get("screen", INF))
	var b_screen: float = float(bb.get("screen", INF))
	if not is_equal_approx(a_screen, b_screen):
		return a_screen < b_screen
	var a_distance: float = float(aa.get("distance", INF))
	var b_distance: float = float(bb.get("distance", INF))
	if not is_equal_approx(a_distance, b_distance):
		return a_distance < b_distance
	var a_target := a.get("target") as MistbornTargetable
	var b_target := b.get("target") as MistbornTargetable
	if a_target == null or b_target == null:
		return a_target != null
	if not is_equal_approx(a_target.selection_priority, b_target.selection_priority):
		return a_target.selection_priority > b_target.selection_priority
	return a_target.target_accessibility > b_target.target_accessibility

func _build_traversal_ranked_candidates(candidates: Array[MistbornTargetable], desired: Vector3, action_name: StringName) -> Array[MistbornTargetable]:
	var ranked: Array[Dictionary] = []
	for target: MistbornTargetable in candidates:
		if target == null or not is_instance_valid(target):
			continue
		var info: Dictionary = _get_traversal_intent_action_score(target, desired, action_name)
		if not bool(info.get("hard_compatible", false)):
			continue
		ranked.append({"target": target, "score": float(info.get("score", INF)), "info": info})
	ranked.sort_custom(_sort_traversal_ranked)
	var result: Array[MistbornTargetable] = []
	for item: Dictionary in ranked:
		var target := item.get("target") as MistbornTargetable
		if target != null and is_instance_valid(target):
			result.append(target)
	return result

func _select_best_traversal_target_for_intent(candidates: Array[MistbornTargetable], desired: Vector3, action_name: StringName, current: MistbornTargetable = null) -> MistbornTargetable:
	var ranked := _build_traversal_ranked_candidates(candidates, desired, action_name)
	if not ranked.is_empty():
		return ranked[0]
	if current != null and is_instance_valid(current):
		var current_info: Dictionary = _get_traversal_intent_action_score(current, desired, action_name)
		if bool(current_info.get("hard_compatible", false)):
			return current
	return null

func _update_active_traversal_target_from_intent() -> void:
	# Legacy compatibility hook intentionally disabled: active actions are fixed-target.
	return

func best_alignment_for_target(target: MistbornTargetable, desired: Vector3, action_name: StringName) -> float:
	return float(_get_traversal_intent_action_score(target, desired, action_name).get("alignment", -1.0))

func _get_allomantic_action_direction(target: MistbornTargetable) -> Vector3:
	if Input.is_action_pressed("steel_push") and not Input.is_action_pressed("iron_pull"):
		return _get_action_direction_for_target(target, &"steel")
	if (Input.is_action_pressed("iron_pull") or Input.is_action_pressed("iron_yank")) and not Input.is_action_pressed("steel_push"):
		return _get_action_direction_for_target(target, &"iron")
	return _get_action_direction_for_target(target, _allomantic_action_name)

func _get_directional_accessibility(target: MistbornTargetable) -> float:
	var desired := _get_desired_travel_direction()
	var delta := _get_allomantic_action_direction(target)
	if desired.length_squared() <= 0.001 or delta.length_squared() <= 0.001:
		return 0.0
	# Directional accessibility is a pure horizontal-travel signal for both metals.
	# The target's vertical reaction never participates in acquisition priority.
	return _horizontal_alignment(desired, delta)

func _is_traversal_candidate_accessible(target: MistbornTargetable, action_name: StringName = StringName("")) -> bool:
	if target == null or not is_instance_valid(target):
		return false
	if action_name != &"steel" and action_name != &"iron":
		action_name = _get_current_allomantic_input_action()
	if target.target_type != "ANCHOR" and target.target_type != "COIN" and target.target_type != "METAL_OBJECT":
		return false
	if action_name == &"steel" and not target.steel_pushable:
		return false
	if action_name == &"iron" and not target.iron_pullable:
		return false
	if not _action_active and not _is_allomantic_use_cone_valid(target, action_name):
		return false
	if _has_directional_input():
		var desired := _get_desired_travel_direction()
		var reaction := _get_action_direction_for_target(target, action_name)
		if not _is_reaction_forward_or_neutral(desired, reaction):
			return false
	return true

func _collect_traversal_candidates(action_name: StringName = StringName("")) -> Array[MistbornTargetable]:
	if action_name != &"steel" and action_name != &"iron":
		action_name = _get_current_allomantic_input_action()
	var result: Array[MistbornTargetable] = []
	for target: MistbornTargetable in _get_targetables():
		if target == null or not is_instance_valid(target):
			continue
		if not target.selectable or not target.is_metallic:
			continue
		if action_name != &"steel" and action_name != &"iron":
			continue
		if not _is_traversal_candidate_accessible(target, action_name):
			continue
		if not _is_action_target_valid(target, action_name):
			continue
		result.append(target)
	return result

func get_traversal_recovery_target(max_distance: float = 24.0, _screen_radius: float = 0.62) -> MistbornTargetable:
	if _player == null or _camera == null:
		return null
	var action_name := _get_current_allomantic_input_action()
	if action_name != &"steel" and action_name != &"iron":
		return null
	var candidates := _collect_traversal_candidates(action_name)
	var desired := _get_desired_travel_direction()
	if desired.length_squared() <= 0.001:
		return null
	var local_candidates: Array[MistbornTargetable] = []
	for target: MistbornTargetable in candidates:
		var point := target.get_target_point()
		var distance := _player.global_position.distance_to(point)
		if distance <= 0.75 or distance > max_distance:
			continue
		# Recovery is still directional traversal: do not discard a valid target merely
		# because its marker is outside the viewport. The ranking below still uses
		# screen position as a tie-breaker.
		local_candidates.append(target)
	var best := _select_best_traversal_target_for_intent(local_candidates, desired, action_name)
	if best != null:
		_set_target(best)
	return best

func _best_from(candidates: Array[MistbornTargetable]) -> MistbornTargetable:
	return candidates[0] if not candidates.is_empty() else null

func _apply_target_hysteresis(best_target: MistbornTargetable, candidates: Array[MistbornTargetable]) -> MistbornTargetable:
	if _get_effective_targeting_mode() == TargetingMode.TRAVERSAL and _has_directional_input():
		return best_target
	if best_target == null or _current_target == null or not is_instance_valid(_current_target):
		return best_target
	if best_target == _current_target:
		return _current_target
	if not keep_current_target or not candidates.has(_current_target):
		return best_target
	var best_score := _score_target(best_target)
	var current_score := _score_target(_current_target)
	return _current_target if best_score + target_change_hysteresis >= current_score else best_target

func get_next_traversal_target(current: MistbornTargetable) -> MistbornTargetable:
	if not _has_directional_input():
		return null
	var desired := _get_desired_travel_direction()
	if desired.length_squared() <= 0.001:
		return null
	var action_name := _allomantic_action_name
	if action_name != &"steel" and action_name != &"iron":
		if Input.is_action_pressed("steel_push") and not Input.is_action_pressed("iron_pull"):
			action_name = &"steel"
		elif (Input.is_action_pressed("iron_pull") or Input.is_action_pressed("iron_yank")) and not Input.is_action_pressed("steel_push"):
			action_name = &"iron"
		else:
			return null
	var candidates := _collect_traversal_candidates(action_name)
	if candidates.is_empty():
		return null
	return _select_best_traversal_target_for_intent(candidates, desired, action_name, current)

func set_traversal_action_target(target: MistbornTargetable) -> bool:
	if target == null or not is_instance_valid(target):
		return false
	var action_name := _get_current_allomantic_input_action()
	if action_name != &"steel" and action_name != &"iron":
		action_name = _allomantic_action_name
	if action_name == &"steel" or action_name == &"iron":
		if not _is_traversal_candidate_accessible(target, action_name) or not _is_action_target_valid(target, action_name):
			return false
		if not _is_allomantic_use_cone_valid(target, action_name):
			return false
	_action_active = true
	_action_target = target
	_set_target(target)
	_action_target_lost_left = action_target_lost_grace
	_allomantic_action_name = action_name
	return true

func _cycle_target(direction: int) -> void:
	var traversal_mode := _get_effective_targeting_mode() == TargetingMode.TRAVERSAL or (_player != null and not _player.is_on_floor())
	var candidates: Array[MistbornTargetable]
	if traversal_mode:
		# A discrete Steel/Iron impulse owns its target until release. Cycling while
		# the button is held would silently violate that contract.
		if _action_active:
			return
		var action_name := _get_current_allomantic_input_action()
		if action_name != &"steel" and action_name != &"iron":
			action_name = _allomantic_action_name
		if action_name != &"steel" and action_name != &"iron":
			return
		candidates = _collect_traversal_candidates(action_name)
		var desired := _get_desired_travel_direction()
		if desired.length_squared() > 0.001:
			candidates = _build_traversal_ranked_candidates(candidates, desired, action_name)
	elif _sight_active:
		candidates = _collect_sight_candidates()
	else:
		candidates = _collect_candidates(false)
	if candidates.is_empty():
		_clear_target()
		return
	var current_index := candidates.find(_current_target)
	var selected: MistbornTargetable = candidates[0] if current_index < 0 else candidates[posmod(current_index + direction, candidates.size())]
	if _action_active and traversal_mode:
		_action_target = selected
		_action_target_lost_left = action_target_lost_grace
	_set_target(selected)
	_manual_cycle_suppression = 0.65

func _set_target(target: MistbornTargetable) -> void:
	if target != null and not is_instance_valid(target):
		target = null
	if _current_target != null and not is_instance_valid(_current_target):
		_current_target = null
	if target == _current_target:
		if target != null and is_instance_valid(target):
			target.set_selected(true)
		return
	if _current_target != null and is_instance_valid(_current_target):
		_current_target.set_selected(false)
	_current_target = target
	if _current_target != null:
		_current_target.set_selected(true)

func _clear_target() -> void:
	if _current_target != null and is_instance_valid(_current_target):
		_current_target.set_selected(false)
	_current_target = null

func _set_locked(value: bool) -> void:
	if _locked == value:
		return
	_locked = value
	target_lock_changed.emit(_locked)

func _set_sight_active(value: bool) -> void:
	if _sight_active == value:
		return
	_sight_active = value
	if not value:
		for target: MistbornTargetable in _get_targetables():
			if target == null or not is_instance_valid(target):
				continue
			target.set_preview(false)
			target.set_allomantic_sight_active(false)
		# The active action line belongs to this same renderer and remains visible
		# while Steel/Iron is held. Only the non-active Sight links clear.
		if not _action_active:
			_clear_sight_line_meshes()

func _update_preview_state() -> void:
	if not _sight_active:
		return
	var visible_ids := {}
	for target: MistbornTargetable in _collect_sight_candidates():
		visible_ids[target.get_instance_id()] = true
	for target: MistbornTargetable in _get_targetables():
		if target == null or not is_instance_valid(target):
			continue
		target.set_allomantic_sight_active(true)
		target.set_preview(visible_ids.has(target.get_instance_id()) and target != _current_target)

func _build_sight_line_groups() -> void:
	# One renderer owns every Allomantic link in the game. The selected action
	# target uses the same Sight shader and geometry path, but is promoted visually
	# instead of spawning a second Steel/Iron-specific line.
	var definitions := {
		# Sight links stay intentionally restrained. The active link is not larger;
		# it is separated mainly by contrast and emission.
		"ANCHOR": {"color": Color(0.16, 0.58, 1.0, 0.72), "width": 0.095, "glow": 2.5},
		"CHARACTER": {"color": Color(0.20, 0.62, 1.0, 0.64), "width": 0.088, "glow": 2.2},
		"PROJECTILE": {"color": Color(0.25, 0.66, 1.0, 0.58), "width": 0.080, "glow": 2.0},
		"SMALL_OBJECT": {"color": Color(0.22, 0.58, 0.94, 0.50), "width": 0.074, "glow": 1.8},
		"DECORATIVE": {"color": Color(0.18, 0.48, 0.86, 0.34), "width": 0.066, "glow": 1.5},
		"ACTIVE": {"color": Color(0.10, 0.66, 1.0, 1.0), "width": selected_line_width, "glow": selected_line_glow}
	}
	for profile in definitions.keys():
		var mesh := ArrayMesh.new()
		var instance := MeshInstance3D.new()
		instance.name = "SightLines_" + profile
		instance.mesh = mesh
		instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		instance.gi_mode = GeometryInstance3D.GI_MODE_DISABLED
		var material := ShaderMaterial.new()
		material.shader = SIGHT_LINES_SHADER
		material.set_shader_parameter("sight_color", definitions[profile]["color"])
		material.set_shader_parameter("glow_strength", definitions[profile]["glow"])
		instance.material_override = material
		instance.visible = false
		add_child(instance)
		_sight_groups[profile] = {"mesh": mesh, "instance": instance, "material": material, "width": definitions[profile]["width"]}

func _clear_sight_line_meshes() -> void:
	for key in _sight_groups.keys():
		_sight_groups[key]["mesh"].clear_surfaces()
		_sight_groups[key]["instance"].visible = false

func _get_sight_profile_weight(target: MistbornTargetable) -> float:
	match target.get_allomantic_profile():
		"ANCHOR": return 1.00
		"CHARACTER": return 0.88
		"PROJECTILE": return 0.72
		"SMALL_OBJECT": return 0.58
		"DECORATIVE": return 0.40
	return 0.50

func _get_sight_occlusion_factor(target: MistbornTargetable) -> float:
	if target == null or not is_instance_valid(target):
		return 0.0
	if not target.requires_line_of_sight:
		return 0.0
	return 0.28 if not _has_line_of_sight(target, target.get_allomantic_visual_point()) else 0.0

func _append_sight_line(vertices: PackedVector3Array, uvs: PackedVector2Array, colors: PackedColorArray, indices: PackedInt32Array, a: Vector3, b: Vector3, width: float, tint: Color, line_key: int = -1) -> int:
	var axis := b - a
	var length := axis.length()
	if length <= 0.01:
		return 0
	axis /= length

	# Keep the ribbon straight, but preserve its roll from frame to frame. The previous
	# version switched abruptly between world-up/world-right near vertical links; that
	# made the line visibly snap even when its endpoints moved smoothly. Project the
	# previous side onto the new perpendicular plane and blend toward it.
	var side := Vector3.ZERO
	if line_key >= 0 and _smoothed_line_sides.has(line_key):
		var previous_side: Vector3 = _smoothed_line_sides[line_key] as Vector3
		var projected := previous_side - axis * previous_side.dot(axis)
		if projected.length_squared() > 0.0001:
			side = projected.normalized()
	if side.length_squared() <= 0.0001:
		var reference := Vector3.UP
		if abs(axis.dot(reference)) > 0.985:
			reference = Vector3.RIGHT
		side = axis.cross(reference)
		if side.length_squared() <= 0.0001:
			side = axis.cross(Vector3.FORWARD)
		side = side.normalized()
	if line_key >= 0:
		_smoothed_line_sides[line_key] = side

	var half_width := width * 0.5
	var base := vertices.size()
	vertices.append(a - side * half_width)
	vertices.append(a + side * half_width)
	vertices.append(b + side * half_width)
	vertices.append(b - side * half_width)
	uvs.append(Vector2(0.0, 0.0))
	uvs.append(Vector2(0.0, 1.0))
	uvs.append(Vector2(1.0, 1.0))
	uvs.append(Vector2(1.0, 0.0))
	colors.append(tint); colors.append(tint); colors.append(tint); colors.append(tint)
	indices.append(base); indices.append(base+1); indices.append(base+2)
	indices.append(base); indices.append(base+2); indices.append(base+3)
	return 4

func _get_sight_origin() -> Vector3:
	# Rendered Allomantic lines originate at the chest. The force solver retains its
	# separate waist/center origin in PlayerController.get_allomantic_origin().
	if _player != null and _player.has_method("get_allomantic_line_origin"):
		return _player.call("get_allomantic_line_origin") as Vector3
	return _player.global_position + Vector3.UP * 1.34

func _get_sight_line_target_point(target: MistbornTargetable) -> Vector3:
	if target == null or not is_instance_valid(target):
		return Vector3.ZERO
	if target == _action_target and _action_active and target.has_meta("allomantic_active_line_endpoint"):
		var endpoint: Variant = target.get_meta("allomantic_active_line_endpoint")
		if endpoint is Vector3:
			return endpoint as Vector3
	return target.get_allomantic_visual_point()

func _smooth_line_target(target: MistbornTargetable) -> Vector3:
	var raw_point: Vector3 = _get_sight_line_target_point(target)
	var key: int = target.get_instance_id()
	if not _smoothed_line_targets.has(key):
		_smoothed_line_targets[key] = raw_point
		return raw_point
	# While physically tethered, keep the rendered endpoint on the same actual
	# attachment point used by the constraint; smoothing it independently looks like
	# the cable is sliding over the anchor surface.
	if target == _action_target and target.has_meta("allomantic_active_line_endpoint"):
		_smoothed_line_targets[key] = raw_point
		return raw_point
	var current: Vector3 = _smoothed_line_targets[key] as Vector3
	var blend := 1.0 - exp(-line_target_follow_sharpness * maxf(get_process_delta_time(), 0.0))
	current = current.lerp(raw_point, clampf(blend, 0.0, 1.0))
	_smoothed_line_targets[key] = current
	return current

func _append_sight_target_line(group: Dictionary, target: MistbornTargetable, origin: Vector3, width: float, tint: Color) -> bool:
	if target == null or not is_instance_valid(target):
		return false
	var b: Vector3 = _smooth_line_target(target)
	# An active action link is not screen-space UI. Once the action is fixed and
	# remains within the shared 35 m authority, it stays visible even if the target
	# temporarily leaves the camera frustum.
	if _player.global_position.distance_to(target.get_allomantic_visual_point()) > FORCE_MODEL.SHARED_RANGE:
		return false
	var vertices := PackedVector3Array()
	var uvs := PackedVector2Array()
	var colors := PackedColorArray()
	var indices := PackedInt32Array()
	_append_sight_line(vertices, uvs, colors, indices, origin, b, width, tint, target.get_instance_id())
	if vertices.size() < 4:
		return false
	var arrays: Array = []; arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_COLOR] = colors
	arrays[Mesh.ARRAY_INDEX] = indices
	group["mesh"].add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	group["instance"].visible = true
	return true

func _update_sight_lines() -> void:
	var has_active_action := _action_active and _action_target != null and is_instance_valid(_action_target)
	if not _sight_active and not has_active_action:
		_clear_sight_line_meshes()
		_sight_line_targets_cache.clear()
		_smoothed_line_targets.clear()
		_smoothed_line_sides.clear()
		_smoothed_line_origin_initialized = false
		return

	# Selection/occlusion can refresh at a modest cadence, but rendered endpoints
	# follow every frame. This removes low-frequency visual stepping.
	if _line_refresh_left <= 0.0:
		if _sight_active:
			_sight_line_targets_cache = _collect_sight_line_targets()
		else:
			_sight_line_targets_cache.clear()
		_line_refresh_left = line_refresh_interval

	var raw_origin := _get_sight_origin()
	if not _smoothed_line_origin_initialized:
		_smoothed_line_origin = raw_origin
		_smoothed_line_origin_initialized = true
	else:
		var origin_blend := 1.0 - exp(-line_origin_follow_sharpness * maxf(get_process_delta_time(), 0.0))
		_smoothed_line_origin = _smoothed_line_origin.lerp(raw_origin, clampf(origin_blend, 0.0, 1.0))
	var origin := _smoothed_line_origin

	_clear_sight_line_meshes()
	var active_target: MistbornTargetable = _action_target if has_active_action else null
	var candidates: Array[MistbornTargetable] = []
	for sight_target in _sight_line_targets_cache:
		if sight_target != null and is_instance_valid(sight_target):
			candidates.append(sight_target)
	if active_target != null:
		candidates.erase(active_target)

	var by_profile: Dictionary = {}
	for profile in _sight_groups.keys():
		by_profile[profile] = []
	for target: MistbornTargetable in candidates:
		if target == null or not is_instance_valid(target):
			continue
		var profile := target.get_allomantic_profile()
		if not by_profile.has(profile):
			profile = "DECORATIVE"
		by_profile[profile].append(target)

	var live_keys: Dictionary = {}
	for profile in by_profile.keys():
		var targets: Array = by_profile[profile]
		if targets.is_empty():
			continue
		var group: Dictionary = _sight_groups[profile]
		var vertices := PackedVector3Array()
		var uvs := PackedVector2Array()
		var colors := PackedColorArray()
		var indices := PackedInt32Array()
		for target: MistbornTargetable in targets:
			var b := _smooth_line_target(target)
			var metrics := _screen_metrics(target.get_allomantic_visual_point())
			if not metrics.get("valid", false):
				continue
			var normalized: float = metrics["normalized"]
			var distance := _player.global_position.distance_to(target.get_allomantic_visual_point())
			var distance_factor := 1.0 - clampf(distance / maxf(sight_max_distance, 0.001), 0.0, 1.0) * 0.42
			var center_factor := 1.0 - clampf(normalized / maxf(sight_screen_soft_limit, 0.001), 0.0, 1.0) * 0.34
			var profile_factor := _get_sight_profile_weight(target)
			var occlusion_factor := _get_sight_occlusion_factor(target)
			var salience := clampf(profile_factor * (0.72 + 0.28 * target.selection_priority / maxf(target.selection_priority + 1.0, 1.0)) * distance_factor * center_factor, 0.16, 1.0)
			var tint := Color(0.86, 0.94, 1.0, salience * (1.0 - occlusion_factor))
			var width := float(group["width"]) * lerpf(0.78, 1.0, salience)
			_append_sight_line(vertices, uvs, colors, indices, origin, b, width, tint, target.get_instance_id())
			live_keys[target.get_instance_id()] = true
		if vertices.size() >= 4:
			var arrays: Array = []; arrays.resize(Mesh.ARRAY_MAX)
			arrays[Mesh.ARRAY_VERTEX] = vertices
			arrays[Mesh.ARRAY_TEX_UV] = uvs
			arrays[Mesh.ARRAY_COLOR] = colors
			arrays[Mesh.ARRAY_INDEX] = indices
			group["mesh"].add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
			group["instance"].visible = true

	if active_target != null:
		var active_group: Dictionary = _sight_groups["ACTIVE"]
		if _append_sight_target_line(active_group, active_target, origin, selected_line_width, Color(0.16, 0.68, 1.0, 1.0)):
			live_keys[active_target.get_instance_id()] = true

	for key in _smoothed_line_targets.keys().duplicate():
		if not live_keys.has(key):
			_smoothed_line_targets.erase(key)
			_smoothed_line_sides.erase(key)

func acquire_action_target(action_name: StringName) -> MistbornTargetable:
	# One fresh Steel/Iron intent press = one fresh acquisition. E traverses;
	# F/right mouse yanks a movable heavy body. The previous action target is
	# deliberately excluded when another valid target exists, even if movement
	# input such as W remains held. Holding W is steering intent, not a reason to
	# reacquire the same anchor forever. If no alternative exists, the previous
	# target remains a valid fallback.
	if action_name != &"steel" and action_name != &"iron":
		return null
	if _player == null or _camera == null or _action_active:
		return _action_target if _action_active else null

	var candidates := _collect_action_candidates(action_name)
	if candidates.is_empty():
		return null

	var fresh_candidates := _remove_recent_action_target(candidates, action_name)
	var selection_pool := fresh_candidates if not fresh_candidates.is_empty() else candidates

	if not _player.is_on_floor() and _has_directional_input():
		var desired := _get_desired_travel_direction()
		if desired.length_squared() > 0.001:
			var traversal_candidates := _build_traversal_ranked_candidates(selection_pool, desired, action_name)
			if not traversal_candidates.is_empty():
				var selected := traversal_candidates[0]
				_clear_recent_action_target()
				return selected

	# Grounded acquisition remains reticle-led. Airborne directional acquisition above
	# may intentionally use off-screen targets when their horizontal reaction is the
	# best match for the player's movement intent.
	var center := _find_reticle_center_target(selection_pool)
	if center != null:
		_clear_recent_action_target()
		return center
	selection_pool.sort_custom(_action_acquisition_sort)
	var selected: MistbornTargetable = selection_pool[0] if not selection_pool.is_empty() else null
	if selected != null:
		_clear_recent_action_target()
	return selected

func _remove_recent_action_target(candidates: Array[MistbornTargetable], action_name: StringName) -> Array[MistbornTargetable]:
	if _last_completed_action_target == null or not is_instance_valid(_last_completed_action_target):
		return candidates
	if _last_completed_action_name != action_name:
		return candidates
	var filtered: Array[MistbornTargetable] = []
	for candidate: MistbornTargetable in candidates:
		if candidate == null or not is_instance_valid(candidate):
			continue
		if candidate != _last_completed_action_target:
			filtered.append(candidate)
	return filtered

func _clear_recent_action_target() -> void:
	_last_completed_action_target = null
	_last_completed_action_name = StringName("")

func _collect_action_candidates(action_name: StringName) -> Array[MistbornTargetable]:
	var result: Array[MistbornTargetable] = []
	for target: MistbornTargetable in _get_targetables():
		if target == null or not is_instance_valid(target):
			continue
		if not _is_action_candidate_valid(target, action_name):
			continue
		result.append(target)
	return result

func _is_action_candidate_valid(target: MistbornTargetable, action_name: StringName) -> bool:
	if target == null or not is_instance_valid(target) or not target.selectable or not target.is_metallic:
		return false
	if action_name == &"steel" and not target.steel_pushable:
		return false
	if action_name == &"iron" and not target.iron_pullable:
		return false
	var point: Vector3 = target.get_allomantic_action_point(action_name, _player.global_position, _player.is_on_floor())
	var distance := _player.global_position.distance_to(point)
	var allowed_range := max_target_distance
	if target.max_range_override > 0.0:
		allowed_range = target.max_range_override if allowed_range <= 0.0 else minf(allowed_range, target.max_range_override)
	if allowed_range > 0.0 and distance > allowed_range:
		return false
	if not _is_allomantic_use_cone_valid(target, action_name):
		return false
	var directional_traversal := _is_directional_traversal_acquisition(action_name)
	if not directional_traversal and _camera.is_position_behind(point):
		return false
	if not directional_traversal:
		var metrics := _screen_metrics(point)
		if not metrics.get("valid", false) or float(metrics["normalized"]) > auto_screen_radius:
			return false
	if target.requires_line_of_sight and not _has_line_of_sight(target, point):
		return false
	if not _player.is_on_floor() and _has_directional_input():
		var desired := _get_desired_travel_direction()
		if desired.length_squared() > 0.001:
			var reaction := _get_action_direction_for_target(target, action_name)
			if not _is_reaction_forward_or_neutral(desired, reaction):
				return false
	return true

func _action_acquisition_sort(a: MistbornTargetable, b: MistbornTargetable) -> bool:
	var a_metrics := _screen_metrics(a.get_allomantic_visual_point())
	var b_metrics := _screen_metrics(b.get_allomantic_visual_point())
	var a_screen: float = float(a_metrics.get("normalized", INF))
	var b_screen: float = float(b_metrics.get("normalized", INF))
	if not is_equal_approx(a_screen, b_screen):
		return a_screen < b_screen
	var a_distance := _player.global_position.distance_to(a.get_allomantic_visual_point())
	var b_distance := _player.global_position.distance_to(b.get_allomantic_visual_point())
	if not is_equal_approx(a_distance, b_distance):
		return a_distance < b_distance
	if not is_equal_approx(a.selection_priority, b.selection_priority):
		return a.selection_priority > b.selection_priority
	return a.target_accessibility > b.target_accessibility

func _is_fixed_action_target_valid(target: MistbornTargetable) -> bool:
	if target == null or not is_instance_valid(target) or not target.selectable or not target.is_metallic:
		return false
	if _allomantic_action_name == &"steel" and not target.steel_pushable:
		return false
	if _allomantic_action_name == &"iron" and not target.iron_pullable:
		return false
	if _player == null:
		return false
	var point: Vector3 = target.get_allomantic_action_point(_allomantic_action_name, _player.global_position, _player.is_on_floor())
	var distance := _player.global_position.distance_to(point)
	var allowed_range := max_target_distance
	if target.max_range_override > 0.0:
		allowed_range = target.max_range_override if allowed_range <= 0.0 else minf(allowed_range, target.max_range_override)
	return allowed_range <= 0.0 or distance <= allowed_range

func begin_action_target(target: MistbornTargetable, action_name: StringName = StringName("")) -> bool:
	if target == null or not is_instance_valid(target):
		return false
	_action_active = true
	_action_target = target
	_set_target(target)
	_action_target_lost_left = action_target_lost_grace
	_allomantic_action_name = action_name if action_name == &"steel" or action_name == &"iron" else StringName("")
	_clear_recent_action_target()
	return true

func end_action_target(action_name: StringName = StringName("")) -> void:
	if _action_target != null and is_instance_valid(_action_target):
		var completed_name := action_name if action_name == &"steel" or action_name == &"iron" else _allomantic_action_name
		if completed_name == &"steel" or completed_name == &"iron":
			_last_completed_action_target = _action_target
			_last_completed_action_name = completed_name
	_allomantic_action_name = StringName("")
	_action_active = false
	_action_target = null

func end_all_action_targets() -> void:
	if _action_target != null and is_instance_valid(_action_target):
		if _allomantic_action_name == &"steel" or _allomantic_action_name == &"iron":
			_last_completed_action_target = _action_target
			_last_completed_action_name = _allomantic_action_name
	_allomantic_action_name = StringName("")
	_action_active = false
	_action_target = null
	_action_target_lost_left = 0.0

func reset_for_playground() -> void:
	end_all_action_targets()
	_clear_target()
	_set_locked(false)
	_last_completed_action_target = null
	_last_completed_action_name = StringName("")
	_action_target_lost_left = 0.0
	_manual_cycle_suppression = 0.0
	_focus_refresh_left = 0.0
	_line_refresh_left = 0.0
	_lock_validation_left = 0.0
	if _sight_active:
		_set_sight_active(false)

func is_action_target_active() -> bool:
	return _action_active and _action_target != null and is_instance_valid(_action_target)

func is_steel_action_active() -> bool:
	return _action_active and _allomantic_action_name == &"steel"

func is_iron_action_active() -> bool:
	return _action_active and _allomantic_action_name == &"iron"

func get_action_target() -> MistbornTargetable:
	return _action_target if is_action_target_active() else null

func get_allomantic_target() -> MistbornTargetable:
	if is_action_target_active():
		return _action_target

	var action_name := _get_current_allomantic_input_action()
	var airborne_traversal := _player != null and not _player.is_on_floor() and (action_name == &"steel" or action_name == &"iron") and _has_directional_input()
	if airborne_traversal:
		var desired := _get_desired_travel_direction()
		if desired.length_squared() > 0.001:
			var traversal_candidates := _collect_traversal_candidates(action_name)
			var ranked := _build_traversal_ranked_candidates(traversal_candidates, desired, action_name)
			if not ranked.is_empty():
				var traversal_target := ranked[0]
				_set_target(traversal_target)
				return traversal_target

	var use_action_acquisition := Input.is_action_pressed("steel_push") or Input.is_action_pressed("iron_pull") or Input.is_action_pressed("iron_yank") or _allomantic_action_name == &"steel" or _allomantic_action_name == &"iron"
	# Grounded/look acquisition remains reticle-led; airborne traversal uses the
	# dedicated directional/recovery ranking above. This keeps normal targeting
	# comfortable without allowing a backwards airborne action target.
	var candidates := _collect_candidates(use_action_acquisition)
	var center := _find_reticle_center_target(candidates)
	var center_usable := false
	if center != null:
		if action_name == &"steel":
			center_usable = center.steel_pushable
		elif action_name == &"iron":
			center_usable = center.iron_pullable
	if center_usable:
		_set_target(center)
		return center

	var current_target_cone_ok := not use_action_acquisition or _is_allomantic_use_cone_valid(_current_target, action_name)
	if _current_target != null and is_instance_valid(_current_target) and current_target_cone_ok and _is_action_target_valid(_current_target):
		_set_target(_current_target)
		return _current_target

	var target := _best_from(candidates)
	if target != null:
		_set_target(target)
	return target

func get_current_target() -> MistbornTargetable:
	return _current_target

func set_context_target(target: MistbornTargetable) -> void:
	if target != null and is_instance_valid(target) and target.selectable:
		_set_target(target)
		_manual_cycle_suppression = 0.45

func has_target() -> bool:
	return _current_target != null and is_instance_valid(_current_target)

func is_locked() -> bool:
	return _locked

func is_sight_active() -> bool:
	return _sight_active

func get_debug_state() -> Dictionary:
	return {
		"target_name": _current_target.display_name if _current_target != null and is_instance_valid(_current_target) else "NINGUNO",
		"target_id": _current_target.target_id if _current_target != null and is_instance_valid(_current_target) else "",
		"target_type": _current_target.target_type if _current_target != null and is_instance_valid(_current_target) else "",
		"focus_name": _focus_target.display_name if _focus_target != null and is_instance_valid(_focus_target) else "NINGUNO",
		"locked": _locked,
		"sight_active": _sight_active,
		"action_target_active": is_action_target_active(),
		"allomantic_action": String(_allomantic_action_name),
		"action_target_name": _action_target.display_name if _action_target != null and is_instance_valid(_action_target) else "NINGUNO",
		"candidate_count": _last_candidate_count,
		"sight_count": _last_sight_count,
		"best_score": _last_best_score,
		"mode": TargetingMode.keys()[_get_effective_targeting_mode()],
		"allomantic_use_cone_half_angle_degrees": allomantic_use_cone_half_angle_degrees
	}
