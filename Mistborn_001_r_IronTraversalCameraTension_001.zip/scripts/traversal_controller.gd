class_name MistbornTraversalController
extends Node

signal steel_coin_interaction_started(coin: MistbornCoin)
signal traversal_recovered(target: MistbornTargetable)
signal traversal_chained(previous: MistbornTargetable, next_target: MistbornTargetable)
signal coin_inventory_changed(count: int)

const FORCE_MODEL = preload("res://scripts/allomantic_force_model.gd")

@export_category("Coin Inventory")
@export var infinite_test_coins: bool = true
@export var starting_coin_count: int = 20

@export_category("Steel Coin Interaction")
@export var steel_coin_spawn_height: float = 1.15

@export_category("Air Traversal")
@export var traversal_chain_distance: float = FORCE_MODEL.COMFORT_PUSH_DISTANCE
@export var traversal_recovery_range: float = FORCE_MODEL.SHARED_RANGE
@export var traversal_recovery_screen_radius: float = 0.82
@export var traversal_recovery_cooldown: float = 0.28

var _player: MistbornPlayerController
var _targeting: MistbornTargetingController
var _steel: MistbornSteelController
var _iron: MistbornIronController
var _coin_count: int = 0
var _recovery_cooldown_left: float = 0.0
var _state: String = "GROUND"

func _ready() -> void:
	_coin_count = maxi(starting_coin_count, 0)
	_player = get_parent() as MistbornPlayerController
	if _player != null:
		_targeting = _player.get_node_or_null("Targeting") as MistbornTargetingController
		_steel = _player.get_node_or_null("Steel") as MistbornSteelController
		_iron = _player.get_node_or_null("Iron") as MistbornIronController

func physics_step(delta: float) -> void:
	if _player == null:
		return
	_recovery_cooldown_left = maxf(_recovery_cooldown_left - delta, 0.0)
	_update_targeting_mode()
	# Steel/Iron controllers own acquisition on the first held frame.
	# Traversal never preselects or retargets behind their backs.
	_update_state()

func spawn_steel_coin_interaction_coin() -> MistbornCoin:
	if _player == null:
		return null
	if not try_spend_coin_for_steel_interaction():
		return null

	var scene_root: Node = _player.get_parent()
	if scene_root == null:
		if not infinite_test_coins:
			_coin_count += 1
			coin_inventory_changed.emit(_coin_count)
		return null

	var pool := get_tree().get_first_node_in_group("mistborn_coin_pool") as MistbornCoinPool
	var coin: MistbornCoin = pool.acquire(scene_root) if pool != null else MistbornCoin.new()
	if coin == null:
		if not infinite_test_coins:
			_coin_count += 1
			coin_inventory_changed.emit(_coin_count)
		return null

	if coin.get_parent() != scene_root:
		coin.reparent(scene_root, true)
	coin.name = "SteelSpecialCoin"

	# The special Steel interaction never uses aim. The coin appears around the
	# player's chest and Steel supplies the downward target reaction immediately.
	var spawn_position := _player.global_position + Vector3.UP * steel_coin_spawn_height
	coin.global_position = spawn_position
	coin.begin_steel_special_drop()
	steel_coin_interaction_started.emit(coin)
	return coin

func try_spend_coin_for_steel_interaction() -> bool:
	if infinite_test_coins:
		return true
	if _coin_count <= 0:
		return false
	_coin_count -= 1
	coin_inventory_changed.emit(_coin_count)
	return true

func try_spend_coin_for_projectile() -> bool:
	if infinite_test_coins:
		return true
	if _coin_count <= 0:
		return false
	_coin_count -= 1
	coin_inventory_changed.emit(_coin_count)
	return true

func collect_world_coin(coin: MistbornCoin = null) -> bool:
	if _player == null:
		return false
	if coin != null and not is_instance_valid(coin):
		return false
	if coin != null and coin.get_targetable() == null:
		return false
	if not infinite_test_coins:
		_coin_count += 1
		coin_inventory_changed.emit(_coin_count)
	return true

func get_coin_count() -> int:
	return 999999 if infinite_test_coins else _coin_count

func is_steel_coin_interaction_ready() -> bool:
	return _has_coin_available()

func _has_coin_available() -> bool:
	return infinite_test_coins or _coin_count > 0

func prewarm_steel_coin_interaction() -> void:
	var pool := get_tree().get_first_node_in_group("mistborn_coin_pool") as MistbornCoinPool
	if pool == null or _player == null:
		return
	var scene_root: Node = _player.get_parent()
	if scene_root == null:
		return
	var coin := pool.acquire(scene_root)
	if coin == null:
		return
	coin.name = "__SteelSpecialPrewarm"
	coin.global_position = _player.global_position + Vector3.UP * steel_coin_spawn_height
	coin.begin_steel_special_drop()
	for _i in range(8):
		if not is_instance_valid(coin):
			return
		coin.is_grounded_on_solid()
		await get_tree().physics_frame
	if is_instance_valid(coin):
		pool.reclaim(coin)

func _try_recover_traversal_action() -> void:
	if _player == null or _targeting == null or _player.is_on_floor():
		return
	if _recovery_cooldown_left > 0.0:
		return
	var steel_input: bool = Input.is_action_pressed("steel_push") and _player.owns_allomancy_input(&"steel")
	var iron_input: bool = Input.is_action_pressed("iron_pull") and _player.owns_allomancy_input(&"iron")
	if not steel_input and not iron_input:
		return
	var current := _targeting.get_action_target()
	if current != null and is_instance_valid(current) and current.selectable and current.show_in_allomantic_sight:
		return
	var recovery := _targeting.get_traversal_recovery_target(FORCE_MODEL.SHARED_RANGE, traversal_recovery_screen_radius)
	if recovery == null:
		return
	if _targeting.set_traversal_action_target(recovery):
		_recovery_cooldown_left = traversal_recovery_cooldown
		traversal_recovered.emit(recovery)

func _try_chain_traversal_target() -> void:
	if _player == null or _targeting == null or _player.is_on_floor():
		return
	# Discrete Steel/Iron owns one target per fresh button press. Never silently
	# preselect a second target while the current impulse key remains held. The
	# next target must be acquired by the next fresh press through the same
	# traversal targeting authority.
	var steel_active: bool = _steel != null and _steel.is_active()
	var iron_active: bool = _iron != null and _iron.is_active()
	if steel_active or iron_active:
		return
	var current := _targeting.get_action_target()
	if current == null or not is_instance_valid(current):
		return
	var distance: float = _player.global_position.distance_to(current.get_target_point())
	if distance > traversal_chain_distance:
		return
	var next_target := _targeting.get_next_traversal_target(current)
	if next_target == null or next_target == current:
		return
	if _targeting.set_traversal_action_target(next_target):
		traversal_chained.emit(current, next_target)

func _update_targeting_mode() -> void:
	if _targeting == null or _player == null:
		return
	_targeting.targeting_mode = MistbornTargetingController.TargetingMode.EXPLORATION if _player.is_on_floor() else MistbornTargetingController.TargetingMode.TRAVERSAL

func _update_state() -> void:
	if _player.is_on_floor():
		_set_state("GROUND")
		return
	if _steel != null and _steel.is_active():
		_set_state("FLIGHT_STEEL")
	elif _iron != null and _iron.is_active():
		_set_state("FLIGHT_IRON")
	else:
		_set_state("AIR")

func _set_state(value: String) -> void:
	_state = value

func reset_for_playground() -> void:
	_recovery_cooldown_left = 0.0
	_state = "GROUND"

func get_traversal_state() -> String:
	return _state

func get_debug_state() -> Dictionary:
	return {
		"state": _state,
		"coin_count": _coin_count,
		"steel_coin_interaction_ready": is_steel_coin_interaction_ready(),
		"chain_grace": _recovery_cooldown_left
	}
