extends Node

## Deterministic Player Core runtime playtest.
## Run with:
##   godot --headless --path . res://scenes/player_core_playtest.tscn
##
## This is QA infrastructure only. It does not execute in the normal game.

const MAIN_SCENE := preload("res://scenes/main.tscn")
const INPUT_ACTIONS := preload("res://scripts/input_setup.gd")
const HEAVY_IRON_TEST := preload("res://scripts/iron_heavy_controller.gd")

const GROUND_POS := Vector3(0.0, 0.0, 108.0)
const TEST_PLATFORM_POS := Vector3(0.0, 8.0, 108.0)
const TEST_PLATFORM_SIZE := Vector3(8.0, 0.5, 6.0)
const TEST_PLATFORM_TOP_Y := 8.25

var _main: Node3D
var _player: MistbornPlayerController
var _camera: MistbornCameraRig
var _platform: StaticBody3D
var _results: Array[Dictionary] = []
var _measurement_active := false
var _max_frame_ms := 0.0
var _started_at := ""
var _finished := false

func _ready() -> void:
	_started_at = Time.get_datetime_string_from_system(true)
	call_deferred("_run_suite")

func _process(delta: float) -> void:
	if _measurement_active:
		_max_frame_ms = maxf(_max_frame_ms, delta * 1000.0)

func _run_suite() -> void:
	INPUT_ACTIONS.ensure_defaults()
	_main = MAIN_SCENE.instantiate() as Node3D
	_main.name = "PlaytestMain"
	add_child(_main)

	await _wait_for_player()
	_create_test_platform()
	_release_all_inputs()
	await _wait_for_runtime_prewarm()
	_measurement_active = true

	_results.append(await _test_boot_and_input())
	_results.append(_test_player_visual_boot())
	_results.append(await _test_walk())
	_results.append(await _test_sprint())
	_results.append(await _test_braking())
	_results.append(await _test_turning())
	_results.append(await _test_jump())
	_results.append(await _test_coyote_time())
	_results.append(await _test_jump_buffer())
	_results.append(await _test_crouch())
	_results.append(await _test_camera_fov())
	_results.append(_test_camera_auto_follow_math())
	_results.append(await _test_mass_response_distribution())
	_results.append(await _test_mass_support_response())
	_results.append(await _test_steel_power())
	_results.append(_test_steel_counterfall_force_math())
	_results.append(_test_steel_grounded_coin_anchor_policy())
	_results.append(await _test_iron_power())
	_results.append(await _test_steel_coin_interaction())
	_results.append(await _test_coin_jump_handoff_to_iron())
	_results.append(await _test_allomancy_camera_yaw_lock())
	_results.append(_test_steel_direction_hard_gate())
	_results.append(_test_traversal_horizontal_only_intent_scoring())
	_results.append(_test_allomantic_use_cone())
	_results.append(await _test_steel_iron_single_acquisition_authority())
	_results.append(await _test_allomancy_input_handoff())
	_results.append(await _test_tall_lamp_allomantic_tip_only())
	_results.append(await _test_tall_lamp_mount_contract())
	_results.append(await _test_generic_metal_perch_contract())
	_results.append(_test_iron_upper_cone_quadratic_contract())
	_results.append(_test_iron_arc_steering_math())
	_results.append(_test_iron_physical_tether_math())
	_results.append(_test_iron_tether_target_classification())
	_results.append(_test_iron_traversal_launch_math())
	_results.append(_test_iron_heavy_intent_math())
	_results.append(_test_mount_capture_envelope())
	_results.append(_test_mount_arrival_guidance_math())
	_results.append(_test_mount_clearance_waypoint())
	_results.append(_test_air_feel_contract())

	_measurement_active = false
	_release_all_inputs()
	await _wait_seconds(0.05)
	_write_report()

	if _finished:
		return
	_finished = true
	get_tree().quit(1 if _has_failures() else 0)

func _wait_for_player() -> void:
	var frames := 0
	while _player == null and frames < 180:
		if is_instance_valid(_main):
			_player = _main.get_node_or_null("Player") as MistbornPlayerController
		if _player != null:
			_camera = _player.get_node_or_null("CameraRig") as MistbornCameraRig
			return
		await get_tree().process_frame
		frames += 1

func _wait_for_runtime_prewarm() -> void:
	var main_ready_method := is_instance_valid(_main) and _main.has_method("is_runtime_prewarm_complete")
	if main_ready_method:
		var frames := 0
		while not bool(_main.call("is_runtime_prewarm_complete")) and frames < 600:
			await get_tree().process_frame
			frames += 1
	else:
		await _wait_seconds(1.0)
	await _wait_seconds(0.2)

func _create_test_platform() -> void:
	_platform = StaticBody3D.new()
	_platform.name = "__PlayerCorePlaytestPlatform"
	_platform.position = TEST_PLATFORM_POS
	_platform.collision_layer = 1
	_platform.collision_mask = 0

	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = TEST_PLATFORM_SIZE
	collision.shape = shape
	_platform.add_child(collision)
	_main.add_child(_platform)

func _reset_player(position: Vector3, yaw_deg: float = 0.0) -> void:
	_release_all_inputs()
	# Expire jump buffer, coyote and Space double-tap latches before a new fixture.
	await _wait_seconds(0.50)
	_player.velocity = Vector3.ZERO
	_player.global_position = position
	_player.rotation = Vector3.ZERO
	if _camera != null and _camera.has_method("reset_for_playtest"):
		_camera.call("reset_for_playtest", yaw_deg, -12.0)
	await _wait_physics_updates(2)
	_player.velocity = Vector3.ZERO

func _hold_forward(seconds: float, sprint: bool = false) -> void:
	Input.action_press("move_forward")
	if sprint:
		Input.action_press("sprint")
	await _wait_seconds(seconds)
	Input.action_release("sprint")
	Input.action_release("move_forward")

func _press_jump() -> void:
	Input.action_press("jump")
	await _wait_physics_updates(1)
	Input.action_release("jump")
	await _wait_physics_updates(1)

func _wait_physics_updates(count: int = 1) -> void:
	# SceneTree.physics_frame fires before Node._physics_process. Await process_frame
	# afterward so state is sampled only after that physics update has executed.
	for _step in range(maxi(count, 0)):
		await get_tree().physics_frame
		await get_tree().process_frame

func _wait_for_player_grounded(max_steps: int = 30) -> bool:
	for _step in range(maxi(max_steps, 0)):
		if _player.is_on_floor():
			return true
		await _wait_physics_updates(1)
	return _player.is_on_floor()

func _release_all_inputs() -> void:
	for action in [
		"move_forward", "move_backward", "move_left", "move_right",
		"sprint", "crouch", "jump", "steel_push", "iron_pull", "iron_yank"
	]:
		Input.action_release(action)

func _wait_seconds(seconds: float) -> void:
	var elapsed := 0.0
	while elapsed < seconds:
		var before := Time.get_ticks_usec()
		await get_tree().process_frame
		var after := Time.get_ticks_usec()
		var frame_seconds := float(after - before) / 1000000.0
		if frame_seconds <= 0.0:
			frame_seconds = 1.0 / 60.0
		elapsed += frame_seconds

func _test_iron_arc_steering_math() -> Dictionary:
	var side_direction := MistbornIronController.calculate_arc_steering_direction(Vector3(0.0, 0.0, -1.0), Vector3.RIGHT)
	var radial_direction := MistbornIronController.calculate_arc_steering_direction(Vector3(0.0, 0.0, -1.0), Vector3(0.0, 0.0, -1.0))
	var vertical_anchor_side := MistbornIronController.calculate_arc_steering_direction(Vector3.UP, Vector3.RIGHT)
	var radial_dot := absf(side_direction.dot(Vector3(0.0, 0.0, -1.0)))
	var passed := side_direction.dot(Vector3.RIGHT) > 0.999 and is_zero_approx(radial_direction.length()) and vertical_anchor_side.dot(Vector3.RIGHT) > 0.999 and radial_dot < 0.001
	return _result(
		"IRON_ARC_STEERING_MATH",
		passed,
		"Iron side input is projected onto the anchor tangent plane; radial intent adds no sideways steering." if passed else "Iron arc steering has an unexpected radial component or loses valid tangent input.",
		{"side_direction": str(side_direction), "radial_intent": str(radial_direction), "vertical_anchor_side": str(vertical_anchor_side), "radial_dot": radial_dot}
	)

func _test_iron_physical_tether_math() -> Dictionary:
	var taut_velocity := MistbornIronController.calculate_physical_tether_velocity(
		Vector3(3.0, 4.0, 0.0), Vector3(4.9, 0.0, 0.0), Vector3.ZERO,
		5.0, 0.1, 6.0, 14.0, 0.0, 24.0
	)
	var exactly_taut_velocity := MistbornIronController.calculate_physical_tether_velocity(
		Vector3(3.0, 2.0, 0.0), Vector3(5.0, 0.0, 0.0), Vector3.ZERO,
		5.0, 1.0 / 60.0, 6.0, 14.0, 0.0, 24.0
	)
	var overextended_velocity := MistbornIronController.calculate_physical_tether_velocity(
		Vector3.ZERO, Vector3(6.0, 0.0, 0.0), Vector3.ZERO,
		5.0, 1.0 / 60.0, 6.0, 14.0, 0.0
	)
	var inward_velocity := MistbornIronController.calculate_physical_tether_velocity(
		Vector3(-3.0, 2.0, 0.0), Vector3(4.0, 0.0, 0.0), Vector3.ZERO,
		5.0, 0.1, 6.0, 14.0, 0.0
	)
	var clearance_velocity := MistbornIronController.calculate_physical_tether_velocity(
		Vector3(-2.0, 1.0, 0.0), Vector3(0.8, 0.0, 0.0), Vector3.ZERO,
		5.0, 0.1, 6.0, 14.0, 1.0
	)
	var pre_tension_reduces_radial_smoothly := taut_velocity.x > 0.0 and taut_velocity.x < 3.0 and is_equal_approx(taut_velocity.y, 4.0)
	var exactly_taut_stays_inside_radius_and_keeps_tangent := exactly_taut_velocity.x < 0.0 and absf(exactly_taut_velocity.x) < 0.02 and is_equal_approx(exactly_taut_velocity.y, 2.0)
	var overextended_corrects_inward := overextended_velocity.x < -5.9 and is_zero_approx(overextended_velocity.y)
	var inward_momentum_preserved := inward_velocity.is_equal_approx(Vector3(-3.0, 2.0, 0.0))
	var clearance_prevents_inward_motion := is_zero_approx(clearance_velocity.x) and is_equal_approx(clearance_velocity.y, 1.0)
	var passed := pre_tension_reduces_radial_smoothly and exactly_taut_stays_inside_radius_and_keeps_tangent and overextended_corrects_inward and inward_momentum_preserved and clearance_prevents_inward_motion
	return _result(
		"IRON_PHYSICAL_TETHER_MATH",
		passed,
		"A tether pre-brakes radial speed before reaching its length limit, preserves tangent/inward momentum, and adds only the small radial correction required by the next discrete swing step." if passed else "Physical tether pre-tension or radial/tangential preservation failed.",
		{
			"pre_tension_velocity": str(taut_velocity),
			"exactly_taut_velocity": str(exactly_taut_velocity),
			"overextended_velocity": str(overextended_velocity),
			"inward_velocity": str(inward_velocity),
			"clearance_velocity": str(clearance_velocity)
		}
	)

func _test_iron_tether_target_classification() -> Dictionary:
	var static_target := MistbornTargetable.new()
	var static_body := StaticBody3D.new()
	static_target.set_physical_body(static_body)
	var static_uses_tether := MistbornIronController.supports_physical_tether(static_target)

	var movable_target := MistbornTargetable.new()
	var movable_body := RigidBody3D.new()
	movable_body.mass = 120.0
	movable_target.set_physical_body(movable_body)
	var movable_uses_resolver := not MistbornIronController.supports_physical_tether(movable_target)
	movable_body.freeze = true
	var frozen_uses_tether := MistbornIronController.supports_physical_tether(movable_target)

	var logical_anchor := MistbornTargetable.new()
	logical_anchor.allomantic_profile = "ANCHOR"
	var logical_anchor_uses_tether := MistbornIronController.supports_physical_tether(logical_anchor)

	# set_physical_body() reparents each physics body under its target. Freeing
	# the target therefore frees its child; guard child cleanup to avoid double-free.
	static_target.free()
	if is_instance_valid(static_body):
		static_body.free()
	movable_target.free()
	if is_instance_valid(movable_body):
		movable_body.free()
	logical_anchor.free()

	var passed := static_uses_tether and movable_uses_resolver and frozen_uses_tether and logical_anchor_uses_tether
	return _result(
		"IRON_TETHER_TARGET_CLASSIFICATION",
		passed,
		"Fixed bodies/frozen bodies can use a physical tether; freely movable rigid bodies keep the shared force resolver." if passed else "A movable target was routed through the physical tether incorrectly.",
		{
			"static_uses_tether": static_uses_tether,
			"movable_uses_force_resolver": movable_uses_resolver,
			"frozen_uses_tether": frozen_uses_tether,
			"logical_anchor_uses_tether": logical_anchor_uses_tether
		}
	)

func _test_iron_traversal_launch_math() -> Dictionary:
	var initial := Vector3(3.0, 0.0, 4.0)
	var launched := MistbornIronController.calculate_launch_velocity(initial, Vector3.UP, 7.5, 34.0)
	var capped := MistbornIronController.calculate_launch_velocity(Vector3(33.0, 0.0, 0.0), Vector3.RIGHT, 7.5, 34.0)
	var launch_adds_velocity: bool = launched.y > 7.4 and is_equal_approx(launched.x, initial.x) and is_equal_approx(launched.z, initial.z)
	var cap_respected: bool = capped.length() <= 34.001
	var invalid_direction_preserves_velocity: bool = MistbornIronController.calculate_launch_velocity(initial, Vector3.ZERO, 7.5, 34.0).is_equal_approx(initial)
	var passed := launch_adds_velocity and cap_respected and invalid_direction_preserves_velocity
	return _result(
		"IRON_TRAVERSAL_LAUNCH_MATH",
		passed,
		"Iron's one-shot launch adds velocity toward the fixed target, preserves the existing vector and respects the traversal speed cap." if passed else "Iron's launch impulse overwrote existing momentum or exceeded the speed cap.",
		{"launched_velocity": str(launched), "capped_speed": capped.length(), "invalid_direction_preserved": invalid_direction_preserves_velocity}
	)

func _test_iron_heavy_intent_math() -> Dictionary:
	var target := MistbornTargetable.new()
	var body := RigidBody3D.new()
	body.mass = 120.0
	target.set_physical_body(body)
	var heavy_movable := HEAVY_IRON_TEST.is_movable_heavy_target(target, 75.0)
	body.freeze = true
	var frozen_not_movable := not HEAVY_IRON_TEST.is_movable_heavy_target(target, 75.0)
	body.freeze = false
	body.mass = 25.0
	var light_not_heavy := not HEAVY_IRON_TEST.is_movable_heavy_target(target, 75.0)
	target.free()
	body.free()
	var yank_action_exists: bool = InputMap.has_action("iron_yank")
	var yank_has_f_binding := false
	var yank_has_mouse_binding := false
	if yank_action_exists:
		for event in InputMap.action_get_events("iron_yank"):
			if event is InputEventKey and (event as InputEventKey).physical_keycode == KEY_F:
				yank_has_f_binding = true
			if event is InputEventMouseButton and (event as InputEventMouseButton).button_index == MOUSE_BUTTON_RIGHT:
				yank_has_mouse_binding = true
	var passed := heavy_movable and frozen_not_movable and light_not_heavy and yank_has_f_binding and yank_has_mouse_binding
	return _result(
		"IRON_HEAVY_EXPLICIT_YANK_INTENT",
		passed,
		"F/right mouse has a separate action for pulling a movable heavy body; frozen and lighter bodies are not routed through Iron Heavy." if passed else "Iron Heavy input mapping or movable-heavy classification is incorrect.",
		{"movable_heavy": heavy_movable, "frozen_rejected": frozen_not_movable, "light_rejected": light_not_heavy, "iron_yank_action": yank_action_exists, "F_bound": yank_has_f_binding, "right_mouse_bound": yank_has_mouse_binding}
	)

func _test_mount_capture_envelope() -> Dictionary:
	var near_below := MistbornIronController.is_mount_capture_eligible(2.0, -2.5, 3.2, 8.5, 1.7)
	var directly_under_from_ground := MistbornIronController.is_mount_capture_eligible(0.0, -7.9, 3.2, 8.5, 1.7)
	var too_low := MistbornIronController.is_mount_capture_eligible(1.0, -9.0, 3.2, 8.5, 1.7)
	var too_far_sideways := MistbornIronController.is_mount_capture_eligible(3.7, -1.0, 3.2, 8.5, 1.7)
	var above_perch := MistbornIronController.is_mount_capture_eligible(1.0, 1.1, 3.2, 8.5, 1.7)
	var too_high := MistbornIronController.is_mount_capture_eligible(1.0, 2.0, 3.2, 8.5, 1.7)
	var passed := near_below and directly_under_from_ground and not too_low and not too_far_sideways and above_perch and not too_high
	return _result(
		"IRON_MOUNT_CAPTURE_ENVELOPE",
		passed,
		"Arrival can guide from the ground beneath a lamp, while still rejecting excessive vertical or lateral distance." if passed else "Mount capture envelope does not cover the lamp's ground-to-top approach as intended.",
		{"near_below": near_below, "directly_under_from_ground": directly_under_from_ground, "too_low": too_low, "too_far_sideways": too_far_sideways, "above_perch": above_perch, "too_high": too_high}
	)

func _test_mount_clearance_waypoint() -> Dictionary:
	var surface := Vector3(4.0, 7.98, -2.0)
	var waypoint := MistbornIronController.calculate_mount_clearance_goal(surface, Vector3(3.0, 4.0, 0.0), 0.95, 0.55)
	var flat_offset := Vector3(waypoint.x - surface.x, 0.0, waypoint.z - surface.z).length()
	var height_offset := waypoint.y - surface.y
	var passed := is_equal_approx(flat_offset, 0.95) and is_equal_approx(height_offset, 0.55) and waypoint.x > surface.x
	return _result(
		"IRON_MOUNT_CLEARANCE_WAYPOINT",
		passed,
		"The first landing phase clears the lamp head laterally and vertically before entering the perch." if passed else "Mount clearance waypoint does not clear both the side and top of the lamp.",
		{"flat_offset_m": flat_offset, "height_offset_m": height_offset, "waypoint": waypoint}
	)

func _test_mount_arrival_guidance_math() -> Dictionary:
	var fast_goal := MistbornIronController.calculate_mount_desired_velocity(Vector3(0.0, 10.0, 0.0), 2.7, 9.5)
	var near_goal := MistbornIronController.calculate_mount_desired_velocity(Vector3(0.0, 0.05, 0.0), 2.7, 9.5)
	var braking := MistbornIronController.calculate_mount_velocity_correction(Vector3(0.0, -12.0, 0.0), Vector3(0.0, 5.0, 0.0), 4.8, 28.0)
	var passed := is_equal_approx(fast_goal.length(), 9.5) and near_goal.length() < 0.2 and braking.y > 0.0 and braking.length() <= 28.001
	return _result(
		"IRON_MOUNT_GUIDANCE_MATH",
		passed,
		"Arrival guidance caps approach speed, eases to zero near the perch, and brakes downward motion before landing." if passed else "Mount guidance math failed its speed, settling, or braking contract.",
		{"capped_desired_speed": fast_goal.length(), "near_goal_speed": near_goal.length(), "braking_correction": braking.length(), "braking_y": braking.y}
	)

func _test_iron_upper_cone_quadratic_contract() -> Dictionary:
	var horizontal := MistbornIronController.calculate_upper_cone_factor(Vector3(1.0, 0.0, 0.0), 45.0)
	var edge_factor := MistbornIronController.calculate_upper_cone_factor(Vector3(1.0, 1.0, 0.0), 45.0)
	var diagonal_inside := MistbornIronController.calculate_upper_cone_factor(Vector3(0.5, 1.0, 0.0), 45.0)
	var straight_up := MistbornIronController.calculate_upper_cone_factor(Vector3.UP, 45.0)
	var base_multiplier := MistbornIronController.calculate_quadratic_multiplier(1.0, 1.15, 0.0)
	var peak_multiplier := MistbornIronController.calculate_quadratic_multiplier(1.0, 1.15, 1.0)
	var passed := is_zero_approx(horizontal) and is_zero_approx(edge_factor) and diagonal_inside > 0.0 and is_equal_approx(straight_up, 1.0) and is_equal_approx(base_multiplier, 1.0) and is_equal_approx(peak_multiplier, 2.15)
	return _result(
		"IRON_UPPER_CONE_QUADRATIC",
		passed,
		"Iron boost is zero outside the upward cone, ramps inside it, and reaches 2.15x only at the cone center." if passed else "Iron upper-cone quadratic math does not match the active contract.",
		{"horizontal_factor": horizontal, "edge_factor": edge_factor, "diagonal_inside_factor": diagonal_inside, "up_factor": straight_up, "base_multiplier": base_multiplier, "peak_multiplier": peak_multiplier}
	)

func _test_mass_support_response() -> Dictionary:
	var free_coin_player_response: bool = MistbornAllomanticForceModel.player_receives_response(75.0, 0.03)
	var supported_mass: float = MistbornAllomanticForceModel.effective_interaction_mass(0.03, MistbornAllomanticForceModel.STATIC_EFFECTIVE_MASS)
	var supported_player_response: bool = MistbornAllomanticForceModel.player_receives_response(75.0, supported_mass)
	var passed: bool = not free_coin_player_response and supported_mass > MistbornAllomanticForceModel.PLAYER_MASS and supported_player_response
	return _result(
		"ALLOMANCY_MASS_SUPPORT_RESPONSE",
		passed,
		"A light target becomes heavy when blocked by static ground/support because masses are summed." if passed else "Blocked-support binary mass response did not resolve correctly.",
		{"free_coin_player_response": free_coin_player_response, "supported_effective_mass": supported_mass, "supported_player_response": supported_player_response}
	)

func _test_mass_response_distribution() -> Dictionary:
	var coin_player_response := MistbornAllomanticForceModel.player_receives_response(75.0, 0.03)
	var object_player_response := MistbornAllomanticForceModel.player_receives_response(75.0, 25.0)
	var anchor_player_response := MistbornAllomanticForceModel.player_receives_response(75.0, MistbornAllomanticForceModel.STATIC_EFFECTIVE_MASS)
	var equal_player_response := MistbornAllomanticForceModel.player_receives_response(75.0, 75.0)
	var passed := not coin_player_response and not object_player_response and anchor_player_response and equal_player_response
	return _result(
		"ALLOMANCY_MASS_RESPONSE_DISTRIBUTION",
		passed,
		"Light coins/objects receive the reaction; anchors and equal-mass targets move the player." if passed else "Mass-response distribution differs from the approved binary mass contract.",
		{
			"coin_player_response": coin_player_response,
			"object_player_response": object_player_response,
			"anchor_player_response": anchor_player_response,
			"equal_mass_player_response": equal_player_response
		}
	)

func _test_player_visual_boot() -> Dictionary:
	var visual := _player.get_node_or_null("Visual") as MistbornExternalCharacter
	if visual == null:
		return _result("PLAYER_VISUAL_BOOT", false, "Player Visual node or external-character bridge missing.", {})
	var model := visual.get_character_instance()
	var mesh_count := 0
	if model != null:
		mesh_count = model.find_children("*", "MeshInstance3D", true, false).size()
	var visible_model := visual.visible and model != null and model.visible and mesh_count >= 1
	return _result(
		"PLAYER_VISUAL_BOOT",
		visible_model,
		"A visible imported character or procedural proxy is available for manual feel validation." if visible_model else "Player has no visible model/proxy; manual visual feel validation is blocked.",
		{"visual_visible": visual.visible, "model_name": model.name if model != null else "NONE", "mesh_count": mesh_count, "procedural_proxy": model != null and model.name == "ProceduralMistbornProxy"}
	)

func _test_boot_and_input() -> Dictionary:
	var required := [
		"move_forward", "move_backward", "move_left", "move_right",
		"jump", "sprint", "crouch", "toggle_debug", "target_sight"
	]
	var missing: Array[String] = []
	for action in required:
		if not InputMap.has_action(action):
			missing.append(action)
	var coordinate_label: Label = _main.get_node_or_null("CoordinateReadoutLayer/Coordinates") as Label
	var passed: bool = _player != null and _camera != null and coordinate_label != null and missing.is_empty()
	return _result(
		"PLAYER_CORE_BOOT",
		passed,
		"Player, camera, coordinate readout and core input actions loaded." if passed else "Missing runtime dependencies, coordinate readout or input actions.",
		{"missing_actions": missing.size(), "camera_ready": _camera != null, "player_ready": _player != null, "coordinates_ready": coordinate_label != null}
	)

func _test_walk() -> Dictionary:
	await _reset_player(GROUND_POS)
	var start: Vector3 = _player.global_position
	await _hold_forward(1.2, false)
	var distance: float = start.distance_to(_player.global_position)
	var speed: float = _horizontal_speed()
	var passed: bool = distance > 3.5 and speed > 3.5
	return _result("PLAYER_CORE_WALK", passed, "Walk reaches a stable travel speed." if passed else "Walk displacement/speed below expected baseline.", {"distance_m": distance, "speed_mps": speed})

func _test_sprint() -> Dictionary:
	await _reset_player(GROUND_POS)
	var start: Vector3 = _player.global_position
	await _hold_forward(1.2, true)
	var distance: float = start.distance_to(_player.global_position)
	var speed: float = _horizontal_speed()
	var passed := distance > 5.8 and speed > 5.8
	return _result("PLAYER_CORE_SPRINT", passed, "Sprint produces materially higher grounded speed." if passed else "Sprint speed/displacement below expected baseline.", {"distance_m": distance, "speed_mps": speed})

func _test_braking() -> Dictionary:
	await _reset_player(GROUND_POS)
	await _hold_forward(0.8, true)
	var peak_speed := _horizontal_speed()
	var start: Vector3 = _player.global_position
	await _wait_seconds(0.75)
	var end_speed := _horizontal_speed()
	var braking_distance := start.distance_to(_player.global_position)
	var passed := peak_speed > 5.8 and end_speed < 0.65
	return _result("PLAYER_CORE_BRAKING", passed, "Ground deceleration returns the player close to rest." if passed else "Player keeps too much residual speed after release.", {"peak_speed_mps": peak_speed, "end_speed_mps": end_speed, "braking_distance_m": braking_distance})

func _test_turning() -> Dictionary:
	await _reset_player(GROUND_POS)
	Input.action_press("move_forward")
	await _wait_seconds(0.45)
	Input.action_release("move_forward")
	Input.action_press("move_left")
	await _wait_seconds(0.75)
	Input.action_release("move_left")
	await _wait_seconds(0.12)
	var velocity_dir := Vector3(_player.velocity.x, 0.0, _player.velocity.z)
	var visual := _player.get_node_or_null("Visual") as Node3D
	if velocity_dir.length_squared() <= 0.04 or visual == null:
		return _result("PLAYER_CORE_TURNING", false, "Insufficient movement data for facing test.", {})
	velocity_dir = velocity_dir.normalized()
	var facing := -visual.global_transform.basis.z
	facing.y = 0.0
	facing = facing.normalized()
	var alignment := facing.dot(velocity_dir)
	var passed := alignment > 0.88
	return _result("PLAYER_CORE_TURNING", passed, "Character facing follows travel direction." if passed else "Character facing lags too far behind travel direction.", {"facing_alignment": alignment})

func _test_jump() -> Dictionary:
	await _reset_player(GROUND_POS)
	var grounded_at_start: bool = await _wait_for_player_grounded()
	if not grounded_at_start:
		return _result("PLAYER_CORE_JUMP", false, "Test fixture never settled on the ground.", {"start_position": _player.global_position})
	var base_y: float = _player.global_position.y
	await _press_jump()
	var max_y: float = base_y
	var air_time: float = 0.0
	var safety := 0
	while safety < 180:
		max_y = maxf(max_y, _player.global_position.y)
		if _player.is_on_floor() and air_time > 0.12:
			break
		await _wait_physics_updates(1)
		air_time += 1.0 / 60.0
		safety += 1
	var height: float = max_y - base_y
	var passed: bool = height >= 0.95 and height <= 1.45 and air_time >= 0.55 and air_time <= 0.92 and _player.is_on_floor()
	return _result("PLAYER_CORE_JUMP", passed, "Snappy normal jump reaches a useful height and lands decisively." if passed else "Jump height or airborne duration is outside the calibrated feel window.", {"height_m": height, "air_time_s": air_time, "landed": _player.is_on_floor(), "grounded_at_start": grounded_at_start, "target_air_time_s": "0.55–0.92"})

func _test_coyote_time() -> Dictionary:
	# Vector3.FORWARD is -Z. Start near the -Z edge so forward input exits the platform.
	await _reset_player(TEST_PLATFORM_POS + Vector3(0.0, TEST_PLATFORM_SIZE.y * 0.5, -1.65))
	var grounded_before: bool = await _wait_for_player_grounded()
	if not grounded_before:
		return _result("PLAYER_CORE_COYOTE", false, "Test fixture never settled on the elevated platform.", {"start_position": _player.global_position})
	Input.action_press("move_forward")
	var left_platform := false
	for _step in range(90):
		await _wait_physics_updates(1)
		if not _player.is_on_floor():
			left_platform = true
			break
	Input.action_release("move_forward")
	if not left_platform:
		return _result("PLAYER_CORE_COYOTE", false, "Player did not leave the platform edge during the test window.", {"position": _player.global_position})
	await _wait_seconds(0.08)
	await _press_jump()
	var launched: bool = _player.velocity.y > 1.0
	var passed: bool = launched
	return _result("PLAYER_CORE_COYOTE", passed, "Jump is accepted shortly after leaving the platform." if passed else "Coyote-time jump was not accepted.", {"vertical_speed_after_input": _player.velocity.y, "height_above_platform_m": _player.global_position.y - TEST_PLATFORM_TOP_Y, "coyote_left_s": _player.get_debug_state().get("coyote_left", -1.0)})

func _test_jump_buffer() -> Dictionary:
	await _reset_player(TEST_PLATFORM_POS + Vector3(0.0, TEST_PLATFORM_SIZE.y * 0.5, 0.0))
	var grounded_at_start: bool = await _wait_for_player_grounded()
	if not grounded_at_start:
		return _result("PLAYER_CORE_JUMP_BUFFER", false, "Test fixture never settled on the elevated platform.", {"start_position": _player.global_position})
	await _press_jump()
	var first_jump_velocity: float = _player.velocity.y
	var peak_y: float = _player.global_position.y
	var descending := false
	var estimated_time_to_landing := -1.0
	var safety := 0
	while safety < 180:
		peak_y = maxf(peak_y, _player.global_position.y)
		var drop := maxf(_player.global_position.y - TEST_PLATFORM_TOP_Y, 0.0)
		var down_speed := maxf(-_player.velocity.y, 0.0)
		# Estimate landing time from the actual vertical state under normal gravity.
		var remaining_time := (sqrt(down_speed * down_speed + 2.0 * _player.gravity * drop) - down_speed) / maxf(_player.gravity, 0.001)
		# Do not mistake the first grounded frame (drop == 0, negative contact velocity)
		# for a valid pre-landing buffer window. Higher gravity makes that discrete edge
		# case more likely, which can turn the test into an ordinary ground jump.
		if not _player.is_on_floor() and _player.velocity.y < 0.0 and remaining_time <= _player.jump_buffer_time and drop > 0.0:
			descending = true
			estimated_time_to_landing = remaining_time
			break
		await _wait_physics_updates(1)
		safety += 1
	if not descending:
		return _result("PLAYER_CORE_JUMP_BUFFER", false, "Could not sample an airborne frame inside the configured jump-buffer window; the fixture may have skipped directly to floor contact.", {"grounded_at_start": grounded_at_start, "first_jump_velocity": first_jump_velocity, "peak_y": peak_y, "final_y": _player.global_position.y, "final_vertical_speed": _player.velocity.y, "on_floor": _player.is_on_floor(), "jump_buffer_time": _player.jump_buffer_time})

	var coyote_left_at_input: float = float(_player.get_debug_state().get("coyote_left", -1.0))
	# Send the buffered input for exactly one physics update, then observe the jump
	# impulse directly. Do not wait for a floor state first: if the buffered jump fires
	# during this helper, a test that only looks for the *next* landing misses it.
	Input.action_press("jump")
	await _wait_physics_updates(1)
	var buffer_left_after_input: float = float(_player.get_debug_state().get("jump_buffer_left", -1.0))
	var velocity_after_input: float = _player.velocity.y
	var floor_after_input: bool = _player.is_on_floor()
	Input.action_release("jump")

	var second_jump_detected: bool = not _player.is_on_floor() and _player.velocity.y >= _player.jump_velocity * 0.5
	var landed_during_observation := false
	var frames_to_second_jump := 0 if second_jump_detected else -1
	safety = 0
	while not second_jump_detected and safety < 36:
		if _player.is_on_floor():
			landed_during_observation = true
		await _wait_physics_updates(1)
		safety += 1
		if not _player.is_on_floor() and _player.velocity.y >= _player.jump_velocity * 0.5:
			second_jump_detected = true
			frames_to_second_jump = safety
	var passed: bool = second_jump_detected and coyote_left_at_input <= 0.02 and estimated_time_to_landing <= _player.jump_buffer_time and buffer_left_after_input > 0.0
	return _result(
		"PLAYER_CORE_JUMP_BUFFER",
		passed,
		"Buffered jump is queued while airborne and launches on/after first floor contact." if passed else "Buffered jump was not observed launching from a valid pre-landing input; inspect timing and buffer state.",
		{
			"second_jump": second_jump_detected,
			"first_jump_velocity": first_jump_velocity,
			"peak_y": peak_y,
			"estimated_time_to_landing_at_input_s": estimated_time_to_landing,
			"jump_buffer_time_s": _player.jump_buffer_time,
			"coyote_left_at_input_s": coyote_left_at_input,
			"buffer_left_after_input_s": buffer_left_after_input,
			"vertical_velocity_after_input_mps": velocity_after_input,
			"floor_after_input": floor_after_input,
			"landed_during_observation": landed_during_observation,
			"frames_to_second_jump": frames_to_second_jump,
			"observation_limit_frames": 36
		}
	)

func _test_crouch() -> Dictionary:
	await _reset_player(GROUND_POS)
	Input.action_press("crouch")
	await _wait_seconds(0.20)
	var crouched: bool = _player.is_crouching()
	var shape := _player.get_node_or_null("CollisionShape3D") as CollisionShape3D
	var capsule := shape.shape as CapsuleShape3D if shape != null else null
	var low_height: bool = capsule != null and capsule.height < _player.standing_height
	Input.action_release("crouch")
	await _wait_seconds(0.20)
	var restored: bool = not _player.is_crouching()
	var passed: bool = crouched and low_height and restored
	return _result("PLAYER_CORE_CROUCH", passed, "Crouch changes the capsule and restores cleanly." if passed else "Crouch state/geometry did not transition correctly.", {"crouched": crouched, "low_height": low_height, "restored": restored})

func _test_camera_fov() -> Dictionary:
	await _reset_player(GROUND_POS)
	var camera_node := _player.get_node_or_null("CameraRig/Camera3D") as Camera3D
	if camera_node == null:
		return _result("PLAYER_CORE_CAMERA_FOV", false, "Camera3D not found.", {})
	var base_fov: float = camera_node.fov
	await _hold_forward(0.95, true)
	var sprint_fov: float = camera_node.fov
	var passed: bool = sprint_fov > base_fov + 0.4
	return _result("PLAYER_CORE_CAMERA_FOV", passed, "Sprint changes FOV enough to communicate speed." if passed else "Sprint FOV response is too small or missing.", {"base_fov": base_fov, "sprint_fov": sprint_fov})


func _find_target_node(node_name: String) -> MistbornTargetable:
	if _main == null:
		return null
	return _main.get_node_or_null(node_name) as MistbornTargetable

func _test_steel_power() -> Dictionary:
	# A fresh Q press fixes one target; holding Q sustains the interaction without retargeting.
	await _reset_player(Vector3(0.0, 4.0, 108.0), 0.0)
	var target := _find_target_node("Target_RoofAnchor_Low")
	var steel := _player.get_node_or_null("Steel") as MistbornSteelController
	var targeting := _player.get_node_or_null("Targeting") as MistbornTargetingController
	if target == null or steel == null or targeting == null:
		return _result("ALLOMANCY_STEEL_POWER", false, "Steel regression test target/controller missing.", {})
	var before_count: int = int(steel.get_debug_state().get("impulse_count", 0))
	Input.action_press("steel_push")
	await _wait_physics_updates(1)
	var first_target_name: String = str(steel.get_debug_state().get("target_name", "NINGUNO"))
	var after_first_count: int = int(steel.get_debug_state().get("impulse_count", 0))
	await _wait_seconds(0.22)
	var held_count: int = int(steel.get_debug_state().get("impulse_count", 0))
	var held_target_name: String = str(steel.get_debug_state().get("target_name", "NINGUNO"))
	var held_active: bool = bool(steel.get_debug_state().get("active", false))
	Input.action_release("steel_push")
	await _wait_seconds(0.04)
	var released_active: bool = bool(steel.get_debug_state().get("active", false))
	var passed: bool = after_first_count > before_count and held_count > after_first_count and held_target_name == first_target_name and held_active and not released_active
	return _result("ALLOMANCY_STEEL_POWER", passed, "Steel sustains one fixed-target interaction while held and stops on release." if passed else "Steel did not sustain its fixed target correctly or kept running after release.", {"interactions_after_press": after_first_count - before_count, "interactions_while_held": held_count - before_count, "target_stable": held_target_name == first_target_name, "active_while_held": held_active, "active_after_release": released_active})

func _test_steel_counterfall_force_math() -> Dictionary:
	# Simulate discrete physics ticks with full gravity. Steel counters the fall only
	# through the ordinary force path; once extra strength is needed, the strength stays
	# latched for the held target so it does not vanish at velocity ~= 0 and cause jitter.
	var base_strength := MistbornAllomanticForceModel.HERO_STRENGTH
	var distance := 20.0
	var initial_fall_speed := -8.0
	var reaction := Vector3(0.0, 0.8, 0.0)
	var candidate_strength := MistbornAllomanticForceModel.calculate_steel_counterfall_strength(
		base_strength, distance, 75.0, 14.0, initial_fall_speed, reaction, true, 0.42, 8.0, 0.45
	)
	var latched_scale := maxf(candidate_strength / base_strength, 1.0)
	var velocity_y := initial_fall_speed
	var simulated_time := 0.0
	var reached_zero := false
	for _tick in range(120):
		var applied_strength := base_strength * latched_scale
		var upward_acceleration := MistbornAllomanticForceModel.force_magnitude(distance, applied_strength) / 75.0 * reaction.y
		velocity_y += (upward_acceleration - 14.0) / 60.0
		simulated_time += 1.0 / 60.0
		if velocity_y >= 0.0:
			reached_zero = true
			break
	var base_only_acceleration := MistbornAllomanticForceModel.force_magnitude(distance, base_strength) / 75.0 * reaction.y - 14.0
	var free_coin_strength := MistbornAllomanticForceModel.calculate_steel_counterfall_strength(
		base_strength, distance, 75.0, 14.0, initial_fall_speed, reaction, false, 0.42, 8.0, 0.45
	)
	var rising_strength := MistbornAllomanticForceModel.calculate_steel_counterfall_strength(
		base_strength, distance, 75.0, 14.0, 5.0, reaction, true, 0.42, 8.0, 0.45
	)
	var lateral_strength := MistbornAllomanticForceModel.calculate_steel_counterfall_strength(
		base_strength, distance, 75.0, 14.0, initial_fall_speed, Vector3.RIGHT, true, 0.42, 8.0, 0.45
	)
	var fast_distance := 35.0
	var fast_candidate := MistbornAllomanticForceModel.calculate_steel_counterfall_strength(
		base_strength, fast_distance, 75.0, 14.0, -20.0, Vector3(0.0, 0.7, 0.0), true, 0.42, 8.0, 0.45
	)
	var fast_net_acceleration := MistbornAllomanticForceModel.force_magnitude(fast_distance, fast_candidate) / 75.0 * 0.7 - 14.0
	var fast_stop_time := 20.0 / fast_net_acceleration if fast_net_acceleration > 0.0 else INF
	var passed := latched_scale > 1.0 and latched_scale <= 8.0 and reached_zero and simulated_time <= 0.45 and base_only_acceleration < 0.0 and is_equal_approx(free_coin_strength, base_strength) and is_equal_approx(rising_strength, base_strength) and is_equal_approx(lateral_strength, base_strength) and fast_candidate <= base_strength * 8.0 and fast_net_acceleration > 0.0 and fast_stop_time < 0.8
	return _result(
		"STEEL_COUNTERFALL_REAL_FORCE",
		passed,
		"With full gravity running, the held Steel force is strong enough to arrest the simulated fall; the force multiplier latches for the active action to avoid a fake brake or zero-velocity jitter." if passed else "Steel counter-fall did not arrest the falling test body within the calibrated window, or boosted an ineligible response.",
		{
			"strength_scale_at_20m": latched_scale,
			"fall_minus_8_stopped": reached_zero,
			"estimated_stop_time_at_8mps": simulated_time,
			"base_force_net_vertical_acceleration": base_only_acceleration,
			"fast_fall_strength_scale": fast_candidate / base_strength,
			"estimated_stop_time_at_20mps_35m": fast_stop_time,
			"free_coin_strength_unchanged": is_equal_approx(free_coin_strength, base_strength),
			"rising_strength_unchanged": is_equal_approx(rising_strength, base_strength),
			"lateral_strength_unchanged": is_equal_approx(lateral_strength, base_strength)
		}
	)

func _test_steel_grounded_coin_anchor_policy() -> Dictionary:
	var lateral_grounded_support := MistbornAllomanticForceModel.grounded_coin_anchor_mass(&"steel", "COIN", true)
	var vertical_grounded_support := MistbornAllomanticForceModel.grounded_coin_anchor_mass(&"steel", "COIN", true)
	var airborne_coin_support := MistbornAllomanticForceModel.grounded_coin_anchor_mass(&"steel", "COIN", false)
	var grounded_coin_iron_support := MistbornAllomanticForceModel.grounded_coin_anchor_mass(&"iron", "COIN", true)
	var grounded_box_support := MistbornAllomanticForceModel.grounded_coin_anchor_mass(&"steel", "BOX", true)
	var passed := lateral_grounded_support == MistbornAllomanticForceModel.STATIC_EFFECTIVE_MASS and vertical_grounded_support == MistbornAllomanticForceModel.STATIC_EFFECTIVE_MASS and is_zero_approx(airborne_coin_support) and is_zero_approx(grounded_coin_iron_support) and is_zero_approx(grounded_box_support)
	return _result(
		"STEEL_GROUNDED_COIN_ANCHOR_POLICY",
		passed,
		"A coin on firm ground is a full Steel anchor regardless of push angle; airborne coins stay light, and this exception does not alter Iron or other objects." if passed else "Grounded coin support policy deviated from the agreed Steel rule.",
		{"lateral_grounded_support": lateral_grounded_support, "vertical_grounded_support": vertical_grounded_support, "airborne_coin_support": airborne_coin_support, "grounded_coin_iron_support": grounded_coin_iron_support, "grounded_box_support": grounded_box_support}
	)


func _test_iron_power() -> Dictionary:
	await _reset_player(GROUND_POS, 0.0)
	var target := _find_target_node("Target_RoofAnchor_High")
	var iron := _player.get_node_or_null("Iron") as MistbornIronController
	var targeting := _player.get_node_or_null("Targeting") as MistbornTargetingController
	if target == null or iron == null or targeting == null:
		return _result("ALLOMANCY_IRON_POWER", false, "Iron regression test target/controller missing.", {})
	var before_count: int = int(iron.get_debug_state().get("impulse_count", 0))
	Input.action_press("iron_pull")
	await _wait_physics_updates(1)
	var first_target_name: String = str(iron.get_debug_state().get("target_name", "NINGUNO"))
	var after_first_count: int = int(iron.get_debug_state().get("impulse_count", 0))
	await _wait_seconds(0.22)
	var held_count: int = int(iron.get_debug_state().get("impulse_count", 0))
	var held_target_name: String = str(iron.get_debug_state().get("target_name", "NINGUNO"))
	var held_active: bool = bool(iron.get_debug_state().get("active", false))
	Input.action_release("iron_pull")
	await _wait_seconds(0.04)
	var released_active: bool = bool(iron.get_debug_state().get("active", false))
	var passed: bool = after_first_count > before_count and held_count > after_first_count and held_target_name == first_target_name and held_active and not released_active
	return _result("ALLOMANCY_IRON_POWER", passed, "Iron sustains one fixed-target interaction while held and stops on release." if passed else "Iron did not sustain its fixed target correctly or kept running after release.", {"interactions_after_press": after_first_count - before_count, "interactions_while_held": held_count - before_count, "target_stable": held_target_name == first_target_name, "active_while_held": held_active, "active_after_release": released_active})

func _test_steel_coin_interaction() -> Dictionary:
	await _reset_player(GROUND_POS, 0.0)
	var steel := _player.get_node_or_null("Steel") as MistbornSteelController
	var traversal := _player.get_node_or_null("Traversal") as MistbornTraversalController
	var targeting := _player.get_node_or_null("Targeting") as MistbornTargetingController
	if steel == null or traversal == null or targeting == null:
		return _result("ALLOMANCY_STEEL_COIN_INTERACTION", false, "Steel/Traversal/Targeting dependencies missing.", {})

	# First Space is the ordinary jump; the second starts an actual sustained Steelpush
	# on the spawned coin. The coin must receive multiple force ticks in descent and
	# multiple force ticks after real ground contact; no impulse/velocity shortcut is valid.
	var responses_before := int(steel.get_debug_state().get("special_coin_interaction_count", 0))
	Input.action_press("jump")
	await _wait_physics_updates(1)
	var first_jump_velocity := _player.velocity.y
	Input.action_release("jump")
	await _wait_seconds(0.06)

	Input.action_press("jump")
	await _wait_physics_updates(1)
	var coin: MistbornCoin = null
	for child in _player.get_parent().get_children():
		if child is MistbornCoin and bool(child.get_debug_state().get("steel_special_response_pending", false)):
			if int(child.get_debug_state().get("steel_special_force_ticks", 0)) > 0:
				coin = child
				break
	var special_exists := coin != null
	var first_descent_ticks := int(coin.get_debug_state().get("steel_special_force_ticks", 0)) if coin != null else 0
	var first_ground_ticks_initial := int(coin.get_debug_state().get("steel_special_ground_force_ticks", 0)) if coin != null else 0
	var coin_target := coin.get_targetable() if coin != null else null
	var same_steel_action := traversal.get_traversal_state() != "FLIGHT_COIN" and targeting.is_action_target_active() and targeting.is_steel_action_active() and targeting.get_action_target() == coin_target and coin_target != null and String(coin_target.get_meta("allomantic_steel_interaction_mode", "")) == "COIN_JUMP" and String(steel.get_debug_state().get("force_model", "")) == "shared_radial_force_and_counterfall_force_scaling"
	Input.action_release("jump")

	var first_response_received := false
	var velocity_at_first_response := _player.velocity.y
	for _frame in range(45):
		await _wait_physics_updates(1)
		var response_count := int(steel.get_debug_state().get("special_coin_interaction_count", 0))
		if response_count > responses_before:
			first_response_received = true
			velocity_at_first_response = _player.velocity.y
			break
	var velocity_after_sustain := _player.velocity.y
	for _frame in range(6):
		await _wait_physics_updates(1)
		velocity_after_sustain = _player.velocity.y
	var first_ground_ticks := int(coin.get_debug_state().get("steel_special_ground_force_ticks", 0)) if coin != null and is_instance_valid(coin) else 0
	var first_sustained_response := first_response_received and first_ground_ticks > first_ground_ticks_initial and velocity_after_sustain > velocity_at_first_response + 0.25

	# Repeat Space×2 while airborne. The second coin must independently receive a
	# sustained downward Steelpush and then a sustained, floor-blocked response.
	var second_responses_before := int(steel.get_debug_state().get("special_coin_interaction_count", 0))
	Input.action_press("jump")
	await _wait_physics_updates(1)
	Input.action_release("jump")
	await _wait_physics_updates(1)
	Input.action_press("jump")
	await _wait_physics_updates(1)
	var second_coin: MistbornCoin = null
	for child in _player.get_parent().get_children():
		if child is MistbornCoin and child != coin:
			if bool(child.get_debug_state().get("steel_special_response_pending", false)) and int(child.get_debug_state().get("steel_special_force_ticks", 0)) > 0:
				second_coin = child
				break
	var second_coin_created := second_coin != null
	var second_descent_ticks := int(second_coin.get_debug_state().get("steel_special_force_ticks", 0)) if second_coin != null else 0
	var second_ground_ticks_initial := int(second_coin.get_debug_state().get("steel_special_ground_force_ticks", 0)) if second_coin != null else 0
	Input.action_release("jump")

	var second_response_received := false
	var velocity_at_second_response := _player.velocity.y
	for _frame in range(45):
		await _wait_physics_updates(1)
		var response_count_after := int(steel.get_debug_state().get("special_coin_interaction_count", 0))
		if response_count_after > second_responses_before:
			second_response_received = true
			velocity_at_second_response = _player.velocity.y
			break
	var velocity_after_second_sustain := _player.velocity.y
	for _frame in range(6):
		await _wait_physics_updates(1)
		velocity_after_second_sustain = _player.velocity.y
	var second_ground_ticks := int(second_coin.get_debug_state().get("steel_special_ground_force_ticks", 0)) if second_coin != null and is_instance_valid(second_coin) else 0
	var second_sustained_response := second_response_received and second_ground_ticks > second_ground_ticks_initial and velocity_after_second_sustain > velocity_at_second_response + 0.25

	var passed := special_exists and first_descent_ticks > 0 and same_steel_action and first_sustained_response and second_coin_created and second_descent_ticks > 0 and second_sustained_response
	return _result(
		"ALLOMANCY_STEEL_COIN_INTERACTION",
		passed,
		"Both Space×2 coins received sustained downward Steel force and a continued force-based upward response after real ground contact." if passed else "A Coin Steelpush failed to sustain force during descent or after the coin was blocked by the floor.",
		{
			"first_jump_velocity": first_jump_velocity,
			"velocity_at_first_response": velocity_at_first_response,
			"velocity_after_first_sustain": velocity_after_sustain,
			"first_coin_created": special_exists,
			"coin_jump_uses_same_steel_action": same_steel_action,
			"first_descent_force_ticks": first_descent_ticks,
			"first_ground_force_ticks": first_ground_ticks,
			"first_response_received": first_response_received,
			"first_sustained_response": first_sustained_response,
			"second_coin_created": second_coin_created,
			"second_descent_force_ticks": second_descent_ticks,
			"second_ground_force_ticks": second_ground_ticks,
			"second_response_received": second_response_received,
			"second_sustained_response": second_sustained_response
		}
	)

func _test_coin_jump_handoff_to_iron() -> Dictionary:
	var steel := _player.get_node_or_null("Steel") as MistbornSteelController
	var iron := _player.get_node_or_null("Iron") as MistbornIronController
	if steel == null or iron == null:
		return _result("ALLOMANCY_COIN_JUMP_HANDOFF", false, "Steel/Iron controller missing.", {})

	# Shared helper pattern is intentionally repeated so each hand-off starts from a
	# fresh player/input state. Coin Jump must yield to the newly selected action.
	await _reset_player(GROUND_POS, 0.0)
	Input.action_press("jump")
	await _wait_physics_updates(1)
	Input.action_release("jump")
	await _wait_seconds(0.06)
	Input.action_press("jump")
	await _wait_physics_updates(2)
	var started_for_iron := steel.is_coin_jump_active()
	Input.action_press("iron_pull")
	await _wait_physics_updates(2)
	var yielded_to_iron := started_for_iron and not steel.is_coin_jump_active() and _player.owns_allomancy_input(&"iron")
	var iron_started := iron.is_active()
	Input.action_release("iron_pull")
	Input.action_release("jump")
	await _wait_physics_updates(2)

	await _reset_player(GROUND_POS, 0.0)
	Input.action_press("jump")
	await _wait_physics_updates(1)
	Input.action_release("jump")
	await _wait_seconds(0.06)
	Input.action_press("jump")
	await _wait_physics_updates(2)
	var started_for_steel := steel.is_coin_jump_active()
	Input.action_press("steel_push")
	await _wait_physics_updates(2)
	var yielded_to_steel := started_for_steel and not steel.is_coin_jump_active() and _player.owns_allomancy_input(&"steel")
	Input.action_release("steel_push")
	Input.action_release("jump")
	await _wait_physics_updates(2)

	await _reset_player(GROUND_POS, 0.0)
	Input.action_press("jump")
	await _wait_physics_updates(1)
	Input.action_release("jump")
	await _wait_seconds(0.06)
	Input.action_press("jump")
	await _wait_physics_updates(2)
	var started_for_yank := steel.is_coin_jump_active()
	Input.action_press("iron_yank")
	await _wait_physics_updates(2)
	var yielded_to_yank := started_for_yank and not steel.is_coin_jump_active() and _player.is_allomancy_input_active()
	var yank_active := bool(iron.get_debug_state().get("object_yank_active", false))
	Input.action_release("iron_yank")
	Input.action_release("jump")
	await _wait_physics_updates(2)

	var passed := yielded_to_iron and yielded_to_steel and yielded_to_yank
	return _result(
		"ALLOMANCY_COIN_JUMP_HANDOFF",
		passed,
		"Coin Jump yields its active target/line to a fresh Iron traversal, regular Steel, or exclusive Iron yank input; no second Steel force runs in parallel." if passed else "Coin Jump did not yield correctly to every supported fresh input.",
		{
			"started_for_iron": started_for_iron,
			"yielded_to_iron": yielded_to_iron,
			"iron_traversal_started": iron_started,
			"started_for_steel": started_for_steel,
			"yielded_to_steel": yielded_to_steel,
			"started_for_yank": started_for_yank,
			"yielded_to_yank": yielded_to_yank,
			"heavy_yank_started": yank_active
		}
	)

func _test_camera_auto_follow_math() -> Dictionary:
	var delta := 1.0 / 60.0
	var angle := deg_to_rad(70.0)
	var normal_step := MistbornCameraRig.calculate_auto_follow_yaw_delta(angle, 2.6, delta, 120.0)
	var allomancy_step := MistbornCameraRig.calculate_auto_follow_yaw_delta(angle, 2.6 * 0.32, delta, 75.0)
	var max_allomancy_step := deg_to_rad(75.0) * delta
	var zero_delta_step := MistbornCameraRig.calculate_auto_follow_yaw_delta(angle, 2.6, 0.0, 120.0)
	var passed := normal_step > allomancy_step and allomancy_step > 0.0 and allomancy_step <= max_allomancy_step + 0.00001 and is_zero_approx(zero_delta_step)
	return _result(
		"CAMERA_ALLOMANCY_AUTO_FOLLOW_MATH",
		passed,
		"Allomancy camera-follow stays slower than normal follow, respects its per-frame yaw cap, and does nothing for a zero-duration step." if passed else "Allomancy follow math exceeded its rate cap or failed to remain subordinate to manual camera control.",
		{"normal_yaw_step_deg": rad_to_deg(normal_step), "allomancy_yaw_step_deg": rad_to_deg(allomancy_step), "allomancy_max_step_deg": rad_to_deg(max_allomancy_step), "zero_delta_step": zero_delta_step}
	)

func _test_allomancy_camera_yaw_lock() -> Dictionary:
	await _reset_player(Vector3(0.0, 4.0, 108.0), 0.0)
	var target := _find_target_node("Target_RoofAnchor_Low")
	var targeting := _player.get_node_or_null("Targeting") as MistbornTargetingController
	var camera_rig := _player.get_node_or_null("CameraRig") as MistbornCameraRig
	var steel := _player.get_node_or_null("Steel") as MistbornSteelController
	if target == null or targeting == null or camera_rig == null or steel == null:
		return _result("ALLOMANCY_CAMERA_YAW_LOCK", false, "Camera/Steel regression dependencies missing.", {})
	targeting.begin_action_target(target, &"steel")
	var yaw_before: float = camera_rig.get_debug_state().get("yaw_deg", 0.0)
	# Simulate recent manual mouse input. Camera velocity-follow must yield to this
	# explicit look lock even while an Allomantic action is held.
	camera_rig.set_playtest_look(yaw_before, -12.0)
	Input.action_press("steel_push")
	await _wait_seconds(0.30)
	# The contract is about the camera while an Allomantic action is held.
	# Sampling after release conflated this with the separate, intentional camera
	# follow-to-travel-direction behavior, which can resume as soon as Steel stops.
	var yaw_while_held: float = camera_rig.get_debug_state().get("yaw_deg", 0.0)
	var steel_active_while_held: bool = steel.is_active()
	var yaw_delta_while_held := absf(fposmod(yaw_while_held - yaw_before + 180.0, 360.0) - 180.0)
	Input.action_release("steel_push")
	await _wait_seconds(0.04)
	var yaw_after_release: float = camera_rig.get_debug_state().get("yaw_deg", 0.0)
	var yaw_delta_after_release := absf(fposmod(yaw_after_release - yaw_before + 180.0, 360.0) - 180.0)
	var passed: bool = steel_active_while_held and yaw_delta_while_held < 1.0
	var details := "Camera yaw remains player-controlled while Steel is held; post-release travel-follow is measured separately." if passed else "Camera yaw changed during the held Steel action, or Steel never became active."
	return _result("ALLOMANCY_CAMERA_YAW_LOCK", passed, details, {"yaw_before_deg": yaw_before, "yaw_while_held_deg": yaw_while_held, "yaw_delta_while_held_deg": yaw_delta_while_held, "steel_active_while_held": steel_active_while_held, "yaw_after_release_deg": yaw_after_release, "yaw_delta_after_release_deg": yaw_delta_after_release})

func _horizontal_speed() -> float:
	return Vector3(_player.velocity.x, 0.0, _player.velocity.z).length()

func _test_steel_direction_hard_gate() -> Dictionary:
	var desired := Vector3.FORWARD
	var backward := Vector3.BACK
	var sideways := Vector3.RIGHT
	var upward := Vector3.UP
	var passed: bool = not MistbornTargetingController._is_reaction_forward_or_neutral(desired, backward) and MistbornTargetingController._is_reaction_forward_or_neutral(desired, sideways) and MistbornTargetingController._is_reaction_forward_or_neutral(desired, upward)
	return _result("ALLOMANCY_STEEL_DIRECTION_HARD_GATE", passed, "Backward reactions are hard-discarded; sideways and vertical reactions remain eligible." if passed else "A backward reaction was not hard-discarded.", {"backward_allowed": MistbornTargetingController._is_reaction_forward_or_neutral(desired, backward), "sideways_allowed": MistbornTargetingController._is_reaction_forward_or_neutral(desired, sideways), "vertical_allowed": MistbornTargetingController._is_reaction_forward_or_neutral(desired, upward)})

func _test_allomantic_use_cone() -> Dictionary:
	var forward := Vector3.FORWARD
	var inside := Vector3(0.55, 0.0, -1.0)
	var edge := Vector3(1.0, 0.0, -1.0)
	var outside := Vector3(1.0, 0.0, 0.05)
	var inside_ok := MistbornTargetingController._is_direction_within_cone(forward, inside, 45.0)
	var edge_ok := MistbornTargetingController._is_direction_within_cone(forward, edge, 45.0)
	var outside_ok := MistbornTargetingController._is_direction_within_cone(forward, outside, 45.0)
	var passed: bool = inside_ok and edge_ok and not outside_ok
	return _result("ALLOMANCY_USE_CONE", passed, "Steel/Iron acquisition accepts targets inside the use cone and rejects targets outside it." if passed else "Allomantic use cone classification is incorrect.", {"inside": inside_ok, "edge": edge_ok, "outside": outside_ok, "half_angle_degrees": 45.0})

func _test_traversal_horizontal_only_intent_scoring() -> Dictionary:
	var input_forward := Vector3.FORWARD
	var flat_forward := Vector3.FORWARD
	var forward_up := (Vector3.FORWARD + Vector3.UP * 4.0).normalized()
	var backward_up := (Vector3.BACK + Vector3.UP * 4.0).normalized()
	var forward_score := MistbornTargetingController._horizontal_alignment(input_forward, flat_forward)
	var forward_up_score := MistbornTargetingController._horizontal_alignment(input_forward, forward_up)
	var backward_up_score := MistbornTargetingController._horizontal_alignment(input_forward, backward_up)
	var backward_allowed := MistbornTargetingController._is_reaction_forward_or_neutral(input_forward, backward_up)
	var passed: bool = is_equal_approx(forward_score, forward_up_score) and forward_score > backward_up_score and not backward_allowed
	return _result("ALLOMANCY_TRAVERSAL_HORIZONTAL_ONLY_INTENT", passed, "Traversal acquisition uses only horizontal reaction alignment; vertical reaction does not affect priority." if passed else "Traversal acquisition still depends on vertical reaction or its backward gate is incorrect.", {"forward": forward_score, "forward_up": forward_up_score, "backward_up": backward_up_score, "backward_allowed": backward_allowed})


func _test_steel_iron_single_acquisition_authority() -> Dictionary:
	await _reset_player(GROUND_POS, 0.0)
	var targeting := _player.get_node_or_null("Targeting") as MistbornTargetingController
	var steel := _player.get_node_or_null("Steel") as MistbornSteelController
	var iron := _player.get_node_or_null("Iron") as MistbornIronController
	if targeting == null or steel == null or iron == null:
		return _result("ALLOMANCY_SINGLE_ACQUISITION_AUTHORITY", false, "Targeting/Steel/Iron controller missing.", {})
	Input.action_press("steel_push")
	await _wait_physics_updates(1)
	var steel_active: bool = steel.is_active()
	var steel_target: String = str(steel.get_debug_state().get("target_name", "NINGUNO"))
	Input.action_release("steel_push")
	await _wait_seconds(0.04)
	var released: bool = not steel.is_active()
	Input.action_press("iron_pull")
	await _wait_physics_updates(1)
	var iron_active: bool = iron.is_active()
	var iron_target: String = str(iron.get_debug_state().get("target_name", "NINGUNO"))
	Input.action_release("iron_pull")
	var passed: bool = steel_active and released and iron_active and steel_target != "NINGUNO" and iron_target != "NINGUNO"
	return _result("ALLOMANCY_SINGLE_ACQUISITION_AUTHORITY", passed, "Steel/Iron acquire through the same explicit Targeting authority and release rearms selection." if passed else "Steel/Iron acquisition did not use the shared action-target path cleanly.", {"steel_target": steel_target, "iron_target": iron_target, "steel_active": steel_active, "iron_active": iron_active, "released": released})

func _test_allomancy_input_handoff() -> Dictionary:
	await _reset_player(GROUND_POS, 0.0)
	var steel := _player.get_node_or_null("Steel") as MistbornSteelController
	var iron := _player.get_node_or_null("Iron") as MistbornIronController
	if steel == null or iron == null:
		return _result("ALLOMANCY_INPUT_HANDOFF", false, "Steel/Iron controller missing.", {})

	# Steel -> Iron: the newest press owns inputs without requiring both buttons to be released.
	Input.action_press("steel_push")
	await _wait_physics_updates(2)
	var steel_initially_active := steel.is_active() and _player.owns_allomancy_input(&"steel")
	Input.action_press("iron_pull")
	await _wait_physics_updates(2)
	var iron_took_over := iron.is_active() and not steel.is_active() and _player.owns_allomancy_input(&"iron")
	Input.action_release("iron_pull")
	await _wait_physics_updates(2)
	var no_silent_steel_resumption := not iron.is_active() and not steel.is_active()
	Input.action_release("steel_push")
	await _wait_physics_updates(1)

	# Iron -> Steel: same ownership rule in the opposite direction.
	Input.action_press("iron_pull")
	await _wait_physics_updates(2)
	var iron_rearmed := iron.is_active() and _player.owns_allomancy_input(&"iron")
	Input.action_press("steel_push")
	await _wait_physics_updates(2)
	var steel_took_over := steel.is_active() and not iron.is_active() and _player.owns_allomancy_input(&"steel")
	Input.action_release("steel_push")
	await _wait_physics_updates(2)
	var no_silent_iron_resumption := not iron.is_active() and not steel.is_active()
	Input.action_release("iron_pull")
	await _wait_physics_updates(1)

	Input.action_press("steel_push")
	await _wait_physics_updates(2)
	var fresh_steel_press_works := steel.is_active() and not iron.is_active() and _player.owns_allomancy_input(&"steel")
	Input.action_release("steel_push")
	Input.action_release("iron_pull")
	await _wait_physics_updates(2)
	var passed := steel_initially_active and iron_took_over and no_silent_steel_resumption and iron_rearmed and steel_took_over and no_silent_iron_resumption and fresh_steel_press_works
	return _result(
		"ALLOMANCY_INPUT_HANDOFF",
		passed,
		"Both Iron→Steel and Steel→Iron handoffs transfer input ownership immediately, preserve momentum, and never resume an older held input silently." if passed else "Bidirectional Steel/Iron handoff or fresh-press rearming is incorrect.",
		{
			"steel_initially_active": steel_initially_active,
			"iron_took_over": iron_took_over,
			"no_silent_steel_resumption": no_silent_steel_resumption,
			"iron_rearmed": iron_rearmed,
			"steel_took_over": steel_took_over,
			"no_silent_iron_resumption": no_silent_iron_resumption,
			"fresh_steel_press_works": fresh_steel_press_works,
			"final_input_owner": str(_player.get_allomancy_input_owner())
		}
	)

func _test_tall_lamp_mount_contract() -> Dictionary:
	var lamp := _main.get_node_or_null("LuthadelLamp_00") as Node3D
	if lamp == null:
		return _result("WORLD_TALL_LAMP_MOUNTABLE", false, "Tall lamp root missing.", {})
	var tip_root := lamp.get_node_or_null("AllomanticTip") as Node3D
	var tip_target := tip_root.get_node_or_null("Target_LuthadelLamp_00_tip") as MistbornTargetable if tip_root != null else null
	var physical_body := tip_target.get_physical_body() if tip_target != null else null
	var mountable: bool = tip_target != null and tip_target.is_mountable_on_arrival()
	var support_shapes := 0
	if physical_body != null:
		for child in physical_body.get_children():
			if child is CollisionShape3D:
				support_shapes += 1
	var passed: bool = mountable and support_shapes >= 4
	return _result("WORLD_TALL_LAMP_MOUNTABLE", passed, "Tall lamp tip exposes a mountable arrival contract and a dedicated perch surface." if passed else "Tall lamp tip is not fully configured as a mountable perch.", {"mountable": mountable, "support_shapes": support_shapes})

func _test_generic_metal_perch_contract() -> Dictionary:
	var broad_anchor := _main.get_node_or_null("Target_RoofAnchor_High") as MistbornTargetable
	var narrow_rail := _main.get_node_or_null("Target_Rail_W_00") as MistbornTargetable
	var broad_mountable := broad_anchor != null and broad_anchor.is_mountable_on_arrival()
	var rail_not_mountable := narrow_rail != null and not narrow_rail.is_mountable_on_arrival()
	var passed := broad_mountable and rail_not_mountable
	return _result(
		"WORLD_GENERIC_METAL_PERCH_CONTRACT",
		passed,
		"Broad metal anchors can be landed on, while narrow rails remain pull targets rather than landing platforms." if passed else "Stable broad-anchor and narrow-rail mount flags are not configured correctly.",
		{"broad_anchor_mountable": broad_mountable, "narrow_rail_not_mountable": rail_not_mountable}
	)

func _test_tall_lamp_allomantic_tip_only() -> Dictionary:
	var lamp := _main.get_node_or_null("LuthadelLamp_00") as Node3D
	if lamp == null:
		return _result("WORLD_TALL_LAMP_TIP_ONLY", false, "Tall lamp root missing.", {})
	var tip_root := lamp.get_node_or_null("AllomanticTip") as Node3D
	var targetable_count := 0
	for node in lamp.find_children("*", "MistbornTargetable", true, false):
		if node is MistbornTargetable:
			targetable_count += 1
	var tip_target := tip_root.get_node_or_null("Target_LuthadelLamp_00_tip") as MistbornTargetable if tip_root != null else null
	var tall_enough: bool = tip_root != null and tip_root.position.y >= 7.7
	var passed: bool = tip_root != null and tip_target != null and targetable_count == 1 and tall_enough
	return _result("WORLD_TALL_LAMP_TIP_ONLY", passed, "Lamp is tall and only the tip is an Allomantic Targetable." if passed else "Lamp still exposes more than one Allomantic target or is not tall enough.", {"targetable_count": targetable_count, "tip_y": tip_root.position.y if tip_root != null else -1.0})

func _test_air_feel_contract() -> Dictionary:
	var iron_traversal_gravity_ok: bool = _player.iron_anchor_gravity_scale >= 0.60 and _player.iron_anchor_gravity_scale < 1.0
	var iron_fall_cap_ok: bool = _player.iron_anchor_max_fall_speed >= 14.0 and _player.iron_anchor_max_fall_speed < 28.0
	var steel := _player.get_node_or_null("Steel") as MistbornSteelController
	var steel_uses_force_based_counterfall: bool = steel != null and steel.counterfall_desired_stop_time > 0.0 and steel.counterfall_max_strength_scale >= 2.0
	var passed: bool = iron_traversal_gravity_ok and iron_fall_cap_ok and steel_uses_force_based_counterfall
	return _result(
		"ALLOMANCY_AIR_FEEL_CONTRACT",
		passed,
		"Iron keeps its localized gravity profile; Steel retains normal gravity and arrests falls only through the shared allomantic force resolver." if passed else "Air feel configuration does not match the force-based Steel / localized-Iron gravity contract.",
		{
			"steel_normal_gravity": true,
			"steel_counterfall_stop_time": steel.counterfall_desired_stop_time if steel != null else -1.0,
			"steel_counterfall_max_scale": steel.counterfall_max_strength_scale if steel != null else -1.0,
			"iron_anchor_gravity_scale": _player.iron_anchor_gravity_scale,
			"iron_anchor_max_fall_speed": _player.iron_anchor_max_fall_speed
		}
	)

func _result(test_name: String, passed: bool, details: String, metrics: Dictionary) -> Dictionary:
	return {
		"name": test_name,
		"status": "PASS" if passed else "FAIL",
		"details": details,
		"metrics": metrics
	}

func _has_failures() -> bool:
	for result in _results:
		if String(result.get("status", "FAIL")) == "FAIL":
			return true
	return false

func _write_report() -> void:
	var pass_count := 0
	var fail_count := 0
	for result in _results:
		if result["status"] == "PASS":
			pass_count += 1
		else:
			fail_count += 1

	var report := {
		"suite": "MISTBORN_PLAYER_CORE_V1",
		"started_at": _started_at,
		"finished_at": Time.get_datetime_string_from_system(true),
		"engine_expected": "Godot 4.7.x",
		"environment": "Luthadel runtime + isolated elevated test platform",
		"tests": _results,
		"summary": {
			"passed": pass_count,
			"failed": fail_count,
			"max_measured_frame_ms_after_prewarm": _max_frame_ms
		},
		"notes": [
			"This suite validates functional/runtime behaviour, not subjective Mistborn feel.",
			"The external character asset is optional in the handoff ZIP and is not required for physics/input tests.",
			"A PASS does not mark Player Core feel-validated; the master playtest remains the authority."
		]
	}

	var directory := DirAccess.open("user://")
	if directory != null:
		directory.make_dir_recursive("mistborn_playtests")
	var file := FileAccess.open("user://mistborn_playtests/player_core_latest.json", FileAccess.WRITE)
	if file != null:
		file.store_string(JSON.stringify(report, "  "))
		file.close()

	print("\n=== MISTBORN PLAYER CORE PLAYTEST ===")
	print(JSON.stringify(report, "  "))
	print("=== RESULT: %s ===" % ("PASS" if fail_count == 0 else "FAIL"))
