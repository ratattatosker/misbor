#!/usr/bin/env python3
"""Closed-loop Mistborn runtime playtester.

This is deterministic QA with lightweight agent behaviour. It launches the real
Godot runtime, drives the local UDP bridge, observes snapshots, retries simple
steps when a precondition was not reached, captures evidence, and writes a
machine-readable report.

It does not attempt to judge subjective "Mistborn feel". It validates runtime
behaviour and produces evidence for a later human/AI visual review.
"""
from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
from typing import Any

from qa_motion_analyzer import analyze_trace

HOST = "127.0.0.1"
GAME_PORT = 39123
CLIENT_PORT = 39124
DEFAULT_TIMEOUT = 15.0
POLL_HZ = 10.0
ROOT = Path(__file__).resolve().parent.parent
REPORT_DIR = ROOT / "playtest_reports"
REPORT_PATH = REPORT_DIR / "autonomous_playtest_latest.json"
TRACE_PATH = REPORT_DIR / "autonomous_trace_latest.json"


def find_godot(explicit: str | None) -> str | None:
    candidates: list[str] = []
    if explicit:
        candidates.append(explicit)
    env = os.environ.get("GODOT_BIN")
    if env:
        candidates.append(env)
    for name in ("godot", "godot4", "godot.exe", "godot4.exe"):
        found = shutil.which(name)
        if found:
            candidates.append(found)
    candidates.extend(
        [
            str(ROOT / "tools" / "godot.exe"),
            r"C:\Program Files\Godot\godot.exe",
            r"C:\Program Files\Godot\Godot.exe",
            r"C:\Users\%USERNAME%\AppData\Local\Godot\Godot.exe",
        ]
    )
    for raw in candidates:
        path = os.path.expandvars(raw)
        if Path(path).exists():
            return path
    return None




def godot_version(godot: str) -> str:
    completed = subprocess.run([godot, "--version"], cwd=ROOT, capture_output=True, text=True, check=False)
    if completed.returncode != 0:
        raise RuntimeError(f"Could not query Godot version: {completed.stderr.strip()}")
    return completed.stdout.strip()

def vec_speed(snapshot: dict[str, Any]) -> float:
    if "horizontal_speed" in snapshot:
        return float(snapshot.get("horizontal_speed", 0.0))
    velocity = snapshot.get("velocity", {})
    return math.hypot(float(velocity.get("x", 0.0)), float(velocity.get("z", 0.0)))


def distance(a: dict[str, Any], b: dict[str, Any]) -> float:
    pa, pb = a.get("position", {}), b.get("position", {})
    return math.sqrt(
        (float(pb.get("x", 0.0)) - float(pa.get("x", 0.0))) ** 2
        + (float(pb.get("y", 0.0)) - float(pa.get("y", 0.0))) ** 2
        + (float(pb.get("z", 0.0)) - float(pa.get("z", 0.0))) ** 2
    )


class RuntimeAgent:
    def __init__(self, timeout: float, screenshots: bool) -> None:
        self.timeout = timeout
        self.screenshots = screenshots
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((HOST, CLIENT_PORT))
        self.sock.settimeout(0.15)
        self.proc: subprocess.Popen[str] | None = None
        self.log_file = None
        self.events: list[dict[str, Any]] = []
        self.snapshots: list[dict[str, Any]] = []

    def launch(self, godot: str) -> None:
        cmd = [godot, "--path", str(ROOT), "res://scenes/agent_runtime.tscn"]
        log_path = REPORT_DIR / "godot_runtime_latest.log"
        self.log_file = open(log_path, "w", encoding="utf-8")
        self.events.append({"type": "runtime_log", "path": str(log_path)})
        self.proc = subprocess.Popen(cmd, cwd=ROOT, stdout=self.log_file, stderr=subprocess.STDOUT, text=True)
        deadline = time.monotonic() + self.timeout
        while time.monotonic() < deadline:
            snap = self.snapshot()
            if snap.get("ok"):
                return
            time.sleep(0.2)
        raise RuntimeError("Agent runtime did not become ready within the timeout.")

    def close(self) -> None:
        try:
            self.command({"cmd": "release"}, want_response=False)
            self.command({"cmd": "quit"}, want_response=False)
        except OSError:
            pass
        try:
            self.sock.close()
        finally:
            if self.proc is not None:
                try:
                    self.proc.wait(timeout=3.0)
                except subprocess.TimeoutExpired:
                    self.proc.kill()
            if self.log_file is not None:
                self.log_file.close()
                self.log_file = None

    def command(self, payload: dict[str, Any], want_response: bool = True, expected_type: str | None = None) -> dict[str, Any]:
        # Drop queued periodic snapshots so a request is answered by the matching response.
        while True:
            try:
                self.sock.recvfrom(65535)
            except socket.timeout:
                break
        self.sock.sendto(json.dumps(payload).encode("utf-8"), (HOST, GAME_PORT))
        if not want_response:
            return {"ok": True}
        deadline = time.monotonic() + self.timeout
        while time.monotonic() < deadline:
            try:
                data, _ = self.sock.recvfrom(65535)
            except socket.timeout:
                continue
            try:
                response = json.loads(data.decode("utf-8"))
            except json.JSONDecodeError:
                continue
            if not isinstance(response, dict):
                continue
            if expected_type is None:
                return response
            if StringType := response.get("type"):
                if StringType == expected_type:
                    return response
            if response.get("ack") == payload.get("cmd"):
                return response
        raise TimeoutError(f"No matching response to command {payload!r}")

    def snapshot(self) -> dict[str, Any]:
        response = self.command({"cmd": "snapshot"}, expected_type="snapshot")
        if response.get("type") == "snapshot" and response.get("ok"):
            self.snapshots.append(response)
        return response

    def screenshot(self, label: str) -> dict[str, Any] | None:
        if not self.screenshots:
            return None
        response = self.command({"cmd": "screenshot"}, expected_type="screenshot")
        self.events.append({"type": "screenshot", "label": label, "response": response})
        return response

    def hold_input(self, move_x: float, move_y: float, seconds: float, sprint: bool = False, crouch: bool = False) -> list[dict[str, Any]]:
        self.command(
            {
                "cmd": "input",
                "move": [move_x, move_y],
                "sprint": sprint,
                "crouch": crouch,
                "steel": False,
                "iron": False,
            }
        )
        samples: list[dict[str, Any]] = []
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            snap = self.snapshot()
            if snap.get("ok"):
                samples.append(snap)
            time.sleep(1.0 / POLL_HZ)
        self.command({"cmd": "release"}, want_response=False)
        return samples

    def reset(self) -> dict[str, Any]:
        self.command({"cmd": "reset", "position": [0.0, 0.0, 108.0]})
        time.sleep(0.35)
        return self.snapshot()

    def sample_for(self, seconds: float) -> list[dict[str, Any]]:
        samples: list[dict[str, Any]] = []
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            snap = self.snapshot()
            if snap.get("ok"):
                samples.append(snap)
            time.sleep(1.0 / POLL_HZ)
        return samples


def result(name: str, passed: bool, details: str, metrics: dict[str, Any], anomalies: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    payload = {"name": name, "status": "PASS" if passed else "FAIL", "details": details, "metrics": metrics}
    if anomalies:
        payload["anomalies"] = anomalies
    return payload


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the Mistborn closed-loop runtime playtest.")
    parser.add_argument("--godot", help="Path to the Godot executable.")
    parser.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT)
    parser.add_argument("--no-screenshots", action="store_true")
    args = parser.parse_args()

    godot = find_godot(args.godot)
    if not godot:
        print("ERROR: Godot 4.7.x executable not found. Use --godot or set GODOT_BIN.", file=sys.stderr)
        return 2

    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    try:
        engine_version = godot_version(godot)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    if not engine_version.startswith("4.7"):
        print(f"ERROR: Project expects Godot 4.7.x; detected {engine_version!r}", file=sys.stderr)
        return 2

    agent = RuntimeAgent(args.timeout, screenshots=not args.no_screenshots)
    started = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    results: list[dict[str, Any]] = []
    all_anomalies: list[dict[str, Any]] = []

    try:
        agent.launch(godot)
        boot = agent.snapshot()
        results.append(
            result(
                "AUTONOMOUS_BOOT",
                bool(boot.get("ok")),
                "Runtime bridge is responding." if boot.get("ok") else "Runtime bridge is not ready.",
                boot,
            )
        )
        agent.screenshot("boot")

        base = agent.reset()
        walk = agent.hold_input(0.0, -1.0, 1.25)
        walk_max_speed = max((vec_speed(s) for s in walk), default=0.0)
        walk_distance = distance(base, walk[-1]) if walk else 0.0
        walk_anomalies = analyze_trace(walk)
        all_anomalies.extend([{**a, "test": "AUTONOMOUS_WALK"} for a in walk_anomalies])
        results.append(result("AUTONOMOUS_WALK", walk_distance > 3.0 and walk_max_speed > 3.4 and not walk_anomalies, "Forward locomotion produced measurable travel." if walk_distance > 3.0 and not walk_anomalies else "Walk produced insufficient travel or deterministic motion anomalies.", {"distance_m": walk_distance, "max_speed_mps": walk_max_speed}, walk_anomalies))
        agent.screenshot("walk")

        sprint_start = agent.snapshot()
        sprint = agent.hold_input(0.0, -1.0, 1.25, sprint=True)
        sprint_max_speed = max((vec_speed(s) for s in sprint), default=0.0)
        sprint_distance = distance(sprint_start, sprint[-1]) if sprint else 0.0
        sprint_anomalies = analyze_trace(sprint)
        all_anomalies.extend([{**a, "test": "AUTONOMOUS_SPRINT"} for a in sprint_anomalies])
        results.append(result("AUTONOMOUS_SPRINT", sprint_max_speed > walk_max_speed + 0.9 and not sprint_anomalies, "Sprint materially exceeds walk speed." if sprint_max_speed > walk_max_speed + 0.9 and not sprint_anomalies else "Sprint did not separate enough from walking or showed deterministic anomalies.", {"walk_max_speed_mps": walk_max_speed, "sprint_max_speed_mps": sprint_max_speed, "distance_m": sprint_distance}, sprint_anomalies))
        agent.screenshot("sprint")

        release_start = agent.snapshot()
        braking_samples = agent.sample_for(0.85)
        after_release = braking_samples[-1] if braking_samples else agent.snapshot()
        end_speed = vec_speed(after_release)
        braking_distance = distance(release_start, after_release)
        braking_anomalies = analyze_trace([release_start, *braking_samples])
        all_anomalies.extend([{**a, "test": "AUTONOMOUS_BRAKING"} for a in braking_anomalies])
        results.append(result("AUTONOMOUS_BRAKING", end_speed < 0.9 and not braking_anomalies, "Released movement settles close to rest." if end_speed < 0.9 and not braking_anomalies else "Residual speed or deterministic motion anomalies remain after release.", {"end_speed_mps": end_speed, "distance_after_release_m": braking_distance}, braking_anomalies))

        agent.command({"cmd": "look", "yaw_deg": 90.0, "pitch_deg": -12.0})
        turn = agent.hold_input(0.0, -1.0, 0.85)
        turn_speed = max((vec_speed(s) for s in turn), default=0.0)
        final_turn = turn[-1] if turn else agent.snapshot()
        turn_anomalies = analyze_trace(turn)
        all_anomalies.extend([{**a, "test": "AUTONOMOUS_CAMERA_RELATIVE_TURN"} for a in turn_anomalies])
        results.append(result("AUTONOMOUS_CAMERA_RELATIVE_TURN", turn_speed > 3.0 and not turn_anomalies, "Movement remains responsive after camera yaw changes." if turn_speed > 3.0 and not turn_anomalies else "Camera-relative movement did not produce enough travel or showed deterministic anomalies.", {"yaw_deg": 90.0, "max_speed_mps": turn_speed, "grounded": final_turn.get("grounded", False)}, turn_anomalies))
        agent.screenshot("turn")

        jump_start = agent.snapshot()
        agent.command({"cmd": "jump"})
        jump_trace = [jump_start]
        peak_y = float(jump_start.get("position", {}).get("y", 0.0))
        peak_vertical_speed = 0.0
        for _ in range(30):
            time.sleep(1.0 / POLL_HZ)
            snap = agent.snapshot()
            if not snap.get("ok"):
                continue
            jump_trace.append(snap)
            peak_y = max(peak_y, float(snap.get("position", {}).get("y", peak_y)))
            peak_vertical_speed = max(peak_vertical_speed, float(snap.get("velocity", {}).get("y", 0.0)))
        agent.command({"cmd": "release"}, want_response=False)
        jump_anomalies = analyze_trace(jump_trace)
        all_anomalies.extend([{**a, "test": "AUTONOMOUS_JUMP"} for a in jump_anomalies])
        results.append(result("AUTONOMOUS_JUMP", peak_y - float(jump_start.get("position", {}).get("y", 0.0)) > 0.75 and peak_vertical_speed > 3.5 and not jump_anomalies, "Jump leaves the ground with expected baseline impulse." if peak_y > float(jump_start.get("position", {}).get("y", 0.0)) + 0.75 and not jump_anomalies else "Jump did not reach the expected baseline or showed deterministic anomalies.", {"height_m": peak_y - float(jump_start.get("position", {}).get("y", 0.0)), "peak_vertical_speed_mps": peak_vertical_speed}, jump_anomalies))
        agent.screenshot("jump")

        agent.reset()
        crouch = agent.hold_input(0.0, 0.0, 0.35, crouch=True)
        crouch_state = crouch[-1] if crouch else agent.snapshot()
        crouched = bool(crouch_state.get("crouching", False))
        agent.command({"cmd": "release"}, want_response=False)
        restored = not bool(agent.snapshot().get("crouching", False))
        crouch_anomalies = analyze_trace(crouch)
        all_anomalies.extend([{**a, "test": "AUTONOMOUS_CROUCH"} for a in crouch_anomalies])
        results.append(result("AUTONOMOUS_CROUCH", crouched and restored and not crouch_anomalies, "Crouch engages and restores cleanly." if crouched and restored and not crouch_anomalies else "Crouch state did not transition cleanly or showed deterministic anomalies.", {"crouched": crouched, "restored": restored}, crouch_anomalies))
        agent.screenshot("crouch")

    except Exception as exc:
        results.append(result("AUTONOMOUS_HARNESS", False, f"Harness exception: {exc}", {}))
    finally:
        agent.close()

    passed = sum(1 for r in results if r["status"] == "PASS")
    failed = sum(1 for r in results if r["status"] == "FAIL")
    TRACE_PATH.write_text(json.dumps(agent.snapshots, indent=2, ensure_ascii=False), encoding="utf-8")
    report = {
        "suite": "MISTBORN_PLAYER_CORE_AUTONOMOUS_AGENT_V1",
        "started_at": started,
        "finished_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "godot": godot,
        "godot_version": engine_version,
        "project_root": str(ROOT),
        "results": results,
        "summary": {"passed": passed, "failed": failed, "snapshots": len(agent.snapshots), "deterministic_anomalies": len(all_anomalies)},
        "evidence": {
            "trace": str(TRACE_PATH),
            "runtime_log": str(REPORT_DIR / "godot_runtime_latest.log"),
            "screenshots": [event["response"].get("path") for event in agent.events if event.get("type") == "screenshot" and isinstance(event.get("response"), dict) and event["response"].get("ok")]
        },
        "deterministic_anomalies": all_anomalies,
        "limitations": [
            "This validates runtime behaviour; it does not certify subjective feel.",
            "Visual quality still benefits from screenshot/video review by a human or multimodal evaluator.",
            "The character GLB is optional for physics/input tests in this handoff.",
        ],
    }
    REPORT_PATH.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
