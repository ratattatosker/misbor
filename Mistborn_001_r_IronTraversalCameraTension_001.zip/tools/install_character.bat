@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_character.ps1"
if errorlevel 1 (
  echo.
  echo Character installation failed.
  pause
  exit /b 1
)
echo.
echo Character installed successfully.
pause
