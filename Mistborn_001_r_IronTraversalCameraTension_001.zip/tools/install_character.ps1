$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$targetDir = Join-Path $projectRoot 'assets\characters'
$targetFile = Join-Path $targetDir 'character.glb'

# Real, rigged humanoid GLB derived from Quaternius Universal Base Characters.
# Source repository documents the asset as CC0 and the character as Superhero Male.
$sourceUrl = 'https://raw.githubusercontent.com/programasweights/avatar/main/public/assets/character.glb'

New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
Write-Host 'Mistborn - Character installer' -ForegroundColor Cyan
Write-Host ''
Write-Host 'Downloading the real rigged humanoid GLB (~724 KB)...' -ForegroundColor White
Write-Host $sourceUrl -ForegroundColor DarkGray

try {
    Invoke-WebRequest -Uri $sourceUrl -OutFile $targetFile -UseBasicParsing
} catch {
    Write-Host ''
    Write-Host 'Download failed.' -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}

if (-not (Test-Path -LiteralPath $targetFile)) {
    Write-Host 'The file was not created.' -ForegroundColor Red
    exit 1
}

$bytes = (Get-Item -LiteralPath $targetFile).Length
if ($bytes -lt 500000 -or $bytes -gt 2000000) {
    Remove-Item -LiteralPath $targetFile -Force
    Write-Host "Downloaded file size is unexpected: $bytes bytes." -ForegroundColor Red
    exit 1
}

Write-Host ''
Write-Host "Installed: $targetFile" -ForegroundColor Green
Write-Host ("Size: {0:N0} bytes" -f $bytes) -ForegroundColor Gray
Write-Host ''
Write-Host 'You can now open the Mistborn project in Godot.' -ForegroundColor Green
