#!/usr/bin/env python3
"""Tiny dependency-free UDP client for Mistborn's local Agent Runtime bridge.

Examples:
  python tools/mistborn_agent_client.py snapshot
  python tools/mistborn_agent_client.py input --x 0 --y -1 --sprint
  python tools/mistborn_agent_client.py jump
  python tools/mistborn_agent_client.py look --yaw 45 --pitch -10
  python tools/mistborn_agent_client.py screenshot
"""

from __future__ import annotations

import argparse
import json
import socket
import sys
from typing import Any

HOST = "127.0.0.1"
GAME_PORT = 39123
CLIENT_PORT = 39124
TIMEOUT = 1.5


def send_command(payload: dict[str, Any]) -> None:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((HOST, CLIENT_PORT))
    sock.settimeout(TIMEOUT)
    sock.sendto(json.dumps(payload).encode("utf-8"), (HOST, GAME_PORT))
    try:
        data, _ = sock.recvfrom(65535)
        print(json.dumps(json.loads(data.decode("utf-8")), indent=2, ensure_ascii=False))
    except socket.timeout:
        print("No response received. Is agent_runtime.tscn running?", file=sys.stderr)
        sys.exit(2)
    finally:
        sock.close()


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("snapshot")
    sub.add_parser("jump")
    sub.add_parser("release")
    sub.add_parser("screenshot")
    sub.add_parser("quit")

    p_input = sub.add_parser("input")
    p_input.add_argument("--x", type=float, default=0.0)
    p_input.add_argument("--y", type=float, default=0.0)
    p_input.add_argument("--sprint", action="store_true")
    p_input.add_argument("--crouch", action="store_true")
    p_input.add_argument("--steel", action="store_true")
    p_input.add_argument("--iron", action="store_true")

    p_look = sub.add_parser("look")
    p_look.add_argument("--yaw", type=float, default=0.0)
    p_look.add_argument("--pitch", type=float, default=-12.0)

    p_reset = sub.add_parser("reset")
    p_reset.add_argument("--x", type=float, default=0.0)
    p_reset.add_argument("--y", type=float, default=0.0)
    p_reset.add_argument("--z", type=float, default=108.0)

    args = parser.parse_args()
    if args.cmd == "input":
        payload = {"cmd": "input", "move": [args.x, args.y], "sprint": args.sprint, "crouch": args.crouch, "steel": args.steel, "iron": args.iron}
    elif args.cmd == "look":
        payload = {"cmd": "look", "yaw_deg": args.yaw, "pitch_deg": args.pitch}
    elif args.cmd == "reset":
        payload = {"cmd": "reset", "position": [args.x, args.y, args.z]}
    else:
        payload = {"cmd": args.cmd}
    send_command(payload)


if __name__ == "__main__":
    main()
