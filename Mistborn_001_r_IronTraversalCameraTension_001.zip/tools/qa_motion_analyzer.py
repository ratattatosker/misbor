#!/usr/bin/env python3
"""Small deterministic anomaly analyzer for Mistborn runtime snapshots."""
from __future__ import annotations

import math
from typing import Any


def _pos(snapshot: dict[str, Any]) -> tuple[float, float, float]:
    p = snapshot.get("position", {})
    return float(p.get("x", 0.0)), float(p.get("y", 0.0)), float(p.get("z", 0.0))


def _vel(snapshot: dict[str, Any]) -> tuple[float, float, float]:
    v = snapshot.get("velocity", {})
    return float(v.get("x", 0.0)), float(v.get("y", 0.0)), float(v.get("z", 0.0))


def _speed(snapshot: dict[str, Any]) -> float:
    if "horizontal_speed" in snapshot:
        return float(snapshot.get("horizontal_speed", 0.0))
    vx, _, vz = _vel(snapshot)
    return math.hypot(vx, vz)


def analyze_trace(samples: list[dict[str, Any]], *, max_sample_speed_mps: float = 32.0,
                  max_step_distance_m: float = 5.5, min_stuck_speed_mps: float = 2.0) -> list[dict[str, Any]]:
    """Return machine-readable anomalies; empty means no deterministic anomaly found."""
    anomalies: list[dict[str, Any]] = []
    if len(samples) < 2:
        return anomalies

    for index in range(1, len(samples)):
        prev, cur = samples[index - 1], samples[index]
        px, py, pz = _pos(prev)
        cx, cy, cz = _pos(cur)
        dx, dy, dz = cx - px, cy - py, cz - pz
        step = math.sqrt(dx * dx + dy * dy + dz * dz)
        t0 = float(prev.get("time_ms", 0.0))
        t1 = float(cur.get("time_ms", 0.0))
        dt = max((t1 - t0) / 1000.0, 1e-3)
        observed_speed = step / dt
        if observed_speed > max_sample_speed_mps:
            anomalies.append({
                "type": "TELEPORT_OR_SPEED_SPIKE",
                "sample": index,
                "observed_speed_mps": round(observed_speed, 3),
                "step_distance_m": round(step, 3),
                "delta_seconds": round(dt, 4),
            })
        if step > max_step_distance_m:
            anomalies.append({
                "type": "LARGE_POSITION_STEP",
                "sample": index,
                "step_distance_m": round(step, 3),
            })

        # A moving input state that reports sustained zero displacement is a useful
        # deterministic proxy for getting wedged on geometry.
        move_active = bool(cur.get("input_move_active", False))
        if move_active and _speed(cur) >= min_stuck_speed_mps and step < 0.015 and dt >= 0.08:
            anomalies.append({
                "type": "MOTION_STALL",
                "sample": index,
                "reported_speed_mps": round(_speed(cur), 3),
                "step_distance_m": round(step, 4),
            })

        camera = cur.get("camera", {})
        fov = float(camera.get("fov", 0.0))
        distance = float(camera.get("distance", 0.0))
        if fov and not 45.0 <= fov <= 100.0:
            anomalies.append({"type": "CAMERA_FOV_OUT_OF_RANGE", "sample": index, "fov": round(fov, 3)})
        if distance and not 1.2 <= distance <= 8.0:
            anomalies.append({"type": "CAMERA_DISTANCE_OUT_OF_RANGE", "sample": index, "distance": round(distance, 3)})

        vx, vy, vz = _vel(cur)
        if not all(math.isfinite(value) for value in (cx, cy, cz, vx, vy, vz, fov, distance)):
            anomalies.append({"type": "NON_FINITE_RUNTIME_STATE", "sample": index})

    return anomalies
