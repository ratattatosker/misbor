@echo off
setlocal
set ROOT=%~dp0..
where godot >nul 2>&1
if %errorlevel% equ 0 (
  godot --path "%ROOT%" res://scenes/agent_runtime.tscn %*
  exit /b %errorlevel%
)
echo Godot was not found in PATH.
exit /b 2
