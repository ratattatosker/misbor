$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$Godot = Get-Command godot -ErrorAction SilentlyContinue
if (-not $Godot) {
    Write-Error 'Godot was not found in PATH.'
}
& $Godot.Source --path $Root res://scenes/agent_runtime.tscn @args
exit $LASTEXITCODE
