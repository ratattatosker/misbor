@echo off
setlocal
set ROOT=%~dp0..
where python >nul 2>&1
if %errorlevel% equ 0 (
  python "%ROOT%tools\autonomous_playtest.py" %*
  exit /b %errorlevel%
)
where py >nul 2>&1
if %errorlevel% equ 0 (
  py -3 "%ROOT%tools\autonomous_playtest.py" %*
  exit /b %errorlevel%
)
echo Python 3 was not found in PATH.
exit /b 2
