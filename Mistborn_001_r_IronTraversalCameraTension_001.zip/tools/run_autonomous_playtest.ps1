$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$Python = Get-Command python -ErrorAction SilentlyContinue
if (-not $Python) { $Python = Get-Command py -ErrorAction SilentlyContinue }
if (-not $Python) { Write-Error 'Python 3 was not found in PATH.' }
& $Python.Source (Join-Path $PSScriptRoot 'autonomous_playtest.py') @args
exit $LASTEXITCODE
