@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "ROOT=%~dp0.."
for %%I in ("%ROOT%") do set "ROOT=%%~fI"
set "LOG=%ROOT%\player_core_playtest.log"
set "SCAN_LOG=%ROOT%\mistborn_editor_scan.log"
set "GODOT_EXE="
set "GODOT_VERSION="

echo ============================================================
echo MISTBORN - PRUEBA AUTOMATIZADA DEL NUCLEO DEL JUGADOR
echo ============================================================
echo Carpeta del proyecto: "%ROOT%"
echo.

rem Busca Godot en PATH; si no esta, permite elegir Godot.exe.
for /f "delims=" %%G in ('where godot 2^>nul') do if not defined GODOT_EXE set "GODOT_EXE=%%G"
if not defined GODOT_EXE (
  echo No encuentro Godot en el PATH de Windows.
  echo Selecciona el ejecutable de Godot 4.7.x en la ventana siguiente.
  echo.
  where powershell >nul 2>&1
  if errorlevel 1 goto :not_found
  for /f "usebackq delims=" %%G in (`powershell -NoProfile -STA -ExecutionPolicy Bypass -Command "Add-Type -AssemblyName System.Windows.Forms; $d = New-Object System.Windows.Forms.OpenFileDialog; $d.Title = 'Selecciona el ejecutable de Godot 4.7.x'; $d.Filter = 'Ejecutable de Godot (*.exe)|*.exe|Todos los archivos (*.*)|*.*'; $d.Multiselect = $false; if ($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::WriteLine($d.FileName) }"`) do set "GODOT_EXE=%%G"
)
if not defined GODOT_EXE goto :not_found

echo Ejecutable: "%GODOT_EXE%"
for /f "usebackq delims=" %%V in (`"%GODOT_EXE%" --version 2^>^&1`) do if not defined GODOT_VERSION set "GODOT_VERSION=%%V"
if defined GODOT_VERSION echo Version: %GODOT_VERSION%
echo.

echo [1/2] Escaneando/importando el proyecto para reconstruir el registro de clases globales...
echo Esto es importante al abrir un ZIP limpio por primera vez.
echo Registro del escaneo: "%SCAN_LOG%"
"%GODOT_EXE%" --headless --path "%ROOT%" --import --log-file "%SCAN_LOG%"
set "SCAN_RESULT=%ERRORLEVEL%"
if not exist "%ROOT%\.godot\global_script_class_cache.cfg" goto :class_cache_missing
findstr /c:"MistbornIronController" "%ROOT%\.godot\global_script_class_cache.cfg" >nul
if errorlevel 1 goto :class_cache_missing
findstr /c:"MistbornTargetable" "%ROOT%\.godot\global_script_class_cache.cfg" >nul
if errorlevel 1 goto :class_cache_missing

echo Escaneo terminado (codigo de salida: %SCAN_RESULT%). Registro de clases encontrado.
echo.
echo [2/2] Ejecutando banco de pruebas del jugador...
echo Registro: "%LOG%"
"%GODOT_EXE%" --headless --path "%ROOT%" --log-file "%LOG%" res://scenes/player_core_playtest.tscn %*
set "RESULT=%ERRORLEVEL%"

echo.
echo ============================================================
echo FIN DEL LANZADOR. Codigo de salida de las pruebas: %RESULT%
echo Registro de Godot: "%LOG%"
echo Registro de escaneo/importacion: "%SCAN_LOG%"
echo Informe JSON esperado: user://mistborn_playtests/player_core_latest.json
echo ============================================================
echo.
echo Envia el archivo player_core_playtest.log. Si siguen apareciendo errores de parseo, envia tambien mistborn_editor_scan.log.
echo.
pause
exit /b %RESULT%

:class_cache_missing
echo.
echo ERROR: Godot no genero un registro de clases globales valido o faltan clases requeridas.
echo No se han ejecutado las pruebas, para evitar resultados enganhosos.
echo Codigo del escaneo: %SCAN_RESULT%
echo Revisa y envia este registro: "%SCAN_LOG%"
echo.
pause
exit /b 3

:not_found
>"%LOG%" echo No se pudo localizar ni seleccionar el ejecutable de Godot.
echo.
echo NO SE HA EJECUTADO LA PRUEBA: no se encontro un ejecutable de Godot.
echo Si Godot esta instalado, vuelve a ejecutar este archivo y selecciona Godot.exe.
echo Registro: "%LOG%"
echo.
pause
exit /b 2
