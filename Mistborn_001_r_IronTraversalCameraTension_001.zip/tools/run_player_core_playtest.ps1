$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$Log = Join-Path $Root 'player_core_playtest.log'
$ScanLog = Join-Path $Root 'mistborn_editor_scan.log'
$Godot = Get-Command godot -ErrorAction SilentlyContinue
if (-not $Godot) {
    throw 'Godot was not found in PATH. Use tools/run_player_core_playtest.bat to select Godot.exe, or add Godot 4.7.x to PATH.'
}
$GodotExe = $Godot.Source
Write-Host "Godot: $GodotExe"
Write-Host 'Step 1/2: scanning/importing the project to rebuild the global script class cache...'
& $GodotExe --headless --path $Root --import --log-file $ScanLog
$ScanExit = $LASTEXITCODE
$ClassCache = Join-Path $Root '.godot/global_script_class_cache.cfg'
if (-not (Test-Path $ClassCache) -or -not (Select-String -Path $ClassCache -Pattern 'MistbornIronController' -Quiet) -or -not (Select-String -Path $ClassCache -Pattern 'MistbornTargetable' -Quiet)) {
    throw "Godot did not generate the expected global class cache. Scan exit=$ScanExit. Inspect $ScanLog"
}
Write-Host "Scan completed (exit $ScanExit). Step 2/2: running playtests..."
& $GodotExe --headless --path $Root --log-file $Log res://scenes/player_core_playtest.tscn @args
exit $LASTEXITCODE
